<!DOCTYPE html><html lang="pt-BR"><head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Samir Barbosa">

    
<!-- HOME -->


<!-- SOBRE -->


<!-- SOLUCÕES -->


<!-- SERVIÇOS E INSTALAÇÕES -->


<!-- ARTIGOS -->


<!-- CONTATO -->


<!-- POLÍTICA DE PRIVACIDADE -->

    <title>Página não encontrada – Refrigeração Comercial SUPERFRIO</title>
<meta name="robots" content="max-image-preview:large">
<link rel="dns-prefetch" href="//unpkg.com">
<link rel="dns-prefetch" href="//maps.google.com">
<link rel="dns-prefetch" href="//sdk.mercadopago.com">
<link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
<link rel="alternate" type="application/rss+xml" title="Feed para Refrigeração Comercial SUPERFRIO »" href="http://localhost:10033/feed/">
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para Refrigeração Comercial SUPERFRIO »" href="http://localhost:10033/comments/feed/">
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost:10033\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.6.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id="wp-emoji-styles-inline-css" type="text/css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel="stylesheet" id="wp-block-library-css" href="../css/style.min.css" type="text/css" media="all">
<style id="cost-calculator-builder-calculator-selector-style-inline-css" type="text/css">
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
.ccb-gutenberg-block {
  padding: 20px;
  border: 1px solid black;
}
.ccb-gutenberg-block__header {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}
.ccb-gutenberg-block__icon {
  margin-right: 20px;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id="classic-theme-styles-inline-css" type="text/css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id="global-styles-inline-css" type="text/css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--font-family--inter: "Inter", sans-serif;--wp--preset--font-family--cardo: Cardo;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="contact-form-7-css" href="../css/styles.css" type="text/css" media="all">
<link rel="stylesheet" id="wpcdt-public-css-css" href="../css/wpcdt-public.css" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-layout-css" href="../css/woocommerce-layout.css" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-smallscreen-css" href="../css/woocommerce-smallscreen.css" type="text/css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" id="woocommerce-general-css" href="../css/woocommerce.css" type="text/css" media="all">
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" id="xoo-wsc-fonts-css" href="../css/xoo-wsc-fonts.css" type="text/css" media="all">
<link rel="stylesheet" id="xoo-wsc-style-css" href="../css/xoo-wsc-style.css" type="text/css" media="all">
<style id="xoo-wsc-style-inline-css" type="text/css">




.xoo-wsc-ft-buttons-cont a.xoo-wsc-ft-btn, .xoo-wsc-container .xoo-wsc-btn {
	background-color: #003c90;
	color: #ffffff;
	border: 2px solid #ffffff;
	padding: 10px 20px;
}

.xoo-wsc-ft-buttons-cont a.xoo-wsc-ft-btn:hover, .xoo-wsc-container .xoo-wsc-btn:hover {
	background-color: #ffffff;
	color: #003c90;
	border: 2px solid #000000;
}

 

.xoo-wsc-footer{
	background-color: #ffffff;
	color: #003c90;
	padding: 10px 20px;
	box-shadow: 0 -1px 10px #0000001a;
}

.xoo-wsc-footer, .xoo-wsc-footer a, .xoo-wsc-footer .amount{
	font-size: 18px;
}

.xoo-wsc-btn .amount{
	color: #ffffff}

.xoo-wsc-btn:hover .amount{
	color: #003c90;
}

.xoo-wsc-ft-buttons-cont{
	grid-template-columns: auto;
}

.xoo-wsc-basket{
	bottom: 12px;
	right: 1px;
	background-color: #ffffff;
	color: #003c90;
	box-shadow: 0px 0px 15px 2px #0000001a;
	border-radius: 50%;
	display: flex;
	width: 60px;
	height: 60px;
}


.xoo-wsc-bki{
	font-size: 30px}

.xoo-wsc-items-count{
	top: -12px;
	left: -12px;
}

.xoo-wsc-items-count{
	background-color: #003c90;
	color: #ffffff;
}

.xoo-wsc-container, .xoo-wsc-slider{
	max-width: 365px;
	right: -365px;
	top: 0;bottom: 0;
	bottom: 0;
	font-family: }


.xoo-wsc-cart-active .xoo-wsc-container, .xoo-wsc-slider-active .xoo-wsc-slider{
	right: 0;
}


.xoo-wsc-cart-active .xoo-wsc-basket{
	right: 365px;
}

.xoo-wsc-slider{
	right: -365px;
}

span.xoo-wsch-close {
    font-size: 16px;
    right: 10px;
}

.xoo-wsch-top{
	justify-content: center;
}

.xoo-wsch-text{
	font-size: 20px;
}

.xoo-wsc-header{
	color: #003c90;
	background-color: #ffffff;
	border-bottom: 2px solid #eee;
}


.xoo-wsc-body{
	background-color: #003c90;
}

.xoo-wsc-body, .xoo-wsc-body span.amount, .xoo-wsc-body a{
	font-size: 16px;
	color: #003c90;
}

.xoo-wsc-product{
	padding: 10px 15px;
	margin: 10px 15px;
	border-radius: 5px;
	box-shadow: 0 2px 2px #00000005;
	background-color: #ffffff;
}

.xoo-wsc-img-col{
	width: 28%;
}
.xoo-wsc-sum-col{
	width: 72%;
}

.xoo-wsc-sum-col{
	justify-content: center;
}


/** Shortcode **/
.xoo-wsc-sc-count{
	background-color: #000000;
	color: #ffffff;
}

.xoo-wsc-sc-bki{
	font-size: 28px;
	color: 28;
}
.xoo-wsc-sc-cont{
	color: #000000;
}

.added_to_cart{
	display: none!important;
}

.xoo-wsc-product dl.variation {
	display: block;
}
</style>
<link rel="stylesheet" id="owl-carousel-css" href="../css/owl.carousel.min.css" type="text/css" media="all">
<link rel="stylesheet" id="owl-theme-css" href="../css/owl.theme.default.min.css" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="../css/all.min.css" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-css" href="../css/bootstrap.css" type="text/css" media="all">
<link rel="stylesheet" id="font_awesome-css" href="../css/font-awesome.css" type="text/css" media="all">
<link rel="stylesheet" id="flaticon-css" href="../css/flaticon.css" type="text/css" media="all">
<link rel="stylesheet" id="factoryplus-css" href="../css/factoryplus-icons.css" type="text/css" media="all">
<link rel="stylesheet" id="animate-css" href="../css/animate.css" type="text/css" media="all">
<link rel="stylesheet" id="owl-css" href="../css/owl.css" type="text/css" media="all">
<link rel="stylesheet" id="fancybox-css" href="../css/jquery.fancybox.css" type="text/css" media="all">
<link rel="stylesheet" id="hover-css" href="../css/hover.css" type="text/css" media="all">
<link rel="stylesheet" id="frontend-css" href="../css/frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="style-css" href="../css/style_1.css" type="text/css" media="all">
<link rel="stylesheet" id="settings-css" href="../css/settings.css" type="text/css" media="all">
<link rel="stylesheet" id="layers-css" href="../css/layers.css" type="text/css" media="all">
<link rel="stylesheet" id="nanigation-css" href="../css/navigation.css" type="text/css" media="all">
<link rel="stylesheet" id="responsive-css" href="../css/responsive.css" type="text/css" media="all">
<link rel="stylesheet" id="wc_mercadopago_checkout_components-css" href="../css/mp-plugins-components.min.css" type="text/css" media="all">
<script type="text/javascript" src="jquery.min.js" id="jquery-core-js"></script>
<script type="text/javascript" src="jquery-migrate.min.js" id="jquery-migrate-js"></script>
<script type="text/javascript" src="jquery.blockUI.min.js" id="jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"Ver carrinho","cart_url":"http:\/\/localhost:10033\/carrinho\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="add-to-cart.min.js" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="js.cookie.min.js" id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="woocommerce.min.js" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="WCPAY_ASSETS-js-extra">
/* <![CDATA[ */
var wcpayAssets = {"url":"http:\/\/localhost:10033\/wp-content\/plugins\/woocommerce-payments\/dist\/"};
/* ]]> */
</script>
<script type="text/javascript" id="xoo-wsc-main-js-js-extra">
/* <![CDATA[ */
var xoo_wsc_params = {"adminurl":"http:\/\/localhost:10033\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","qtyUpdateDelay":"500","notificationTime":"5000","html":{"successNotice":"<ul class=\"xoo-wsc-notices\"><li class=\"xoo-wsc-notice-success\"><span class=\"xoo-wsc-icon-check_circle\"><\/span>%s%<\/li><\/ul>","errorNotice":"<ul class=\"xoo-wsc-notices\"><li class=\"xoo-wsc-notice-error\"><span class=\"xoo-wsc-icon-cross\"><\/span>%s%<\/li><\/ul>"},"strings":{"maxQtyError":"Only %s% in stock","stepQtyError":"Quantity can only be purchased in multiple of %s%","calculateCheckout":"Please use checkout form to calculate shipping","couponEmpty":"Please enter promo code"},"isCheckout":"","isCart":"","sliderAutoClose":"1","shippingEnabled":"1","couponsEnabled":"1","autoOpenCart":"yes","addedToCart":"","ajaxAddToCart":"yes","skipAjaxForData":[],"showBasket":"always_show","flyToCart":"no","productFlyClass":"","refreshCart":"no","fetchDelay":"200","triggerClass":""};
/* ]]> */
</script>
<script type="text/javascript" src="xoo-wsc-main.js" id="xoo-wsc-main-js-js" defer="defer" data-wp-strategy="defer"></script>
<link rel="https://api.w.org/" href="http://localhost:10033/wp-json/"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost:10033/xmlrpc.php?rsd">
<script type="text/javascript">window.ccb_nonces = {"ccb_payment":"79cc3e0be7","ccb_contact_form":"63e8574f58","ccb_woo_checkout":"d121c9fd99","ccb_add_order":"0a56c957db","ccb_orders":"98bf39e814","ccb_update_order":"afb5bc6e2c","ccb_send_invoice":"16fae9339c","ccb_get_invoice":"a2d32b27cf","ccb_wp_hook_nonce":"26cc302b29","ccb_razorpay_receive":"d1eb5abbc7"};</script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style id="wp-fonts-local" type="text/css">
@font-face{font-family:Inter;font-style:normal;font-weight:300 900;font-display:fallback;src:url('../fonts/Inter-VariableFont_slnt%2Cwght.woff2') format('woff2');font-stretch:normal;}
@font-face{font-family:Cardo;font-style:normal;font-weight:400;font-display:fallback;src:url('../fonts/cardo_normal_400.woff2') format('woff2');}
</style>

    
    <link rel="shortcut icon" href="../images/favicon.png" type="image/x-icon">

            <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5PZK4VD');</script>
<!-- End Google Tag Manager -->

<meta name="facebook-domain-verification" content="xtxhu5rgxu3ois2sb4akimp77ncsk0">                <!-- Google tag (gtag.js) -->
<script async="" src="../js_1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-136254453-1');
</script>

<!-- Google tag (gtag.js) --> 
<script async="" src="../js_2"></script> 
<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-28BYHGFJCK');
</script>        <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '864136254912326');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=864136254912326&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->            
</head>

<body class="home header-sticky header-v2 hide-topbar-mobile">

    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5PZK4VD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --> 
 

<div id="page">

    <!-- topbar -->
    <div id="fh-header-minimized" class="fh-header-minimized fh-header-v1"></div>
    <div id="topbar" class="topbar">
        <div class="container">

            <div class="topbar-left topbar-widgets text-left">
                <div id="cargo-office-location-widget-2" class="widget cargo-office-location-widget">
                    <div class="office-location clearfix mt--25">
                        <ul class="topbar-office active">
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>Rua. Antonio Christi, 470 LT. PQ Industrial Jundiaí III - Jundiaí/Sp<br>
</li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>(11) 4599-5239</li>
                                                            <li><i class="fa fa-whatsapp" aria-hidden="true"></i><a href="https://api.whatsapp.com/send?phone=+5511960770675&amp;text=Olá, gostaria de tirar um dúvida. Podem me retornar por favor? Obrigado!" class="footer" target="_blank">(11) 96077-0675</a></li>
                                                    </ul>
                    </div>
                </div>
            </div>

            <div class="topbar-right topbar-widgets text-right">
                <div class="widget cargohub-social-links-widget">
                    <div class="list-social style-1">
                                                <a href="https://facebook.com/profile.php?id=100082985059561" class="fa fa-facebook-f" target="_blank"></a>
                        
                                                <a href="https://instagram.com/superfriosr/" class="fa fa-instagram" target="_blank"></a>
                        
                        
                        
                                                <a href="https://linkedin.com/company/superfriosr/" class="fa fa-linkedin" target="_blank"></a>
                        
                        
                                            </div>
                </div>
                <div class="widget cargo-search-widget">
                    <div class="topbar-search topbar-search-1">
                        <a class="current-office" href="https://vagassuperfrio.rhgestor.com.br/" target="_blank">Trabalhe Conosco</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- topbar end -->

    <!-- masthead -->
    <header id="masthead" class="site-header clearfix">

        <div class="header-main clearfix">
            <div class="container mobile_relative">
                <div class="row">
                    <div class="site-logo col-md-3 col-sm-6 col-xs-6">
                                                    <a href="http://localhost:10033/">
                                <img src="../images/logo-superfrio-header.png" class="logo-light show-logo" alt="Refrigeração Comercial SUPERFRIO">
                            </a>
                                            </div>
                    <div class="site-menu col-md-9 col-sm-6 col-xs-6">
                        
                            <nav id="site-navigation" class="main-nav primary-nav nav"><ul id="menu-header" class="menu"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-290 nav-item"><a title="Home" href="http://localhost:10033/" class="nav-link">Home</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-294" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-294 nav-item"><a title="Sobre" href="http://localhost:10033/sobre/" class="nav-link">Sobre</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-295" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-295 nav-item"><a title="Soluções" href="http://localhost:10033/solucoes/" class="nav-link">Soluções</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-293 nav-item"><a title="Serviços e Instalações" href="http://localhost:10033/instalacoes-refrigeracao-industrial/" class="nav-link">Serviços e Instalações</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-589 nav-item"><a title="Supermercados" href="http://localhost:10033/supermercados/" class="nav-link">Supermercados</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-298" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-298 nav-item"><a title="Superbox" href="http://localhost:10033/superbox" class="nav-link">Superbox</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299 nav-item"><a title="Artigos" href="http://localhost:10033/artigos/" class="nav-link">Artigos</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-291" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-291 nav-item"><a title="Contato" href="http://localhost:10033/contato/" class="nav-link">Contato</a></li>
<li class="menu-item xoo-wsc-menu-item">

<div class="xoo-wsc-sc-cont">
	<div class="xoo-wsc-cart-trigger">

					<span class="xoo-wsc-sc-subt">
				<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">R$</span>&nbsp;0,00</bdi></span>			</span>
		

		<div class="xoo-wsc-sc-bkcont">
			
			
									<span class="xoo-wsc-sc-bki xoo-wsc-icon-cart1"></span>
				
			
							<span class="xoo-wsc-sc-count">0</span>
			
		</div>

		
	</div>
</div></li></ul></nav>                           
                    </div>
                </div>
                <a href="#" class="navbar-toggle">
                    <span class="navbar-icon">
                        <span class="navbars-line"></span>
                    </span>
                </a>
            </div>
        </div>

    </header>

<section class="page-title" style="background-image: url();">
    <div class="auto-container">
        <h1>Página não encontrada</h1>
    </div>
</section>

<section class="error-section">
    <div class="auto-container">
        <div class="content">
            <h1>404</h1>
            <h2>Oops! Página não encontrada.</h2>
            <a href="http://localhost:10033/" class="theme-btn btn-style-three"><span class="txt">Voltar para Home</span></a>
        </div>
    </div>
</section>
	

<!--footer sec-->
<div class="footer-widgets widgets-area">
    <div class="footer-sidebars">
        <div class="container">
            <div class="row">
                <div class="footer-sidebar footer-1 col-xs-12 col-sm-6 col-md-3">
                    <div class="widget widget_text">
                        <h4 class="widget-title">A Superfrio</h4>
                        <div class="textwidget">
                            <p>Com um atendimento diferenciado, a SUPERFRIO entende as necessidades de cada projeto fazendo um serviço único e personalizado, utilizando sempre materiais de qualidade.</p>
                        </div>
                    </div>
                    <div class="widget cargohub-social-links-widget">
                        <div class="list-social style-1">
                                                        <a href="https://facebook.com/profile.php?id=100082985059561" class="fa fa-facebook-f" target="_blank"></a>
                            
                                                        <a href="https://instagram.com/superfriosr/" class="fa fa-instagram" target="_blank"></a>
                            
                            
                            
                                                        <a href="https://linkedin.com/company/superfriosr/" class="fa fa-linkedin" target="_blank"></a>
                            
                            
                                                    </div>
                    </div>
                </div>
                <div class="footer-sidebar footer-2 col-xs-12 col-sm-6 col-md-3">
                    <div class="widget widget_nav_menu">
                        <h4 class="widget-title">Mapa do Site</h4>
                        <div class="menu-service-menu-container"><ul id="menu-footer" class="menu"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-300" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-300 nav-item"><a title="Home" href="http://localhost:10033/" class="nav-link">Home</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-305" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-305 nav-item"><a title="Sobre" href="http://localhost:10033/sobre/" class="nav-link">Sobre</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-306" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-306 nav-item"><a title="Soluções" href="http://localhost:10033/solucoes/" class="nav-link">Soluções</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-304" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-304 nav-item"><a title="Serviços e Instalações" href="http://localhost:10033/instalacoes-refrigeracao-industrial/" class="nav-link">Serviços e Instalações</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-301" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-301 nav-item"><a title="Artigos" href="http://localhost:10033/artigos/" class="nav-link">Artigos</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-302" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-302 nav-item"><a title="Contato" href="http://localhost:10033/contato/" class="nav-link">Contato</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-303" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-303 nav-item"><a title="Política de Privacidade" href="http://localhost:10033/politica-de-privacidade/" class="nav-link">Política de Privacidade</a></li>
</ul></div>                    </div>
                </div>
                <div class="footer-sidebar footer-3 col-xs-12 col-sm-6 col-md-3">
                    <div class="widget latest-project-widget">
                        <h4 class="widget-title">Facilidades</h4>
                        <div class="latest-project-list clearfix">
                            <div class="latest-project clearfix">
                                <div class="fp-widget-thumb">
                                    <i class="fa fa-link" aria-hidden="true"></i>
                                                                            <img src="../images/logo-bnds.png" alt="Refrigeração Comercial SUPERFRIO">
                                                                    </div>
                            </div>
                            <div class="latest-project clearfix">
                                <div class="fp-widget-thumb mt-20">
                                    <i class="fa fa-link" aria-hidden="true"></i>
                                                                            <img src="../images/logo-leasing.png" alt="Refrigeração Comercial SUPERFRIO">
                                                                    </div>
                            </div>
                            <div class="latest-project clearfix">
                                <div class="fp-widget-thumb mt-20">
                                    <i class="fa fa-link" aria-hidden="true"></i>
                                                                            <img src="../images/logo-cartao-bnds.png" alt="Refrigeração Comercial SUPERFRIO">
                                                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-sidebar footer-4 col-xs-12 col-sm-6 col-md-3">
                    <div class="widget widget_mc4wp_form_widget">
                        <h4 class="widget-title">Informações</h4>
                        <div class="widget cargohub-social-links-widget">
                            <div class="info">
                                <ul class="info-footer">
                                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>Rua. Antonio Christi, 470 LT. PQ Industrial Jundiaí III - Jundiaí/Sp<br>
</li>
                                    <li><i class="fa fa-phone" aria-hidden="true"></i>(11) 4599-5239</li>
                                                                            <li><i class="fa fa-whatsapp" aria-hidden="true"></i><a href="https://api.whatsapp.com/send?phone=+5511960770675&amp;text=Olá, gostaria de tirar um dúvida. Podem me retornar por favor? Obrigado!" class="footer" target="_blank">(11) 96077-0675</a></li>
                                                                    </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--footer sec end-->

<!--copyright sec-->
<footer class="site-footer">
    <div class="container">
        <div style="display:flex;justify-content:space-evenly;align-items:center;align-content:center;margin-bottom:100px;">
            <span>
            <h4 class="foot">Redes Socias</h4>

        <ul class="social-icons3">
        <li>
            <a href="https://www.facebook.com/seu_perfil" target="_blank">
                <img src="../background-facebook-logo_9007.html" alt="Facebook">
            </a>
        </li>
        <li>
            <a href="https://www.instagram.com/seu_perfil" target="_blank">
                <img src="../images/instagram-logo-png-transparent-background.png" alt="Instagram">
            </a>
        </li>
        <li>
            <a href="https://www.linkedin.com/in/seu_perfil" target="_blank">
                <img src="../images/linkedin-icon-free-png.png" alt="LinkedIn">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img src="../images/8170c0b0cddec975b7c2553c20c1ab7e.png" alt="YouTube">
            </a>
        </li>
    </ul>   
    </span>          

    <span>
    <h4 class="foot">Formas de Pagamento</h4>
    <ul class="social-icons3">
           
        <li>
            <a href="https://www.facebook.com/seu_perfil" target="_blank">
                <img src="../fonts/visa-logo-svg-vector.svg" alt="Visa">
            </a>
        </li>
        <li>
            <a href="https://www.instagram.com/seu_perfil" target="_blank">
                <img src="../images/mastercard-icon-2048x1587-tygju446.png" alt="MasterCard">
            </a>
        </li>
        <li>
            <a href="https://www.linkedin.com/in/seu_perfil" target="_blank">
                <img src="../images/196548.png" alt="Diners Club">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img src="../images/elo-logo-CD5DACF296-seeklogo.com.png" alt="Elo">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img src="../images/3d4e43_14d478689ee04ad9b2d51308bfef0284~mv2_d_3000_1334_s_2.png" alt="Hipercard">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img src="../images/amex-icon-2048x1286-jssggdy1.png" alt="American Express">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img src="../images/boleto-logo-0.png" alt="Boleto">
            </a>
        </li>
        <li>
            <a href="https://www.youtube.com/c/seu_canal" target="_blank">
                <img style="width:80px;" src="../images/1200px-Logo_-_pix_powered_by_Banco_Central_%28Brazil%252C_2020%29.png" alt="Pix">
            </a>
        </li>
    </ul> 
    </span>


    <span>
    <h4 style="opacity:0;">TESTEE</h4>
    <ul class="social-icons3">
           
        <li>
            <a href="https://www.facebook.com/seu_perfil" target="_blank">
                <img src="../images/img_73870.png" alt="Visa">
            </a>
        </li>
        <li>
            <a href="https://www.instagram.com/seu_perfil" target="_blank">
                <img src="../images_1" alt="MasterCard">
            </a>
        </li>
      
       
    </ul> 
    </span>
        </div>
        <div class="row">
            <div class="footer-copyright col-md-6 col-sm-12 col-sx-12">
                <div class="site-info">Copyright ©
                    <script>
                        document.write(new Date().getFullYear());
                    </script> - Refrigeração Comercial SUPERFRIO                </div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12 text-right footer-text"><a href="https://trivelapublicidade.com.br" target="_blank">Trivela Publicidade e Marketing Digital</a> </div>
        </div>
    </div>
</footer>
<!--copyright sec end-->
</div>
<!--End pagewrapper-->

<!--primary-mobile-nav-->
<div class="primary-mobile-nav header-v1" id="primary-mobile-nav" role="navigation">
    <a href="#" class="close-canvas-mobile-panel">×</a>
        <div class="menu-header-container"><ul id="menu-header-1" class="menu"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-290 nav-item"><a title="Home" href="http://localhost:10033/" class="nav-link">Home</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-294 nav-item"><a title="Sobre" href="http://localhost:10033/sobre/" class="nav-link">Sobre</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-295 nav-item"><a title="Soluções" href="http://localhost:10033/solucoes/" class="nav-link">Soluções</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-293 nav-item"><a title="Serviços e Instalações" href="http://localhost:10033/instalacoes-refrigeracao-industrial/" class="nav-link">Serviços e Instalações</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-589 nav-item"><a title="Supermercados" href="http://localhost:10033/supermercados/" class="nav-link">Supermercados</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-298 nav-item"><a title="Superbox" href="http://localhost:10033/superbox" class="nav-link">Superbox</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299 nav-item"><a title="Artigos" href="http://localhost:10033/artigos/" class="nav-link">Artigos</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-291 nav-item"><a title="Contato" href="http://localhost:10033/contato/" class="nav-link">Contato</a></li>
<li class="menu-item xoo-wsc-menu-item">

<div class="xoo-wsc-sc-cont">
	<div class="xoo-wsc-cart-trigger">

					<span class="xoo-wsc-sc-subt">
				<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">R$</span>&nbsp;0,00</bdi></span>			</span>
		

		<div class="xoo-wsc-sc-bkcont">
			
			
									<span class="xoo-wsc-sc-bki xoo-wsc-icon-cart1"></span>
				
			
							<span class="xoo-wsc-sc-count">0</span>
			
		</div>

		
	</div>
</div></li></ul></div></div>

<div id="off-canvas-layer" class="off-canvas-layer"></div>
<!--primary-mobile-nav end-->

<!--Scroll to top-->
<a id="scroll-top" class="backtotop" href="#page-top"><i class="fa fa-angle-up"></i></a>

    <div id="chat-whatsapp">
        <a href="https://api.whatsapp.com/send?phone=+5511960770675&amp;text=Olá, gostaria de tirar um dúvida. Podem me retornar por favor? Obrigado!" target="_blank"><i class="fa fa-whatsapp"></i>
        </a>
    </div>

<div class="xoo-wsc-markup-notices"></div>
<div class="xoo-wsc-markup">
	<div class="xoo-wsc-modal">

		
<div class="xoo-wsc-container">

	<div class="xoo-wsc-basket">

					<span class="xoo-wsc-items-count">0</span>
		

		<span class="xoo-wsc-bki xoo-wsc-icon-cart1"></span>

		
	</div>

	<div class="xoo-wsc-header">

		
		
<div class="xoo-wsch-top">

			<div class="xoo-wsc-notice-container" data-section="cart"><ul class="xoo-wsc-notices"></ul></div>	
			<div class="xoo-wsch-basket">
			<span class="xoo-wscb-icon xoo-wsc-icon-bag2"></span>
			<span class="xoo-wscb-count">0</span>
		</div>
	
			<span class="xoo-wsch-text">Seu carrinho</span>
	
			<span class="xoo-wsch-close xoo-wsc-icon-cross"></span>
	
</div>
		
	</div>


	<div class="xoo-wsc-body">

		
		
<div class="xoo-wsc-empty-cart"><span>Seu carrinho está vazio</span><a class="xoo-wsc-btn" href="http://localhost:10033/loja/">Retornar á loja</a></div>
		
	</div>

	<div class="xoo-wsc-footer">

		
		




<div class="xoo-wsc-ft-buttons-cont">

	<a href="#" class="xoo-wsc-ft-btn xoo-wsc-btn xoo-wsc-cart-close xoo-wsc-ft-btn-continue">Continuar comprando</a>
</div>


		
	</div>

	<span class="xoo-wsc-loader"></span>
	<span class="xoo-wsc-icon-spinner8 xoo-wsc-loader-icon"></span>

</div>
		<span class="xoo-wsc-opac"></span>

	</div>
</div><link rel="stylesheet" id="wc-blocks-style-css" href="../css/wc-blocks.css" type="text/css" media="all">
<script type="text/javascript" src="hooks.min.js" id="wp-hooks-js"></script>
<script type="text/javascript" src="i18n.min.js" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="index.js" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"http:\/\/localhost:10033\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="index_1.js" id="contact-form-7-js"></script>
<script type="text/javascript" src="sourcebuster.min.js" id="sourcebuster-js-js"></script>
<script type="text/javascript" id="wc-order-attribution-js-extra">
/* <![CDATA[ */
var wc_order_attribution = {"params":{"lifetime":1.0000000000000001e-5,"session":30,"base64":false,"ajaxurl":"http:\/\/localhost:10033\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
/* ]]> */
</script>
<script type="text/javascript" src="order-attribution.min.js" id="wc-order-attribution-js"></script>
<script type="text/javascript" src="owl.carousel.min.js" id="owl-carousel-js"></script>
<script type="text/javascript" src="owl.carousel-init.js" id="owl-carousel-init-js"></script>
<script type="text/javascript" id="mytheme-sale-banner-js-extra">
/* <![CDATA[ */
var mytheme_ajax_object = {"ajax_url":"http:\/\/localhost:10033\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="sale-banner.js" id="mytheme-sale-banner-js"></script>
<script type="text/javascript" src="bootstrap.min.js" id="bootstrap_min-js"></script>
<script type="text/javascript" src="jquery.mask.min.js" id="mask_min-js"></script>
<script type="text/javascript" src="jquery.fancybox.pack.js" id="fancybox_pack-js"></script>
<script type="text/javascript" src="jquery.fancybox-media.js" id="fancybox_media-js"></script>
<script type="text/javascript" src="isotope.pkgd.min.js" id="isotope-js"></script>
<script type="text/javascript" src="owl.js" id="owl_js-js"></script>
<script type="text/javascript" src="jquery.appear.js" id="appear-js"></script>
<script type="text/javascript" src="jquery.countTo.js" id="counto-js"></script>
<script type="text/javascript" src="jquery.themepunch.tools.min.js" id="tools_js-js"></script>
<script type="text/javascript" src="jquery.themepunch.revolution.min.js" id="revolution-js"></script>
<script type="text/javascript" src="revolution.extension.actions.min.js" id="revolution_actions-js"></script>
<script type="text/javascript" src="revolution.extension.carousel.min.js" id="revolution_carousel-js"></script>
<script type="text/javascript" src="revolution.extension.kenburn.min.js" id="revolution_kenburn-js"></script>
<script type="text/javascript" src="revolution.extension.layeranimation.min.js" id="revolution_layeranimation-js"></script>
<script type="text/javascript" src="revolution.extension.migration.min.js" id="revolution_migration-js"></script>
<script type="text/javascript" src="revolution.extension.navigation.min.js" id="revolution_navigation-js"></script>
<script type="text/javascript" src="revolution.extension.parallax.min.js" id="revolution_parallax-js"></script>
<script type="text/javascript" src="revolution.extension.slideanims.min.js" id="revolution_slideanims-js"></script>
<script type="text/javascript" src="revolution.extension.video.min.js" id="revolution_video-js"></script>
<script type="text/javascript" src="js.js" id="google_maps-js"></script>
<script type="text/javascript" src="map-script.js" id="map_script-js"></script>
<script type="text/javascript" src="mask-input.js" id="mask_input-js"></script>
<script type="text/javascript" src="scripts.min.js" id="scripts_min-js"></script>
<script type="text/javascript" src="script.js" id="script-js"></script>
<script type="text/javascript" src="mp-plugins-components.min.js" id="wc_mercadopago_checkout_components-js"></script>
<script type="text/javascript" src="mp-checkout-update.min.js" id="wc_mercadopago_checkout_update-js"></script>
<script type="text/javascript" src="../v2" id="wc_mercadopago_sdk-js"></script>
<script type="text/javascript" src="session.min.js" id="wc_mercadopago_security_session-js"></script>
<script type="text/javascript" src="mp-custom-page.min.js" id="wc_mercadopago_custom_page-js"></script>
<script type="text/javascript" src="mp-custom-elements.min.js" id="wc_mercadopago_custom_elements-js"></script>
<script type="text/javascript" id="wc_mercadopago_custom_checkout-js-extra">
/* <![CDATA[ */
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
var wc_mercadopago_custom_checkout_params = {"public_key":"TEST-f11b605c-fbe0-4180-922c-335f093393c7","intl":"pt-BR","site_id":"MLB","currency":"BRL","theme":"superfrio","location":"\/checkout","plugin_version":"7.6.3","platform_version":"9.1.2","cvvText":"d\u00edgitos","installmentObsFee":"Sem acr\u00e9scimos","installmentButton":"Mais op\u00e7\u00f5es","bankInterestText":"Se houverem acr\u00e9scimos, eles ser\u00e3o aplicados pelo seu banco.","interestText":"Acr\u00e9scimos","placeholders":{"issuer":"Banco emissor","installments":"Parcelamento","cardExpirationDate":"mm\/aa"},"cvvHint":{"back":"do verso","front":"da frente"},"input_helper_message":{"cardNumber":{"invalid_type":"N\u00famero do cart\u00e3o \u00e9 obrigat\u00f3rio","invalid_length":"N\u00famero do cart\u00e3o inv\u00e1lido"},"cardholderName":{"221":"Nome do titular \u00e9 obrigat\u00f3rio","316":"Nome do titular inv\u00e1lido"},"expirationDate":{"invalid_type":"Data de vencimento inv\u00e1lida","invalid_length":"Data de vencimento incompleta","invalid_value":"Data de vencimento inv\u00e1lida"},"securityCode":{"invalid_type":"C\u00f3digo de seguran\u00e7a \u00e9 obrigat\u00f3rio","invalid_length":"C\u00f3digo de seguran\u00e7a incompleto"}},"threeDsText":{"title_loading":"Estamos levando voc\u00ea para validar o cart\u00e3o","title_loading2":"com seu banco","text_loading":"Precisamos confirmar que voc\u00ea \u00e9 o titular do cart\u00e3o.","title_loading_response":"Estamos recebendo a resposta do seu banco","title_frame":"Conclua a valida\u00e7\u00e3o banc\u00e1ria para aprovar seu pagamento","tooltip_frame":"Mantenha esta tela aberta. Se voc\u00ea fech\u00e1-la, n\u00e3o poder\u00e1 retomar a valida\u00e7\u00e3o.","message_close":"<b>Por motivos de seguran\u00e7a, seu pagamento foi recusado<\/b><br>Recomendamos que voc\u00ea pague com o meio de pagamento e dispositivo que costuma usar para compras on-line."}};
/* ]]> */
</script>
<script type="text/javascript" src="mp-custom-checkout.min.js" id="wc_mercadopago_custom_checkout-js"></script>
<script type="text/javascript" src="mp-ticket-page.min.js" id="wc_mercadopago_ticket_page-js"></script>
<script type="text/javascript" src="mp-ticket-elements.min.js" id="wc_mercadopago_ticket_elements-js"></script>
<script type="text/javascript" id="wc_mercadopago_ticket_checkout-js-extra">
/* <![CDATA[ */
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
var wc_mercadopago_ticket_checkout_params = {"site_id":"MLB"};
/* ]]> */
</script>
<script type="text/javascript" src="mp-ticket-checkout.min.js" id="wc_mercadopago_ticket_checkout-js"></script>

     

<script>
document.addEventListener('DOMContentLoaded', function () {
    const relatedProductsContainer = document.getElementById('related-products-container');
    
    // Função para salvar a consulta de pesquisa no localStorage
    function saveSearchQuery(query) {
        let searches = JSON.parse(localStorage.getItem('user_searches')) || [];
        if (!searches.includes(query)) {
            searches.push(query);
            localStorage.setItem('user_searches', JSON.stringify(searches));
        }
    }

    // Função para buscar e renderizar produtos relacionados
    function fetchAndRenderProducts() {
        const searchQueries = JSON.parse(localStorage.getItem('user_searches')) || [];

        if (searchQueries.length > 0) {
            const queriesString = searchQueries.map(query => `s=${encodeURIComponent(query)}`).join('&');

            fetch(`/?${queriesString}`)
                .then(response => response.text())
                .then(data => {
                    // Use o parser HTML para extrair os produtos
                    let parser = new DOMParser();
                    let doc = parser.parseFromString(data, 'text/html');
                    let productsHtml = '';

                    doc.querySelectorAll('.products .product').forEach(product => {
                        productsHtml += `
                            <div class="product-card productrelated">
                                <a href="${product.querySelector('a').href}">
                                    <img src="${product.querySelector('img').src}" alt="${product.querySelector('h2').textContent}" />
                                    <h5>${product.querySelector('h2').textContent}</h5>
                                    <p style="display:none;">${product.querySelector('.price').textContent}</p>
                                </a>
                            </div>
                        `;
                    });

                    if (productsHtml === '') {
                        productsHtml = '<p>Nenhum produto encontrado.</p>';
                    }

                    relatedProductsContainer.innerHTML = productsHtml;
                })
                .catch(error => {
                    console.error('Error fetching related products:', error);
                    relatedProductsContainer.innerHTML = '<p>Erro ao carregar produtos.</p>';
                });
        } else {
            relatedProductsContainer.innerHTML = '<p>Nenhuma pesquisa registrada.</p>';
        }
    }

    // Inicializa a função para salvar a consulta e renderizar produtos ao carregar a página
    fetchAndRenderProducts();

    // Salva a consulta de pesquisa se existir
    const searchQuery = new URLSearchParams(window.location.search).get('s');
    if (searchQuery) {
        saveSearchQuery(searchQuery);
    }
});

</script>



</div></body></html>