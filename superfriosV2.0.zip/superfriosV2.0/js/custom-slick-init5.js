jQuery(document).ready(function($) {
    $('.slick-carousel5').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true,
        autoplay:true
    });
    console.log('lets go init 5555')
});
