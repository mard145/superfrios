jQuery(document).ready(function($) {
    function mediaUploader(buttonId, inputId, previewId) {
        var file_frame;
        $('#' + buttonId).on('click', function(e) {
            e.preventDefault();
            if (file_frame) {
                file_frame.open();
                return;
            }
            file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Selecionar Imagem',
                button: {
                    text: 'Selecionar Imagem'
                },
                multiple: false
            });
            file_frame.on('select', function() {
                var attachment = file_frame.state().get('selection').first().toJSON();
                $('#' + inputId).val(attachment.url);
                $('#' + previewId).html('<img src="' + attachment.url + '" style="max-width: 100%; height: auto;" />');
            });
            file_frame.open();
        });
    }
    mediaUploader('carousel_image01_button', 'carousel_image01', 'carousel_image01_preview');
    mediaUploader('carousel_image02_button', 'carousel_image02', 'carousel_image02_preview');
    mediaUploader('carousel_image03_button', 'carousel_image03', 'carousel_image03_preview');
    mediaUploader('carousel_image04_button', 'carousel_image04', 'carousel_image04_preview');
    mediaUploader('carousel_image05_button', 'carousel_image05', 'carousel_image05_preview');
});


document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.querySelector('form.woocommerce-product-search');
    
    if (searchForm) {
        searchForm.addEventListener('submit', function() {
            const searchQuery = document.querySelector('input[name=s]').value;
            saveSearchToLocalStorage(searchQuery);
        });
    }
});

function saveSearchToLocalStorage(query) {
    let searches = JSON.parse(localStorage.getItem('product_searches')) || [];
    searches.push(query);
    if (searches.length > 10) searches.shift();
    localStorage.setItem('product_searches', JSON.stringify(searches));
}

