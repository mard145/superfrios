<?php
class WP_Custom_Nav_Walker extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';

        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= $indent . '<li' . $class_names .'>';
        $attributes = array();
        $attributes['title']  = ! empty($item->attr_title) ? $item->attr_title : '';
        $attributes['target'] = ! empty($item->target) ? $item->target : '';
        $attributes['rel']    = ! empty($item->xfn)     ? $item->xfn : '';
        $attributes['href']   = ! empty($item->url)     ? $item->url : '';

        $attributes['class']  = 'menu-link';
        $attributes = apply_filters('nav_menu_link_attributes', $attributes, $item, $args, $depth);

        $attribute_strings = [];
        foreach ( $attributes as $attr => $value ) {
            if ( ! is_null($value) ) {
                $value = ( 'href' === $attr ) ? esc_url($value) : esc_attr($value);
                $attribute_strings[] = $attr . '="' . $value . '"';
            }
        }
        $attributes = join(' ', $attribute_strings);

        $title = apply_filters('the_title', $item->title, $item->ID);
        $item_output = $args->before;
        $item_output .= '<a ' . $attributes .'>';
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    function start_lvl(&$output, $depth = 0, $args = null) {
        if ( ! isset($args->item_spacing) || 'discard' !== $args->item_spacing ) {
            $t = "\t";
            $n = "\n";
        } else {
            $t = '';
            $n = '';
        }
        $indent = str_repeat($t, $depth);
        $classes = array('sub-menu');
        $class_names = join(' ', apply_filters('nav_menu_submenu_css_class', $classes, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= $indent . '<ul' . $class_names . '>' . $n;
    }
}
