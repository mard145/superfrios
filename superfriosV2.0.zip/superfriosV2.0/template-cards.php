<?php
// Query para obter os posts do Custom Post Type 'card'
$args = array(
    'post_type' => 'card',
    'posts_per_page' => -1, // Número de posts a serem exibidos
);
$query = new WP_Query($args);
?>

<div class="banner-cards-container hidden-sm hidden-xs card-overflow">
    <?php if ($query->have_posts()) : ?>
        <?php while ($query->have_posts()) : $query->the_post(); ?>
            <?php
            // Obtendo os campos personalizados
            $title = get_the_title();
            $image = get_the_post_thumbnail_url(get_the_ID(), 'full'); // Obtém a URL da imagem destacada
            $link = get_post_meta(get_the_ID(), 'link_field', true); // Substitua 'link_field' pelo nome real do campo
            ?>

            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 condensed-padding home-card">
                <div class="banner-card-wrapper">
                    <p class="title"><strong><?php echo esc_html($title); ?></strong></p>
                    <?php if ($image) : ?>
                        <div class="image-wrapper" id="cc_img__resize_wrapper">
                            <a href="<?php echo esc_url($link); ?>">
                                <div id="cc_img__resize_wrapper" style="max-width: 100%; min-height: 0px; height: 100%;">
                                    <img class="card-cover" src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($title); ?>" width="280" height="280">
                                </div>
                            </a>
                        </div>
                    <?php else : ?>
                        <p>Imagem não disponível</p> <!-- Mensagem de fallback se a imagem não estiver definida -->
                    <?php endif; ?>
                </div>
            </div>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php else : ?>
        <p>Nenhum card encontrado.</p>
    <?php endif; ?>
</div>
