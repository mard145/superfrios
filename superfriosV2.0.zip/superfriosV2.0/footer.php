<footer id="footerBar" class="page-row">
      <div data-bind="css:{'container': containFooter}">
        <!-- ko foreach: footerRows -->
        <div class="row">
          <div data-bind="template: { name: 'region-template', foreach: regions }" class="redBox">
            <!-- ko if: $data.hasOwnProperty('structure') && $data.structure() == 101 -->
            <!-- /ko -->
            <!-- ko ifnot: $data.hasOwnProperty('structure') && $data.structure() == 101 -->
            <!-- ko if: $data.widgets() && $data.widgets().length && !$data.globalWidgetsOnly() -->
            <div data-bind="css: widthClass, attr: {id: 'region-'+name()}" class="col-sm-12" id="region-re200009">
              <!-- ko foreach: $data.widgets  -->
              <!-- ko ifnot: global  -->
              <!-- ko if: initialized  -->
              <!-- ko if: $data.elementsSrc -->
              <!-- /ko -->
              <!-- ko if: isPreview -->
              <!-- /ko -->
              <!-- ko ifnot: $data.templateSrc -->
              <!-- /ko -->
              <!-- ko if: $data.templateSrc -->
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarFooter_v1-wi300037" style="">
                <div class="container -footer-content">
                  <div class="row site-links">
                    <div class="col-sm-3 about-section">
                      <div class="aboutUsTitle" data-bind="widgetLocaleText: 'aboutUsTitle'">A Superfrios</div>
                      <ul class="listing">
                        <!-- ko if: $data.translate('aboutUsAreaTitle1') != 'aboutUsAreaTitle1' && $data.translate('aboutUsAreaTitle1') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea1URL').startsWith("/",0)-->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle1', ccLink: {route: $data.translate('aboutUsArea1URL')}" href="/sobre-a-frigelar">Sobre a Superfrios</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea1URL').startsWith("/",0)-->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle2') != 'aboutUsAreaTitle2' && $data.translate('aboutUsAreaTitle2') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea2URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle2', ccLink: {route: $data.translate('aboutUsArea2URL')}" href="/nossas-lojas">Nossas Lojas</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea2URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle3') != 'aboutUsAreaTitle3' && $data.translate('aboutUsAreaTitle3') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea3URL').startsWith("/",0)-->
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea3URL').startsWith("/",0)-->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle3', attr: {href: $data.translate('aboutUsArea3URL')}" target="_blank" href="https://eos.com.br/suaempresa/termoisolantes/">EOS Termoisolantes</a>
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle4') != 'aboutUsAreaTitle4' && $data.translate('aboutUsAreaTitle4') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea4URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle4', ccLink: {route: $data.translate('aboutUsArea4URL')}" href="/vrf">Sistema VRF</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea4URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle5') != 'aboutUsAreaTitle5' && $data.translate('aboutUsAreaTitle5') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea5URL').startsWith("/",0) -->
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea5URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle5', attr: {href: $data.translate('aboutUsArea5URL')}" target="_blank" href="https://jobs.compleo.app/frigelar/home">Trabalhe Conosco</a>
                          <!-- /ko -->

                        </li>
                        <!-- /ko -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea6URL').startsWith("/",0) -->
                          <a data-bind="ccLink: {route: $data.translate('aboutUsArea6URL')}" href="/campea-premio-reclame-aqui">Prêmio Reclame Aqui</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea6URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- ko if: $data.translate('aboutUsAreaTitle7') != 'aboutUsAreaTitle7' && $data.translate('aboutUsAreaTitle7') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea7URL').startsWith("/",0)-->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle7', ccLink: {route: $data.translate('aboutUsArea7URL')}" href="/camaras-frias">Orçamento Câmaras Frias</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea7URL').startsWith("/",0)-->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle8') != 'aboutUsAreaTitle8' && $data.translate('aboutUsAreaTitle8') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('aboutUsArea8URL').startsWith("/",0) -->
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('aboutUsArea8URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'aboutUsAreaTitle8', attr: {href: $data.translate('aboutUsArea8URL')}" target="_blank" href="https://www.frigelar.com.br/file/general/Codigo-de-Etica-e-Conduta-V2.pdf">Código de Ética e Conduta</a>
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->

                        <!-- ko if: $data.translate('aboutUsAreaTitle9') != 'aboutUsAreaTitle9' && $data.translate('aboutUsAreaTitle9') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle10') != 'aboutUsAreaTitle10' && $data.translate('aboutUsAreaTitle10') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle11') != 'aboutUsAreaTitle11' && $data.translate('aboutUsAreaTitle11') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle12') != 'aboutUsAreaTitle12' && $data.translate('aboutUsAreaTitle12') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle13') != 'aboutUsAreaTitle13' && $data.translate('aboutUsAreaTitle13') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle14') != 'aboutUsAreaTitle14' && $data.translate('aboutUsAreaTitle14') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle15') != 'aboutUsAreaTitle15' && $data.translate('aboutUsAreaTitle15') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle16') != 'aboutUsAreaTitle16' && $data.translate('aboutUsAreaTitle16') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle17') != 'aboutUsAreaTitle17' && $data.translate('aboutUsAreaTitle17') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('aboutUsAreaTitle18') != 'aboutUsAreaTitle18' && $data.translate('aboutUsAreaTitle18') != '0' -->
                        <!-- /ko -->
                        <li>
                          <a data-bind="ccLink: { route: '/transparencia-salarial' }" title="ESG" href="/transparencia-salarial">ESG</a>
                        </li>

                      </ul>
                    </div>
                    <div class="col-sm-3 help-section" style="padding:0">
                      <div class="helpTitle" data-bind="widgetLocaleText: 'helpTitle'">Central de Ajuda</div>
                      <ul class="listing">
                        <!-- ko if: $data.translate('helpAreaTitle1') != 'helpAreaTitle1' && $data.translate('helpAreaTitle1') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea1URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle1', ccLink: {route: $data.translate('helpArea1URL')}" href="/como-comprar">Como comprar</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea1URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle2') != 'helpAreaTitle2' && $data.translate('helpAreaTitle2') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea2URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle2', ccLink: {route: $data.translate('helpArea2URL')}" href="/entrega-e-recebimento">Entrega e recebimento</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea2URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle4') != 'helpAreaTitle4' && $data.translate('helpAreaTitle4') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea4URL').startsWith("/",0)-->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle4', ccLink: {route: $data.translate('helpArea4URL')}" href="/garantia">Garantia</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea4URL').startsWith("/",0)-->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle5') != 'helpAreaTitle5' && $data.translate('helpAreaTitle5') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea5URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle5', ccLink: {route: $data.translate('helpArea5URL')}" href="/perguntas-frequentes">Perguntas frequentes</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea5URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle6') != 'helpAreaTitle6' && $data.translate('helpAreaTitle6') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea6URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle6', ccLink: {route: $data.translate('helpArea6URL')}" href="/trocas-e-devolucoes">Trocas e devoluções</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea6URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle7') != 'helpAreaTitle7' && $data.translate('helpAreaTitle7') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea7URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle7', ccLink: {route: $data.translate('helpArea7URL')}" href="/instalador">Programa de Vantagens Impulsiona</a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea7URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle8') != 'helpAreaTitle8' && $data.translate('helpAreaTitle8') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea8URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle8', ccLink: {route: $data.translate('helpArea8URL')}" href="/servico-de-instalacao-de-ar-condicionado">Serviços para ar condicionado </a>
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea8URL').startsWith("/",0) -->
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle9') != 'helpAreaTitle9' && $data.translate('helpAreaTitle9') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea9URL').startsWith("/",0) -->
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea9URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle9', attr: {href: $data.translate('helpArea9URL')}" target="_blank" href="https://eos.com.br/atendimento/#assistencia-tecnica">Assistência técnica EOS</a>
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle10') != 'helpAreaTitle10' && $data.translate('helpAreaTitle10') != '0' -->
                        <li>
                          <!-- ko if: $data.translate('helpArea10URL').startsWith("/",0) -->
                          <!-- /ko -->
                          <!-- ko if: !$data.translate('helpArea10URL').startsWith("/",0) -->
                          <a data-bind="widgetLocaleText: 'helpAreaTitle10', attr: {href: $data.translate('helpArea10URL')}" target="_blank" href="https://www.frigelar.com.br/file/general/Manual_EOS_v7.pdf">Manual de Câmaras Frias</a>
                          <!-- /ko -->
                        </li>
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle11') != 'helpAreaTitle11' && $data.translate('helpAreaTitle11') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle12') != 'helpAreaTitle12' && $data.translate('helpAreaTitle12') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle13') != 'helpAreaTitle13' && $data.translate('helpAreaTitle13') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle14') != 'helpAreaTitle14' && $data.translate('helpAreaTitle14') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle15') != 'helpAreaTitle15' && $data.translate('helpAreaTitle15') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle16') != 'helpAreaTitle16' && $data.translate('helpAreaTitle16') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle17') != 'helpAreaTitle17' && $data.translate('helpAreaTitle17') != '0' -->
                        <!-- /ko -->
                        <!-- ko if: $data.translate('helpAreaTitle18') != 'helpAreaTitle18' && $data.translate('helpAreaTitle18') != '0' -->
                        <!-- /ko -->
                      </ul>
                    </div>

                    <div class="col-md-3">

                      <div class="row mobile-block">
                        <div>
                          <ul>
                            <!-- ko if: $data.translate('billingBoletoURL').startsWith("/",0) -->
                            <!-- /ko -->
                            <!-- ko if: !$data.translate('billingBoletoURL').startsWith("/",0) -->
                            <li>
                              <div class="titlesH5" data-bind="widgetLocaleText: 'billingBoletoTitle'">2ª via de boletos</div>
                            </li>
                            <!-- /ko -->
                          </ul>
                          <ul class="listing">
                            <!-- Paragraphs -->

                            <!-- ko if: $data.translate('billingBoletoParagraph1') != 'billingBoletoParagraph1' && $data.translate('billingBoletoParagraph1') != '0' -->
                            <li>
                              <p data-bind="widgetLocaleText: 'billingBoletoParagraph1'">Consulte pedidos da loja física ou APP</p>
                            </li>
                            <li>
                              <a class="billingboletoTitleText" data-bind="widgetLocaleText: 'billingBoletoText', attr: {href: $data.translate('billingBoletoURL')}" target="_blank" href="https://portaldeboletos.com.br/frigelar">Clique aqui</a>
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingBoletoParagraph2') != 'billingBoletoParagraph2' && $data.translate('billingBoletoParagraph2') != '0' -->
                            <li>
                              <p data-bind="widgetLocaleText: 'billingBoletoParagraph2'">Consulte pedidos do site</p>
                            </li>
                            <li>
                              <a class="billingboletoTitleText" data-bind="widgetLocaleText: 'billingBoletoText', click:$data.goToOrderHistoryPage">Clique aqui</a>
                            </li>
                            <!-- /ko -->
                          </ul>
                        </div>
                      </div>

                      <div class="row mobile-block">
                        <div>
                          <div class="billingTitle" cdata-bind="widgetLocaleText: 'billingTitle'">Cobrança</div>
                          <ul class="listing">
                            <!-- Links -->

                            <!-- ko if: $data.translate('billingLinkTitle1') != 'billingLinkTitle1' && $data.translate('billingLinkTitle1') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle2') != 'billingLinkTitle2' && $data.translate('billingLinkTitle2') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle3') != 'billingLinkTitle3' && $data.translate('billingLinkTitle3') != '0' -->
                            <!-- /ko -->

                            <!-- ko if: $data.translate('billingLinkTitle4') != 'billingLinkTitle4' && $data.translate('billingLinkTitle4') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle5') != 'billingLinkTitle5' && $data.translate('billingLinkTitle5') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle6') != 'billingLinkTitle6' && $data.translate('billingLinkTitle6') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle7') != 'billingLinkTitle7' && $data.translate('billingLinkTitle7') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle8') != 'billingLinkTitle8' && $data.translate('billingLinkTitle8') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle9') != 'billingLinkTitle9' && $data.translate('billingLinkTitle9') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingLinkTitle10') != 'billingLinkTitle10' && $data.translate('billingLinkTitle10') != '0' -->
                            <!-- /ko -->

                            <!-- Paragraphs -->

                            <!-- ko if: $data.translate('billingParagraph1') != 'billingParagraph1' && $data.translate('billingParagraph1') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph2') != 'billingParagraph2' && $data.translate('billingParagraph2') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph3') != 'billingParagraph3' && $data.translate('billingParagraph3') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph4') != 'billingParagraph4' && $data.translate('billingParagraph4') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph5') != 'billingParagraph5' && $data.translate('billingParagraph5') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph6') != 'billingParagraph6' && $data.translate('billingParagraph6') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph7') != 'billingParagraph7' && $data.translate('billingParagraph7') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph8') != 'billingParagraph8' && $data.translate('billingParagraph8') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph9') != 'billingParagraph9' && $data.translate('billingParagraph9') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingParagraph10') != 'billingParagraph10' && $data.translate('billingParagraph10') != '0' -->
                            <!-- /ko -->

                            <!-- Emails -->

                            <!-- ko if: $data.translate('billingEmail1URL') != 'billingEmail1URL' && $data.translate('billingEmail1URL') != '0' -->
                            <li>
                              <a data-bind="widgetLocaleText: $data.removeMailTo('billingEmail1URL'), attr:{ href: $data.translate('billingEmail1URL')}" href="mailto:centraldecobranca@frigelar.com.br">centraldecobranca@superfrios.com.br</a>
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail2URL') != 'billingEmail2URL' && $data.translate('billingEmail2URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail3URL') != 'billingEmail3URL' && $data.translate('billingEmail3URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail4URL') != 'billingEmail4URL' && $data.translate('billingEmail4URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail5URL') != 'billingEmail5URL' && $data.translate('billingEmail5URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail6URL') != 'billingEmail6URL' && $data.translate('billingEmail6URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail7URL') != 'billingEmail7URL' && $data.translate('billingEmail7URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail8URL') != 'billingEmail8URL' && $data.translate('billingEmail8URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail9URL') != 'billingEmail9URL' && $data.translate('billingEmail9URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('billingEmail10URL') != 'billingEmail10URL' && $data.translate('billingEmail10URL') != '0' -->
                            <!-- /ko -->
                          </ul>
                        </div>
                      </div>

                    </div>

                    <div class="col-md-3">

                      <div class="row mobile-block">
                        <div>
                          <div class="titlesH5" data-bind="widgetLocaleText: 'sacTitle'">SAC / Televendas</div>
                          <ul class="listing">
                            <!-- Links -->

                            <!-- ko if: $data.translate('sacLinkTitle1') != 'sacLinkTitle1' && $data.translate('sacLinkTitle1') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle2') != 'sacLinkTitle2' && $data.translate('sacLinkTitle2') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle3') != 'sacLinkTitle3' && $data.translate('sacLinkTitle3') != '0' -->
                            <!-- /ko -->

                            <!-- ko if: $data.translate('sacLinkTitle4') != 'sacLinkTitle4' && $data.translate('sacLinkTitle4') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle5') != 'sacLinkTitle5' && $data.translate('sacLinkTitle5') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle6') != 'sacLinkTitle6' && $data.translate('sacLinkTitle6') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle7') != 'sacLinkTitle7' && $data.translate('sacLinkTitle7') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle8') != 'sacLinkTitle8' && $data.translate('sacLinkTitle8') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle9') != 'sacLinkTitle9' && $data.translate('sacLinkTitle9') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacLinkTitle10') != 'sacLinkTitle10' && $data.translate('sacLinkTitle10') != '0' -->
                            <!-- /ko -->

                            <!-- Paragraphs -->

                            <!-- ko if: $data.translate('sacParagraph1') != 'sacParagraph1' && $data.translate('sacParagraph1') != '0' -->
                            <li>
                              <p data-bind="widgetLocaleText: 'sacParagraph1'">0800 008 8999 / 4007 2808</p>
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('whatsappParagraph1') != 'whatsappParagraph1' && $data.translate('whatsappParagraph1') != '0' -->
                            <li>
                              <a href="http://wa.me/5551998028999" target="_blank" rel="noopener" title="Whatsapp Frigelar" alt="Whatsapp Frigelar">
                                <svg style="width: 13px;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 418.135 418.135" xml:space="preserve">
                                  <g>
                                    <path style="fill:#7AD06D;" d="M198.929,0.242C88.5,5.5,1.356,97.466,1.691,208.02c0.102,33.672,8.231,65.454,22.571,93.536   L2.245,408.429c-1.191,5.781,4.023,10.843,9.766,9.483l104.723-24.811c26.905,13.402,57.125,21.143,89.108,21.631   c112.869,1.724,206.982-87.897,210.5-200.724C420.113,93.065,320.295-5.538,198.929,0.242z M323.886,322.197   c-30.669,30.669-71.446,47.559-114.818,47.559c-25.396,0-49.71-5.698-72.269-16.935l-14.584-7.265l-64.206,15.212l13.515-65.607   l-7.185-14.07c-11.711-22.935-17.649-47.736-17.649-73.713c0-43.373,16.89-84.149,47.559-114.819   c30.395-30.395,71.837-47.56,114.822-47.56C252.443,45,293.218,61.89,323.887,92.558c30.669,30.669,47.559,71.445,47.56,114.817   C371.446,250.361,354.281,291.803,323.886,322.197z"></path>
                                    <path style="fill:#7AD06D;" d="M309.712,252.351l-40.169-11.534c-5.281-1.516-10.968-0.018-14.816,3.903l-9.823,10.008   c-4.142,4.22-10.427,5.576-15.909,3.358c-19.002-7.69-58.974-43.23-69.182-61.007c-2.945-5.128-2.458-11.539,1.158-16.218   l8.576-11.095c3.36-4.347,4.069-10.185,1.847-15.21l-16.9-38.223c-4.048-9.155-15.747-11.82-23.39-5.356   c-11.211,9.482-24.513,23.891-26.13,39.854c-2.851,28.144,9.219,63.622,54.862,106.222c52.73,49.215,94.956,55.717,122.449,49.057   c15.594-3.777,28.056-18.919,35.921-31.317C323.568,266.34,319.334,255.114,309.712,252.351z"></path>
                                  </g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                  <g></g>
                                </svg> 051998028999
                              </a>
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph2') != 'sacParagraph2' && $data.translate('sacParagraph2') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph3') != 'sacParagraph3' && $data.translate('sacParagraph3') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph4') != 'sacParagraph4' && $data.translate('sacParagraph4') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph5') != 'sacParagraph5' && $data.translate('sacParagraph5') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph6') != 'sacParagraph6' && $data.translate('sacParagraph6') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph7') != 'sacParagraph7' && $data.translate('sacParagraph7') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph8') != 'sacParagraph8' && $data.translate('sacParagraph8') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph9') != 'sacParagraph9' && $data.translate('sacParagraph9') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacParagraph10') != 'sacParagraph10' && $data.translate('sacParagraph10') != '0' -->
                            <!-- /ko -->

                            <!-- Emails -->

                            <!-- ko if: $data.translate('sacEmail1URL') != 'sacEmail1URL' && $data.translate('sacEmail1URL') != '0' -->
                            <li>
                              <a data-bind="widgetLocaleText: $data.removeMailTo('sacEmail1URL'), attr:{ href: $data.translate('sacEmail1URL')}" href="mailto:sac@frigelar.com.br">sac@superfrios.com.br</a>
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail2URL') != 'sacEmail2URL' && $data.translate('sacEmail2URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail3URL') != 'sacEmail3URL' && $data.translate('sacEmail3URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail4URL') != 'sacEmail4URL' && $data.translate('sacEmail4URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail5URL') != 'sacEmail5URL' && $data.translate('sacEmail5URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail6URL') != 'sacEmail6URL' && $data.translate('sacEmail6URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail7URL') != 'sacEmail7URL' && $data.translate('sacEmail7URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail8URL') != 'sacEmail8URL' && $data.translate('sacEmail8URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail9URL') != 'sacEmail9URL' && $data.translate('sacEmail9URL') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('sacEmail10URL') != 'sacEmail10URL' && $data.translate('sacEmail10URL') != '0' -->
                            <!-- /ko -->
                          </ul>
                        </div>
                      </div>

                      <div class="row mobile-block">
                        <div>
                          <div class="titlesH5">Segurança e Privacidade</div>
                          <ul class="listing">
                            <li><a href="https://blog.frigelar.com.br/dicas-de-seguranca-frigelar" target="_blank" title="Dicas de Segurança">Dicas de Segurança</a></li>
                            <li>
                              <a href="/politica-de-privacidade">Política de privacidade</a>
                            </li>
                            <li>
                              <a target="_blank" title="Contate o Canal de Privacidade" href="https://titulares.becompliance.com/webforms/6c6b50fd-6cea-483d-a066-12982fc1c00f/0133b665-716e-4030-8f62-75de88b03534">Contate o Canal de Privacidade</a>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div class="row mobile-block">
                        <div>
                          <ul class="listing hotlink-list">
                            <li class="additional-space">
                              <a class="highlighted-links" id="chat" data-bind="click: openChat">Atendente Virtual</a>
                            </li>
                            <!-- ko if: $data.translate('hotLink1') != 'hotLink1' && $data.translate('hotLink1') != '0' -->
                            <li class="additional-space">
                              <!-- ko if: $data.translate('hotLink1URL').startsWith("/",0) -->
                              <a class="highlighted-links" data-bind="widgetLocaleText: 'hotLink1', ccLink: {route: $data.translate('hotLink1URL')}" href="/nossas-lojas">Nossas Lojas</a>
                              <!-- /ko -->
                              <!-- ko if: !$data.translate('hotLink1URL').startsWith("/",0) -->
                              <!-- /ko -->
                            </li>
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink2') != 'hotLink2' && $data.translate('hotLink2') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink3') != 'hotLink3' && $data.translate('hotLink3') != '0' -->
                            <!-- /ko -->

                            <!-- ko if: $data.translate('hotLink4') != 'hotLink4' && $data.translate('hotLink4') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink5') != 'hotLink5' && $data.translate('hotLink5') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink6') != 'hotLink6' && $data.translate('hotLink6') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink7') != 'hotLink7' && $data.translate('hotLink7') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink8') != 'hotLink8' && $data.translate('hotLink8') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink9') != 'hotLink9' && $data.translate('hotLink9') != '0' -->
                            <!-- /ko -->
                            <!-- ko if: $data.translate('hotLink10') != 'hotLink10' && $data.translate('hotLink10') != '0' -->
                            <!-- /ko -->
                          </ul>

                        </div>
                      </div>

                    </div>

                  </div>

                  <div class="row">
                    <div class="col-md-3">
                      <div class="titlesH5" data-bind="widgetLocaleText: 'socialMediaTitle'">Redes sociais</div>
                      <?php echo do_shortcode('[social_media_images5]'); ?>

                    </div>
                    <div class="col-md-6 mobile-block">
                      <div class="titlesH5" data-bind="widgetLocaleText: 'paymentMethodsTitle'">Formas de Pagamento</div>
                      <?php echo do_shortcode('[payment_methods_images]'); ?>

                    </div>
                    <div class="col-md-3">
                      <ul class="listing horizontal-list mobile-block">
                      <?php echo do_shortcode('[certificates_images]'); ?>

                      </ul>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <p class="terms" data-bind="widgetLocaleText: 'terms'">Superfrios Comércio e Indústria Ltda. - CNPJ 92.660.406/0001-19 - Av. Pernambuco, 2285, Navegantes. CEP 90240-005, Porto Alegre/RS; </p>
                  </div>

                </div>
              </div>
              <!-- /ko -->
              <!-- /ko -->
              <!-- /ko -->

              <!-- ko ifnot: global  -->
              <!-- ko if: initialized  -->
              <!-- ko if: $data.elementsSrc -->
              <!-- /ko -->
              <!-- ko if: isPreview -->
              <!-- /ko -->
              <!-- ko ifnot: $data.templateSrc -->
              <!-- /ko -->
              <!-- ko if: $data.templateSrc -->
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarAvisoCookies_v1-wi600010" style="">
                <div id="modalPrivacyPolicy" class="modalPrivacyPolicy" data-bind="visible: isModalPolicyVisible()" style="display: none;">
                  <p><strong>Superfrios e os cookies:</strong> Ao clicar em "Concordar", você concorda com uso de cookies para melhorar e personalizar a sua experiência, bem como nossa Política de Privacidade.
                    <a href="/politica-de-privacidade" target="_blank">
                      Ver a Política de Privacidade
                    </a>.
                  </p>
                  <button id="modalPrivacyPolicy-btn" data-bind="click: modalPrivacyPolicyBtnClick">concordar</button>
                </div>
              </div>
            
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="webContent_v2-wi3800001" style="">
    
                <div class="row">

                  <div class="oc-panel col-md-12" data-oc-id="panel-0-0">

                    <!-- oc sect><script type="application/ld+json">
                          {
                            "@context": "https://schema.org",
                            "@type": "ElectronicsStore",
                            "name": "Frigelar Comércio e Indústria Ltda.",
                            "image": "https://www.frigelar.com.br/ccstore/v1/images/?source=/file/general/Novo-Logo-Frigelar-Azul.png&height=47&width=236",
                            "@id": "",
                            "url": "https://www.frigelar.com.br/",
                            "telephone": "051998028999",
                            "address": {
                              "@type": "PostalAddress",
                              "streetAddress": "Av. Pernambuco, 2285, Navegantes",
                              "addressLocality": "Porto Alegre/RS",
                              "postalCode": "90240-005",
                              "addressCountry": "BR"
                            },
                            "geo": {
                              "@type": "GeoCoordinates",
                              "latitude": -30.0128092,
                              "longitude": -51.2025776
                            },
                            "openingHoursSpecification": {
                              "@type": "OpeningHoursSpecification",
                              "dayOfWeek": [
                                "Monday",
                                "Tuesday",
                                "Wednesday",
                                "Thursday",
                                "Friday",
                                "Saturday",
                                "Sunday"
                              ],
                              "opens": "00:00",
                              "closes": "23:59"
                            },
                            "sameAs": [
                              "https://www.facebook.com/Frigelar",
                              "https://www.instagram.com/Frigelar/",
                              "https://www.linkedin.com/company/frigelar/?viewAsMember=true",
                              "https://www.youtube.com/user/CanalFrigelar",
                              "https://blog.frigelar.com.br/"
                            ],
                            "department": [{
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Manaus",
                              "image": "https://www.frigelar.com.br/file/general/F39.jpg",
                              "telephone": "092 2123.8923"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Salvador",
                              "image": "https://www.frigelar.com.br/file/general/F35.jpg",
                              "telephone": "071 3507.7474"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Fortaleza",
                              "image": "https://www.frigelar.com.br/file/general/F24.jpg",
                              "telephone": "085 3924-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Brasília",
                              "image": "https://www.frigelar.com.br/file/general/F31.jpg",
                              "telephone": "061 3203-9999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Vitória",
                              "image": "https://www.frigelar.com.br/file/general/F13.jpg",
                              "telephone": "027 3301-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Vila Velha",
                              "image": "https://www.frigelar.com.br/file/general/F25.jpg",
                              "telephone": "027 3533-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Goiânia",
                              "image": "https://www.frigelar.com.br/file/general/F21.jpg",
                              "telephone": "062 3878-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frgielar Belo Horizente",
                              "image": "https://www.frigelar.com.br/file/general/F32.jpg",
                              "telephone": "031 3323-8989"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Uberlândia",
                              "image": "https://www.frigelar.com.br/file/general/F43.jpg",
                              "telephone": "034 2101-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Extrema",
                              "image": "https://www.frigelar.com.br/file/general/F52.jpg",
                              "telephone": "19 98141-3334"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Cuiabá",
                              "image": "https://www.frigelar.com.br/file/general/F53-New.jpg",
                              "telephone": "65 3928-4999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Belém",
                              "image": "https://www.frigelar.com.br/file/general/F37.jpg",
                              "telephone": "091 3205-8282"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Ananindeua",
                              "image": "https://www.frigelar.com.br/file/general/F38.jpg",
                              "telephone": "(91) 3039-7599"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar João Pessoa",
                              "image": "https://www.frigelar.com.br/file/general/F26.jpg",
                              "telephone": "083 3031-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Cuiabá",
                              "image": "https://www.frigelar.com.br/file/general/F03.jpg",
                              "telephone": "041 2102-8989"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Teresina",
                              "image": "https://www.frigelar.com.br/file/general/F57.jpeg",
                              "telephone": "86 2107-8800"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Recife",
                              "image": "https://www.frigelar.com.br/file/general/F06.jpg",
                              "telephone": "081 3323-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Rio de Janeiro",
                              "image": "https://www.frigelar.com.br/file/general/F08.jpg",
                              "telephone": "021 2102-8989"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Porto Alegre",
                              "image": "https://www.frigelar.com.br/file/general/F10.jpg",
                              "telephone": "051 3314-8977"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Cachoeirinha",
                              "image": "https://www.frigelar.com.br/file/general/F14-16.jpg",
                              "telephone": "051 2131-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar São José (SC)",
                              "image": "https://www.frigelar.com.br/file/general/F33.jpg",
                              "telephone": "048 3722-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Itajaí",
                              "image": "https://www.frigelar.com.br/file/general/F48.jpg",
                              "telephone": "47 3404-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Navegantes",
                              "image": "https://www.frigelar.com.br/file/general/F49.jpg",
                              "telephone": "47 3404-8901"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Florianópolis",
                              "image": "https://www.frigelar.com.br/file/general/F54.jpg",
                              "telephone": "48 3877.8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar São Paulo",
                              "image": "https://www.frigelar.com.br/file/general/F04.jpg",
                              "telephone": "011 3363-2400"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Campinas",
                              "image": "https://www.frigelar.com.br/file/general/F18.jpg",
                              "telephone": "019 3734-4444"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Ribeirão Preto",
                              "image": "https://www.frigelar.com.br/file/general/F07.jpg",
                              "telephone": "016 2102-8989"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar São José do Rio Preto",
                              "image": "https://www.frigelar.com.br/file/general/F20.jpg",
                              "telephone": "017 3202-6959"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar São José dos Campos",
                              "image": "https://www.frigelar.com.br/file/general/F44.jpg",
                              "telephone": "012 2122-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Piracicaba",
                              "image": "https://www.frigelar.com.br/file/general/F45.jpg",
                              "telephone": "019 3302-4999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Osasco",
                              "image": "https://www.frigelar.com.br/file/general/F50.jpg",
                              "telephone": "11 2113-8999"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Guaralhos",
                              "image": "https://www.frigelar.com.br/file/general/F46.jpg",
                              "telephone": "011 2714-9123"
                            }, {
                              "@type": "ElectronicsStore",
                              "name": "Frigelar Santos",
                              "image": "https://www.frigelar.com.br/file/general/F56.jpg",
                              "telephone": "013 2105-7111"
                            }]
                          }
                        </script>-->
                      </div>
                      <!-- /ko -->
                      <!-- /ko -->

                    </span>

                    <!-- /oc -->

                  </div>


                </div>
                <!-- /oc -->
              </div>
              <!-- /ko -->
              <!-- /ko -->
              <!-- /ko -->
              <!-- /ko -->
            </div>
            <!-- /ko -->
            <!-- /ko -->
          </div>
        </div>
        <!-- /ko -->
      </div>
    </footer>
  </div>

  <!--<script type="text/html" id="region-template"></script>-->

  <!--<script type="text/html" id="stack-template">-->
    <!-- ko if: $masterViewModel.isPreview -->
  <div class="sf-display-error">
    <span class="sf-error-title" data-bind="text: $root.displayErrorMessage"></span>:
    <span class="sf-error-msg"></span>
  </div>
  <!-- /ko -->
  <!-- ko ifnot: templateSrc -->
  <!-- ko if: templatePath() -->
  <div data-bind='template: {name: templatePath(), templateUrl: ""}, attr: {id: stackType()+"-"+id()}' class="stack-template "></div>
  <!-- /ko -->
  <!-- /ko -->
  <!-- ko if: templateSrc -->
  <div data-bind='template: {name: name(), templateSrc: templateSrc()}, attr: {id: stackType()+"-"+id()}' class="stack-template "></div>
  <!-- /ko -->
  </script>

  <!-- this template is loaded on site load and is available then onwards even if internet connection has some issue -->
  <!--<script type="text/html" id="notificationsNetworkError">
    <span data-bind="text: networkErrorMessage"></span>
    <u><a data-bind="text: networkErrorReloadText" href="javascript:location.reload(true);"></a></u>
  </script>-->




  <!--<script type="text/javascript" nonce="">
    window.storeLibsPath = './js/store-libs.js';
    window.ccKoOjExtensionsPath = './js/cc-ko-oj-extensions.js';
  </script>
  <script type="text/javascript">
    var require = {
      "config": {
        "ccNavState": {
          "referrer": "/",
          "statusCode": "200"
        },
        "ccResourceLoader": {
          "jsUrls": [
            "./js/frigelarGlobalPaymentUtils.min.js",
            "./js/frigelarGlobalUtils.min.js",
            "./js/frigelarJqueryPlugins.min.js"
          ]
        },
        "pageLayout/css-loader": {
          "optimizingCSS": true
        }
      },
      "urlArgs": "bust=24.05",
      "waitSeconds": 45
    };
  </script>
  <script src="./js/require.js"></script>

  <script src="./js/main.js"></script>

  <script src="./js/store-libs.js"></script>
-->




  <div></div>
  <div id="loom-companion-mv3" ext-id="liecbddmkiiihnedobmlmillhodjkdmb">
    <section id="shadow-host-companion"></section>
  </div>
  <script type="text/html" id="frigelarHomeBanner_v1-add-to-purchase-list">
    <!-- ko if: $data.initialized() && $data.elements.hasOwnProperty('purchase-list') -->
  <div class="btn-group swm-add-to-wishlist-selector add-space-to-purchase-list">
    <!-- ko if:$data.quickViewFromPurchaseList !== undefined -->
    <!-- ko if:!$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseList" data-backdrop="static" data-dismiss="modal" data-bind="disabled:{condition:!validateAddToCart(),click:$data.elements['purchase-list'].addItemToGivenPurchaseList.bind($data)}, widgetLocaleText:'productAddToPurchaseListText'" class="cc-button-secondary">
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList == undefined -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->

    <!-- ko if: $data.user().loggedIn() -->
    <ul class="dropdown-menu cc-scrollable-menu" role="menu" aria-labelledby="cc-prodDetailsAddToPurchaseListDropdown">
      <li role="presentation" class="dropdown-header" data-bind="widgetLocaleText: 'myPurchaseListText'"></li>
      <!-- ko foreach : {data : $data.elements['purchase-list'].purchaseListArray, as : 'purchaseList'} -->
      <li role="presentation">
        <a role="menuitem" tabindex="-1" href="#" data-bind="text: purchaseList.purchaseListName,
         click: $parent['elements']['purchase-list'].addItemToPurchaseList.bind($parent, purchaseList)"></a>
      </li>
      <!-- /ko -->
      <li role="presentation" class="divider"></li>
      <li role="presentation"><a role="menuitem" tabindex="-1" href="" data-bind="widgetLocaleText: 'createNewPurchaseListText',
        click: $parent['elements']['purchase-list'].addToNewPurchaseListClick.bind($parent)"></a></li>
    </ul>
    <!-- /ko -->
  </div>
  <!-- /ko -->

  <div class="modal fade" id="CC-newPurchaseList-modal" tabindex="-1" role="alert">
    <div class="modal-dialog" id="CC-newPurchaseList-modal-dialog">
      <div class="modal-content" id="CC-newPurchaseListModalContent">
        <div class="modal-header" id="CC-newPurchaseList-modal-header">
          <button type="button" class="close" data-dismiss="modal" id="CC-newPurchaseList-modal-headerClose" aria-hidden="true">&times;</button>
          <h4 data-bind="widgetLocaleText:'newPurchaseListModalTitle'" id="CC-newPurchaseList-modal-headerText"></h4>
        </div>
        <hr class="hr-without-margin">
        <div class="modal-body" id="CC-newPurchaseList-modal-modalBody">
          <div><span data-bind="widgetLocaleText:'listNameText'"></span></div>
          <div class="row">
            <div class="form-group col-md-6">
              <span class="text-danger visible-xs" id="CC-purchaseListName" role="alert"></span>
              <div class="control">
                <input id="CC-purchaseList-name" type="text" class="col-md-12 form-control" data-bind="widgetLocaleText: {attr: 'placeholder', value: 'purchaseListNameText'}" />
              </div>
            </div>
            <div class="text-danger col-md-4 cc-alert" id="cc-purchaseListName-error" role="alert">
              <span data-bind="widgetLocaleText:'listNameMandatoryText'">
            </div>
          </div>
        </div>
        <div class="modal-footer" id="CC-newPurchaseList-modal-footer">
          <button class="btn cc-button-secondary" id="CC-newPurchaseList-modal-cancel" data-bind="click: $parent.handleModalNo">
            <span id="CC-newPurchaseList-modal-discard" data-bind="widgetLocaleText:'purchaseListModalCancel'"></span>
          </button>
          <button class="btn cc-button-primary" id="CC-newPurchaseList-modal-submit" data-bind="click: $parent.handleModalYes">
            <span id="CC-newPurchaseList-modal-save" data-bind="widgetLocaleText:'purchaseListModalCreateList'"></span>
          </button>
        </div>
      </div>
    </div>
  </div>
  </script>
  <script type="text/html" id="frigelarHomeBanner_v1-frigelarHomeBannerImage"></script>
  <script type="text/html" id="frigelarHomeBanner_v1-generic-text">
    <span data-bind="widgetLocaleText:{custom: $elementInstance.textId, value: 'customTextNotFound', attr:'innerText'}"></span>
  </script>
  <script type="text/html" id="frigelarHomeBanner_v1-image">
    <!-- ko with: $elementInstance -->
  <!-- ko if: ($data.hasOwnProperty('config') && $data.id !== 'id') -->
  <div class="cc-image" data-bind="style: {'text-align': config.horizontalAlignment.horizontalAlignment}">
    <!-- ko if: (config.image.link && config.image.link !== '') -->
    <a data-bind="attr: {href: config.image.link}">
      <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    </a>
    <!-- /ko -->
    <!-- ko ifnot: (config.image.link && config.image.link !== '') -->
    <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    <!-- /ko -->
  </div>
  <!-- /ko -->
  <!-- /ko -->

  </script>
  <script type="text/html" id="frigelarHomeBanner_v1-product-quickview">
    <!-- Quick View Element -->
  <!-- ko if: initialized() && $data.elements.hasOwnProperty('product-quickview') && $data.elements['product-quickview'].quickViewEnabled($parents) -->
  <div class="quick-view hidden-xs hidden-sm">
    <p data-bind="click: $data.elements['product-quickview'].handleQuickViewClick.bind($product, $popupId, $parents[1]), 
	                attr: { title: $product.displayName },
		              widgetLocaleText: 'quickViewText'" class="cc-product-quickview"></p>
  </div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarHomeBanner_v1-rich-text">
    <!-- ko with: $elementInstance -->
  <!-- ko if: ($data.hasOwnProperty('config') && $data.id !== 'id') -->
  <div class="cc-rich-text" data-bind="style: {paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}, html: config.richText.content">
  </div>
  <!-- /ko -->
  <!-- /ko -->

  </script>
  <script type="text/html" id="frigelarWebContent_v1-add-to-purchase-list">
    <!-- ko if: $data.initialized() && $data.elements.hasOwnProperty('purchase-list') -->
  <div class="btn-group swm-add-to-wishlist-selector add-space-to-purchase-list">
    <!-- ko if:$data.quickViewFromPurchaseList !== undefined -->
    <!-- ko if:!$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseList" data-backdrop="static" data-dismiss="modal" data-bind="disabled:{condition:!validateAddToCart(),click:$data.elements['purchase-list'].addItemToGivenPurchaseList.bind($data)}, widgetLocaleText:'productAddToPurchaseListText'" class="cc-button-secondary">
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList == undefined -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->

    <!-- ko if: $data.user().loggedIn() -->
    <ul class="dropdown-menu cc-scrollable-menu" role="menu" aria-labelledby="cc-prodDetailsAddToPurchaseListDropdown">
      <li role="presentation" class="dropdown-header" data-bind="widgetLocaleText: 'myPurchaseListText'"></li>
      <!-- ko foreach : {data : $data.elements['purchase-list'].purchaseListArray, as : 'purchaseList'} -->
      <li role="presentation">
        <a role="menuitem" tabindex="-1" href="#" data-bind="text: purchaseList.purchaseListName,
         click: $parent['elements']['purchase-list'].addItemToPurchaseList.bind($parent, purchaseList)"></a>
      </li>
      <!-- /ko -->
      <li role="presentation" class="divider"></li>
      <li role="presentation"><a role="menuitem" tabindex="-1" href="" data-bind="widgetLocaleText: 'createNewPurchaseListText',
        click: $parent['elements']['purchase-list'].addToNewPurchaseListClick.bind($parent)"></a></li>
    </ul>
    <!-- /ko -->
  </div>
  <!-- /ko -->

  <div class="modal fade" id="CC-newPurchaseList-modal" tabindex="-1" role="alert">
    <div class="modal-dialog" id="CC-newPurchaseList-modal-dialog">
      <div class="modal-content" id="CC-newPurchaseListModalContent">
        <div class="modal-header" id="CC-newPurchaseList-modal-header">
          <button type="button" class="close" data-dismiss="modal" id="CC-newPurchaseList-modal-headerClose" aria-hidden="true">&times;</button>
          <h4 data-bind="widgetLocaleText:'newPurchaseListModalTitle'" id="CC-newPurchaseList-modal-headerText"></h4>
        </div>
        <hr class="hr-without-margin">
        <div class="modal-body" id="CC-newPurchaseList-modal-modalBody">
          <div><span data-bind="widgetLocaleText:'listNameText'"></span></div>
          <div class="row">
            <div class="form-group col-md-6">
              <span class="text-danger visible-xs" id="CC-purchaseListName" role="alert"></span>
              <div class="control">
                <input id="CC-purchaseList-name" type="text" class="col-md-12 form-control" data-bind="widgetLocaleText: {attr: 'placeholder', value: 'purchaseListNameText'}" />
              </div>
            </div>
            <div class="text-danger col-md-4 cc-alert" id="cc-purchaseListName-error" role="alert">
              <span data-bind="widgetLocaleText:'listNameMandatoryText'">
            </div>
          </div>
        </div>
        <div class="modal-footer" id="CC-newPurchaseList-modal-footer">
          <button class="btn cc-button-secondary" id="CC-newPurchaseList-modal-cancel" data-bind="click: $parent.handleModalNo">
            <span id="CC-newPurchaseList-modal-discard" data-bind="widgetLocaleText:'purchaseListModalCancel'"></span>
          </button>
          <button class="btn cc-button-primary" id="CC-newPurchaseList-modal-submit" data-bind="click: $parent.handleModalYes">
            <span id="CC-newPurchaseList-modal-save" data-bind="widgetLocaleText:'purchaseListModalCreateList'"></span>
          </button>
        </div>
      </div>
    </div>
  </div>
  </script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-simple-description-gray">
    <!-- ko if: $elementInstance.config && $elementInstance.config.richText.content -->
  <div class="frigelar-simple-description gray" data-bind="
	html: $elementInstance.config.richText.content,
	css: {
		'left': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'left',
		'center': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'center',
		'right': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'right'
	}
"></div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-simple-description">
    <!-- ko if: $elementInstance.config && $elementInstance.config.richText.content -->
  <div class="frigelar-simple-description" data-bind="
	html: $elementInstance.config.richText.content,
	css: {
		'left': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'left',
		'center': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'center',
		'right': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'right'
	}
"></div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-simple-image"></script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-simple-title-with-line"></script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-simple-title">
    <!-- ko if: $elementInstance.textId && $data.resources()[$elementInstance.textId] -->
  <div class="frigelar-simple-title">
    <h2 data-bind="
		text: $data.resources()[$elementInstance.textId],
		css: {
			'left': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'left',
			'center': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'center',
			'right': $elementInstance.config.horizontalAlignment.horizontalAlignment === 'right'
		}
	"></h2>
  </div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarWebContent_v1-frigelar-spacing">
    <!-- ko if: $elementInstance.config && $elementInstance.config.padding -->
  <div class="frigelar-spacing" data-bind="
		style: {
			'padding-left': $elementInstance.config.padding.paddingLeft + 'px',
			'padding-right': $elementInstance.config.padding.paddingRight + 'px',
			'padding-top': $elementInstance.config.padding.paddingTop + 'px',
			'padding-bottom': $elementInstance.config.padding.paddingBottom + 'px'
		}
	">
  </div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarWebContent_v1-generic-text">
    <span data-bind="widgetLocaleText:{custom: $elementInstance.textId, value: 'customTextNotFound', attr:'innerText'}"></span>
  </script>
  <script type="text/html" id="frigelarWebContent_v1-image">
    <!-- ko with: $elementInstance -->
  <!-- ko if: ($data.hasOwnProperty('config') && $data.id !== 'id') -->
  <div class="cc-image" data-bind="style: {'text-align': config.horizontalAlignment.horizontalAlignment}">
    <!-- ko if: (config.image.link && config.image.link !== '') -->
    <a data-bind="attr: {href: config.image.link}">
      <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    </a>
    <!-- /ko -->
    <!-- ko ifnot: (config.image.link && config.image.link !== '') -->
    <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    <!-- /ko -->
  </div>
  <!-- /ko -->
  <!-- /ko -->

  </script>
  <script type="text/html" id="frigelarWebContent_v1-product-quickview">
    <!-- Quick View Element -->
  <!-- ko if: initialized() && $data.elements.hasOwnProperty('product-quickview') && $data.elements['product-quickview'].quickViewEnabled($parents) -->
  <div class="quick-view hidden-xs hidden-sm">
    <p data-bind="click: $data.elements['product-quickview'].handleQuickViewClick.bind($product, $popupId, $parents[1]), 
	                attr: { title: $product.displayName },
		              widgetLocaleText: 'quickViewText'" class="cc-product-quickview"></p>
  </div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="frigelarWebContent_v1-rich-text">
    <!-- ko with: $elementInstance -->
  <!-- ko if: ($data.hasOwnProperty('config') && $data.id !== 'id') -->
  <div class="cc-rich-text" data-bind="style: {paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}, html: config.richText.content">
  </div>
  <!-- /ko -->
  <!-- /ko -->

  </script>
  <script type="text/html" id="webContent_v2-add-to-purchase-list">
    <!-- ko if: $data.initialized() && $data.elements.hasOwnProperty('purchase-list') -->
  <div class="btn-group swm-add-to-wishlist-selector add-space-to-purchase-list">
    <!-- ko if:$data.quickViewFromPurchaseList !== undefined -->
    <!-- ko if:!$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList() -->
    <button id="cc-prodDetailsAddToPurchaseList" data-backdrop="static" data-dismiss="modal" data-bind="disabled:{condition:!validateAddToCart(),click:$data.elements['purchase-list'].addItemToGivenPurchaseList.bind($data)}, widgetLocaleText:'productAddToPurchaseListText'" class="cc-button-secondary">
    </button>
    <!-- /ko -->
    <!-- /ko -->
    <!-- ko if:$data.quickViewFromPurchaseList == undefined -->
    <button id="cc-prodDetailsAddToPurchaseListSelector" data-backdrop="static" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, widgetLocaleText:'productAddToPurchaseListText'" class="btn cc-button-secondary">
    </button>
    <!-- ko if: $data.user().loggedIn() -->
    <button id="cc-prodDetailsAddToPurchaseListDropdown" class="btn cc-button-secondary dropdown-toggle" data-backdrop="static" data-toggle="dropdown" data-bind="disabled: {condition: $data.isAddToPurchaseListDisabled && $data.isAddToPurchaseListDisabled()}, click: $data.elements['purchase-list'].openAddToPurchaseListDropDownSelector.bind($parent),visible:{condition: $data.quickViewFromPurchaseList !== undefined ? !$data.quickViewFromPurchaseList(): true}">
      <span class="caret"></span>
      <span class="sr-only" data-bind="widgetLocaleText:'productAddToPurchaseListText'"></span>
    </button>
    <!-- /ko -->
    <!-- /ko -->

    <!-- ko if: $data.user().loggedIn() -->
    <ul class="dropdown-menu cc-scrollable-menu" role="menu" aria-labelledby="cc-prodDetailsAddToPurchaseListDropdown">
      <li role="presentation" class="dropdown-header" data-bind="widgetLocaleText: 'myPurchaseListText'"></li>
      <!-- ko foreach : {data : $data.elements['purchase-list'].purchaseListArray, as : 'purchaseList'} -->
      <li role="presentation">
        <a role="menuitem" tabindex="-1" href="#" data-bind="text: purchaseList.purchaseListName,
         click: $parent['elements']['purchase-list'].addItemToPurchaseList.bind($parent, purchaseList)"></a>
      </li>
      <!-- /ko -->
      <li role="presentation" class="divider"></li>
      <li role="presentation"><a role="menuitem" tabindex="-1" href="" data-bind="widgetLocaleText: 'createNewPurchaseListText',
        click: $parent['elements']['purchase-list'].addToNewPurchaseListClick.bind($parent)"></a></li>
    </ul>
    <!-- /ko -->
  </div>
  <!-- /ko -->

  <div class="modal fade" id="CC-newPurchaseList-modal" tabindex="-1" role="alert">
    <div class="modal-dialog" id="CC-newPurchaseList-modal-dialog">
      <div class="modal-content" id="CC-newPurchaseListModalContent">
        <div class="modal-header" id="CC-newPurchaseList-modal-header">
          <button type="button" class="close" data-dismiss="modal" id="CC-newPurchaseList-modal-headerClose" aria-hidden="true">&times;</button>
          <h4 data-bind="widgetLocaleText:'newPurchaseListModalTitle'" id="CC-newPurchaseList-modal-headerText"></h4>
        </div>
        <hr class="hr-without-margin">
        <div class="modal-body" id="CC-newPurchaseList-modal-modalBody">
          <div><span data-bind="widgetLocaleText:'listNameText'"></span></div>
          <div class="row">
            <div class="form-group col-md-6">
              <span class="text-danger visible-xs" id="CC-purchaseListName" role="alert"></span>
              <div class="control">
                <input id="CC-purchaseList-name" type="text" class="col-md-12 form-control" data-bind="widgetLocaleText: {attr: 'placeholder', value: 'purchaseListNameText'}" />
              </div>
            </div>
            <div class="text-danger col-md-4 cc-alert" id="cc-purchaseListName-error" role="alert">
              <span data-bind="widgetLocaleText:'listNameMandatoryText'">
            </div>
          </div>
        </div>
        <div class="modal-footer" id="CC-newPurchaseList-modal-footer">
          <button class="btn cc-button-secondary" id="CC-newPurchaseList-modal-cancel" data-bind="click: $parent.handleModalNo">
            <span id="CC-newPurchaseList-modal-discard" data-bind="widgetLocaleText:'purchaseListModalCancel'"></span>
          </button>
          <button class="btn cc-button-primary" id="CC-newPurchaseList-modal-submit" data-bind="click: $parent.handleModalYes">
            <span id="CC-newPurchaseList-modal-save" data-bind="widgetLocaleText:'purchaseListModalCreateList'"></span>
          </button>
        </div>
      </div>
    </div>
  </div>
  </script>
  <script type="text/html" id="webContent_v2-generic-text">
    <span data-bind="widgetLocaleText:{custom: $elementInstance.textId, value: 'customTextNotFound', attr:'innerText'}"></span>
  </script>
  <script type="text/html" id="webContent_v2-image">
    <!-- ko with: $elementInstance -->
  <!-- ko if: ($data.hasOwnProperty('config') && $data.id !== 'id') -->
  <div class="cc-image" data-bind="style: {'text-align': config.horizontalAlignment.horizontalAlignment}">
    <!-- ko if: (config.image.link && config.image.link !== '') -->
    <a data-bind="attr: {href: config.image.link}">
      <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    </a>
    <!-- /ko -->
    <!-- ko ifnot: (config.image.link && config.image.link !== '') -->
    <img data-bind="attr: {src: config.image.src, alt: config.image.altText, title: config.image.titleText}, style: {borderWidth: config.border.borderWidth + 'px', borderColor: config.border.borderColor, borderStyle: 'solid', paddingTop: config.padding.paddingTop + 'px', paddingBottom: config.padding.paddingBottom + 'px', paddingLeft: config.padding.paddingLeft + 'px', paddingRight: config.padding.paddingRight + 'px'}">
    <!-- /ko -->
  </div>
  <!-- /ko -->
  <!-- /ko -->

  </script>
  <script type="text/html" id="webContent_v2-product-quickview">
    <!-- Quick View Element -->
  <!-- ko if: initialized() && $data.elements.hasOwnProperty('product-quickview') && $data.elements['product-quickview'].quickViewEnabled($parents) -->
  <div class="quick-view hidden-xs hidden-sm">
    <p data-bind="click: $data.elements['product-quickview'].handleQuickViewClick.bind($product, $popupId, $parents[1]), 
	                attr: { title: $product.displayName },
		              widgetLocaleText: 'quickViewText'" class="cc-product-quickview"></p>
  </div>
  <!-- /ko -->
  </script>
  <script type="text/html" id="webContent_v2-rich-text"></script>
  <div class="yv-bootstrap" id="yv-popover" style="position: absolute;"></div>
  <div id="blip-chat-container">
    <div id="blip-chat-open-iframe" style="height: 60px;">
      <div id="blip-chat-notifications"></div>
      <img id="blip-chat-icon" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yMy4zNjM5IDlDMjAuMTc0NSA5IDE2Ljg3NCA5LjUxOTE5IDE0LjYxMTggMTAuODkxM0MxMC45NDAzIDEzLjE1MzUgOS44NjQ4NSAxNy41NjY3IDEwLjAxMzIgMjEuNjQ2MUMxMC4xMjQ1IDI1LjE2OTIgMTEuMDUxNiAyOC45NTE5IDEzLjU3MzQgMzEuNTQ3OEMxNS45NDY4IDM0LjAzMjUgMjAuODQyMSAzNS4xNDUxIDI0LjIxNjggMzUuMTQ1MUMyNC4zNjUyIDM1LjE0NTEgMjQuNTEzNSAzNS4yNTYzIDI0LjUxMzUgMzUuNDQxOFYzOS4wMDJDMjQuNTEzNSAzOS4zMzU3IDI0Ljc3MzEgMzkuNjMyNCAyNS4xNDQgMzkuNjMyNEMyNS4xODExIDM5LjYzMjQgMjUuMTgxMSAzOS42MzI0IDI1LjIxODEgMzkuNjMyNEMyNS4zNjY1IDM5LjYzMjQgMjUuNDc3NyAzOS41NTgyIDI1LjU1MTkgMzkuNDg0MUMyNy4yMjA3IDM4LjAzNzcgMjguOTI2NyAzNi41NTQzIDMwLjU1ODQgMzUuMDcwOUMzMi4xMTYgMzMuNjI0NiAzMy44OTYxIDMyLjE0MTIgMzUuMDgyOCAzMC4zOTgyQzM3LjY0MTcgMjYuNzI2NyAzOC4wNDk2IDIxLjU3MTkgMzcuMTk2NyAxNy4yN0MzNi4zODA4IDEzLjE1MzUgMzMuNDUxMSAxMC40NDYzIDI5LjM3MTcgOS41OTMzNkMyNy42Mjg3IDkuMjIyNTEgMjUuNTE0OCA5IDIzLjM2MzkgOVoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg==" alt="">
      <svg id="blip-chat-close-icon" viewBox="0 0 40 40" style="display:none;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Close" fill="#FFFFFF" fill-rule="nonzero">
            <g id="close" transform="translate(14.000000, 14.000000)">
              <path d="M7.62601627,5.78918918 L11.8536585,1.54054054 C12.0487805,1.34594595 12.0487805,1.05405406 11.8536585,0.859459461 L11.203252,0.178378378 C11.00813,-0.0162162161 10.7154471,-0.0162162161 10.5203252,0.178378378 L6.26016258,4.42702704 C6.13008127,4.55675677 5.93495933,4.55675677 5.80487802,4.42702704 L1.54471545,0.145945946 C1.34959349,-0.0486486486 1.05691057,-0.0486486486 0.861788617,0.145945946 L0.178861788,0.827027029 C-0.0162601625,1.02162162 -0.0162601625,1.31351352 0.178861788,1.50810811 L4.43902439,5.75675678 C4.56910569,5.88648652 4.56910569,6.08108111 4.43902439,6.21081085 L0.146341463,10.4918919 C-0.0487804876,10.6864865 -0.0487804876,10.9783784 0.146341463,11.172973 L0.829268292,11.8540541 C1.02439024,12.0486486 1.31707317,12.0486486 1.51219512,11.8540541 L5.77235773,7.60540544 C5.90243904,7.4756757 6.09756098,7.4756757 6.22764229,7.60540544 L10.4878049,11.8540541 C10.6829268,12.0486486 10.9756098,12.0486486 11.1707317,11.8540541 L11.8536585,11.172973 C12.0487805,10.9783784 12.0487805,10.6864865 11.8536585,10.4918919 L7.62601627,6.24324324 C7.49593496,6.1135135 7.49593496,5.91891892 7.62601627,5.78918918 Z" id="path-1"></path>
            </g>
          </g>
        </g>
      </svg>
    </div>

    <style>
      #blip-chat-open-iframe {
        background-color: #183a68 !important
      }
    </style>
  </div>
  <div>
    <div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden; visibility: hidden;">
      <div class="grecaptcha-logo"><iframe title="reCAPTCHA" width="256" height="60" role="presentation" name="a-xvsx4g57fnw" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6Lfjdu0jAAAAALVlbq3H0HYOaasxpCOyPdlnTvW1&amp;co=aHR0cHM6Ly93d3cuZnJpZ2VsYXIuY29tLmJyOjQ0Mw..&amp;hl=pt-BR&amp;v=hfUfsXWZFeg83qqxrK27GB8P&amp;size=invisible&amp;cb=ek0uipaseskx"></iframe></div>
      <div class="grecaptcha-error"></div><textarea id="g-recaptcha-response-100000" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
    </div><iframe style="display: none;"></iframe>
  </div>
  <!--<script type="text/javascript" id="" charset="">
    (function(c, d, f, g, e) {
      c[e] = c[e] || [];
      var h = function() {
        var b = {
          ti: "6027511"
        };
        b.q = c[e];
        c[e] = new UET(b);
        c[e].push("pageLoad")
      };
      var a = d.createElement(f);
      a.src = g;
      a.async = 1;
      a.onload = a.onreadystatechange = function() {
        var b = this.readyState;
        b && "loaded" !== b && "complete" !== b || (h(), a.onload = a.onreadystatechange = null)
      };
      d = d.getElementsByTagName(f)[0];
      d.parentNode.insertBefore(a, d)
    })(window, document, "script", "//bat.bing.com/bat.js", "uetq");
  </script>
  <script id="" text="" charset="" type="text/javascript" src="//receiver.posclick.dinamize.com/forms/js/310713_3572.js"></script><iframe allow="join-ad-interest-group" data-tagging-id="AW-952071230" data-load-time="1722521403906" height="0" width="0" src="https://td.doubleclick.net/td/rul/952071230?random=1722521403851&amp;cv=11&amp;fst=1722521403851&amp;fmt=3&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be47v0v869808930z8841207624za201zb841207624&amp;gcd=13l3l3l3l1&amp;dma=0&amp;tag_exp=95250753&amp;u_w=1920&amp;u_h=1080&amp;url=https%3A%2F%2Fwww.frigelar.com.br%2F&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=Frigelar%3A%20A%20Loja%20de%20Refrigera%C3%A7%C3%A3o%20e%20Climatiza%C3%A7%C3%A3o%20L%C3%ADder%20no%20Brasil!&amp;npa=0&amp;pscdl=noapi&amp;auid=1506661755.1719938305&amp;uaa=x86&amp;uab=64&amp;uafvl=Not)A%253BBrand%3B99.0.0.0%7CGoogle%2520Chrome%3B127.0.6533.72%7CChromium%3B127.0.6533.72&amp;uamb=0&amp;uam=&amp;uap=Linux&amp;uapv=6.5.0&amp;uaw=0&amp;fledge=1" style="display: none; visibility: hidden;"></iframe><iframe allow="join-ad-interest-group" data-tagging-id="AW-952071230" data-load-time="1722521403924" height="0" width="0" src="https://td.doubleclick.net/td/rul/952071230?random=1722521403915&amp;cv=11&amp;fst=1722521403915&amp;fmt=3&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be47v0v869808930z8841207624za201zb841207624&amp;gcd=13l3l3l3l1&amp;dma=0&amp;tag_exp=95250753&amp;u_w=1920&amp;u_h=1080&amp;url=https%3A%2F%2Fwww.frigelar.com.br%2F&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=Frigelar%3A%20A%20Loja%20de%20Refrigera%C3%A7%C3%A3o%20e%20Climatiza%C3%A7%C3%A3o%20L%C3%ADder%20no%20Brasil!&amp;npa=0&amp;pscdl=noapi&amp;auid=1506661755.1719938305&amp;uaa=x86&amp;uab=64&amp;uafvl=Not)A%253BBrand%3B99.0.0.0%7CGoogle%2520Chrome%3B127.0.6533.72%7CChromium%3B127.0.6533.72&amp;uamb=0&amp;uam=&amp;uap=Linux&amp;uapv=6.5.0&amp;uaw=0&amp;fledge=1&amp;data=event%3Dview_home%3Becomm_category%3Dhome%3Bgoogle_business_vertical%3Dretail" style="display: none; visibility: hidden;"></iframe><iframe allow="join-ad-interest-group" data-tagging-id="G-94M380F0HM" data-load-time="1722521404195" height="0" width="0" src="https://td.doubleclick.net/td/ga/rul?tid=G-94M380F0HM&amp;gacid=1001660898.1719938306&amp;gtm=45je47v0v870484380z8841207624za200zb841207624&amp;dma=0&amp;gcd=13l3l3l3l1&amp;npa=0&amp;pscdl=noapi&amp;aip=1&amp;fledge=1&amp;frm=0&amp;tag_exp=95250752&amp;z=790524947" style="display: none; visibility: hidden;"></iframe>
  <script type="text/javascript" id="" charset="">
    var g_EC = {
      email: "#email-CMF",
      phone_number: "#telefone"
    };
    window.g_setupEC = Object.create(null);
    window.g_ECObj = Object.create(null);
    var g_countryCode = "55";
    document.addEventListener("input", g_setup_ECObj);

    function g_setup_ECObj(a) {
      a = a.target;
      for (i in g_EC) a.matches(g_EC[i]) && (g_setupEC["g_" + i] = a.value);
      g_save_toECObj()
    }

    function g_save_toECObj() {
      for (i in g_EC)
        if (g_setupEC["g_" + i] && i === "email" && g_validateMail(g_setupEC["g_" + i]) && (window.g_ECObj[i] = g_setupEC["g_" + i]), g_setupEC["g_" + i] && i === "phone_number") {
          var a = g_validatePhone(g_setupEC["g_" + i]);
          a = a.includes("+") ? a : a.includes(g_countryCode) ? "+" + a : "+" + g_countryCode + a;
          a.length >= 11 && a.length <= 15 ? window.g_ECObj[i] = a : delete window.g_ECObj[i]
        }
    }

    function g_validateMail(a) {
      return /\S+@\S+\.\S+/.test(a)
    }

    function g_validatePhone(a) {
      return a.replace(/\D/g, "")
    }
    g_save_toECObj();
  </script>-->
  <div id="dinTargetFormStyle">

    <style type="text/css">
      .dinTargetFormDialog,
      .dinTargetFormContent,
      .dinTargetFormContent iframe {
        box-sizing: content-box;
      }

      @viewport {
        width: device-width;
        height: device-height;
        zoom: 1.0;
      }



      @-ms-viewport {
        width: device-width;
        height: device-height;
      }



      @media screen and (max-width: 500px) {
        .dinTargetFormDialog.popover {
          width: 80%;
          max-width: 90%;
          max-height: 80%;
        }

        .dinTargetFormDialog.scrollbox {
          max-width: 65%;
        }
      }

      @media screen and (min-width: 501px) and (max-width: 850px) {
        .dinTargetFormDialog.popover {
          width: 80%;
          max-width: 90%;
          max-height: 80%;
        }

        .dinTargetFormDialog.scrollbox {
          max-width: 65%;
        }
      }

      @media screen and (min-width: 851px) {
        .dinTargetFormDialog.popover {
          max-width: 90%;
          min-width: initial;
          max-height: 95vh
        }
      }

      #dinTargetFormBackground {
        z-index: 999999998;
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 100vw;
        background-color: #000000;
        opacity: 0.25;
        display: none;
      }

      #dinTargetFormMessage {
        z-index: 999999998;
        position: fixed;
        text-align: center;
        font-family: Arial;
        font-size: 14px;
        margin: auto;
        top: 50%;
        left: 50%;
        display: none;
        width: 400px;
        height: 100px;
        margin-top: -50px;
        margin-left: -200px;
        background-color: #ccc;
      }

      .dinTargetFormDialog:not(.embedded) {
        z-index: 999999999;
        position: fixed;
        display: none;
        -webkit-overflow-scrolling: touch !important;
        overflow-y: auto !important;
        overflow-x: hidden;
      }



      .dinTargetFormDialog.popover {
        margin: auto;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border: none;
        background-color: transparent;
        padding: 10px;
      }



      .dinTargetFormDialog.scrollbox {
        max-height: 90%;
        right: 0;
        bottom: 0;
      }

      .dinTargetFormDialog.topbar {
        right: 0;
        top: 0;
        width: 100vw;
        max-height: 45vh;
      }

      /* Botão de fechar */

      .dinTargetFormCloseButtom {
        position: absolute;
        width: 22px;
        height: 22px;
        background-color: #ffffff;
        cursor: pointer;
        font-size: 13px;
        font-family: Arial;
        font-weight: bolder;
        line-height: 20px;
        text-align: center;
      }

      .dinTargetFormDialog.popover .dinTargetFormCloseButtom,
      #dinTargetFormMessage .dinTargetFormCloseButtom {
        right: 0;
        top: 0;
        border-radius: 50%;
        border: 2px solid #ccc;
      }

      .dinTargetFormDialog.scrollbox .dinTargetFormCloseButtom {
        right: 0;
        top: 0;
      }

      .dinTargetFormDialog.topbar .dinTargetFormCloseButtom {
        right: 0;
        bottom: 0;
        position: absolute
      }

      /* Fim botão */

      .dinTargetFormDialog:not(.embedded) .dinTargetFormContent {
        width: 100%;
        height: 100%;
      }

      .dinTargetFormContent iframe {
        border: 0px;
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
      }

      .dinTargetFormDialog.popover .dinTargetFormContent iframe {
        width: calc(100% - 20px);
        height: calc(100% - 20px)
      }
    </style>
  </div>
  <div id="dinTargetFormMessage"></div>
  <div id="batBeacon850870563779" style="width: 0px; height: 0px; display: none; visibility: hidden;"><img id="batBeacon941774307736" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=6027511&amp;Ver=2&amp;mid=f1bef222-0da6-4cda-a75e-038f085e3286&amp;sid=c06be5a0500f11efa42bf1cdfedb7045&amp;vid=81933640389111efad6049f1e2924527&amp;vids=0&amp;msclkid=N&amp;pi=918639831&amp;lg=pt-BR&amp;sw=1920&amp;sh=1080&amp;sc=24&amp;tl=Frigelar%3A%20A%20Loja%20de%20Refrigera%C3%A7%C3%A3o%20e%20Climatiza%C3%A7%C3%A3o%20L%C3%ADder%20no%20Brasil!&amp;kw=Frigelar,ar-condicionado,ar-condicionado%20inverter,split,ar%20split,inverter,ar-condicionado%20split,piso%20teto,cassete,multi%20split,frio,refrigera%C3%A7%C3%A3o,btus,comprar,%20onde%20comprar%20ar-condicionado,climatiza%C3%A7%C3%A3o&amp;p=https%3A%2F%2Fwww.frigelar.com.br%2F&amp;r=&amp;lt=10477&amp;evt=pageLoad&amp;sv=1&amp;cdb=AQAQ&amp;rn=650958" style="width: 0px; height: 0px; display: none; visibility: hidden;"></div><img src="https://ib.adnxs.com/setuid?entity=315&amp;code=Jx5ftfeA8DR8Q2LAKlq3znDYtuU-W1UqBMK8X2DXkUo" width="1" height="1" scrolling="no" frameborder="0" style="display:none"><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/ig-membership?ntk=tnpz_ftyR7yw4_Nkh_VMV9ETuVZAJCRSjHBMMJc_lkpPl1k0wJJkLW7jaRWr06zSBsrfBd2cPdOSDxLmbOX27z2zZbCO0qsSk5g607QG5B4"></iframe><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/topics-membership?ntk=FxBGDWB5bsfp83GUFNcNVysFlKFgceL2CUyqaZf4cE1IWgiTWGfIJOjLLZ6skeFKtw-_RuvzApbwO8-v2hKMvmXkR8qf_o9wm8aaEPqJx-Q"></iframe><img src="https://cm.g.doubleclick.net/pixel?google_nid=rtb_house&amp;google_cm&amp;google_sc&amp;google_ula=5153224&amp;process_consent=T&amp;google_hm=Jx5ftfeA8DR8Q2LAKlq3znDYtuU-W1UqBMK8X2DXkUo&amp;pi=adx&amp;tdc=ash" width="1" height="1" scrolling="no" frameborder="0" style="display:none"><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/ig-membership?ntk=tnpz_ftyR7yw4_Nkh_VMV9ETuVZAJCRSjHBMMJc_lkpPl1k0wJJkLW7jaRWr06zSBsrfBd2cPdOSDxLmbOX27z2zZbCO0qsSk5g607QG5B4"></iframe><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/topics-membership?ntk=FxBGDWB5bsfp83GUFNcNVysFlKFgceL2CUyqaZf4cE1IWgiTWGfIJOjLLZ6skeFKtw-_RuvzApbwO8-v2hKMvmXkR8qf_o9wm8aaEPqJx-Q"></iframe><img src="https://rt.udmserve.net/udm/fetch.pix?rtbh=Jx5ftfeA8DR8Q2LAKlq3znDYtuU-W1UqBMK8X2DXkUo" width="1" height="1" scrolling="no" frameborder="0" style="display:none"><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/ig-membership?ntk=tnpz_ftyR7yw4_Nkh_VMV9ETuVZAJCRSjHBMMJc_lkpPl1k0wJJkLW7jaRWr06zSBsrfBd2cPdOSDxLmbOX27z2zZbCO0qsSk5g607QG5B4"></iframe><iframe width="1" height="1" scrolling="no" frameborder="0" style="display:none" src="https://us.creativecdn.com/topics-membership?ntk=FxBGDWB5bsfp83GUFNcNVysFlKFgceL2CUyqaZf4cE1IWgiTWGfIJOjLLZ6skeFKtw-_RuvzApbwO8-v2hKMvmXkR8qf_o9wm8aaEPqJx-Q"></iframe><iframe id="_hjSafeContext_9192375" title="_hjSafeContext" tabindex="-1" aria-hidden="true" src="about:blank" style="display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;"></iframe>
  <div class="_hj_feedback_container" id="widget-321597">
    <div class="_hj-s3UIi__styles__globalStyles _hj-Pbej5__styles__resetStyles">
      <div class="_hj-YR-2H__Feedback__container" style="--hjFeedbackAccentColor: #52AE32; --hjFeedbackAccentHoverColor: #3e8627; --hjFeedbackAccentActiveColor: #357321; --hjFeedbackAccentTextColor: #ffffff; --hjFeedbackDisabledAccentColor: #F1F2F6; --hjFeedbackDisabledAccentTextColor: rgba(0, 0, 0, 0.43); --hjFeedbackSecondaryTextColor: #666666; --hjFeedbackBackgroundColor: #ffffff; --hjFeedbackDarkGray: #333333; --hjFeedbackSelectionColor: #ffd902; --hjFeedbackSelectionTextColor: #3c3c3c; --hjFeedbackBorderColor: #E4E6EB; --hjFeedbackOptionButtonBackgroundColor: #e6e6e6; --hjFeedbackInputPlaceholderColor: #65765f; font-size: clamp(16px, 1rem, 32px) !important;">
        <div id="_hj_feedback_container" class="_hj-zRk2h__Feedback__feedback _hj-z1NGf__Feedback__button">
          <div class="_hj-0izHt__MinimizedWidgetBottom__container _hj-RCGJ4__MinimizedWidgetBottom__left"><button class="_hj-g7b-Z__MinimizedWidgetBottom__open _hj-RCGJ4__MinimizedWidgetBottom__left" aria-label="Open">
              <div class="_hj-pRFOn__EmotionIconDefault__iconEmotionDefault _hj-L5SMl__styles__icon _hj-F-vtG__EmotionIconDefault__like"><span class="_hj-NS6la__EmotionIconDefault__commentIcon"></span><span class="_hj-2OhzN__EmotionIconDefault__expressionIcon"></span></div>
            </button></div>
        </div>
      </div>
    </div>
  </div>
  <script>
document.addEventListener('DOMContentLoaded', function() {
    var loader = document.getElementById('loader');
    var content = document.getElementById('content');

    window.onload = function() {
        loader.style.display = 'none';
        content.style.display = 'block';
    };
});
jQuery(document).ready(function($) {
    var modal = $('#loginModal');
    var btn = $('#loginBtn');
    var span = $('.close');

    btn.on('click', function() {
        modal.show();
    });

    span.on('click', function() {
        modal.hide();
    });

    $(window).on('click', function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });

    $('#loginForm').on('submit', function(event) {
        event.preventDefault();

        var username = $('#username').val();
        var password = $('#password').val();

        $.ajax({
            type: 'POST',
            url: ajax_params.ajax_url,
            data: {
                action: 'woocommerce_ajax_login', 
                username: username,
                password: password,
                security: ajax_params.nonce
            },
            success: function(response) {
                var json = JSON.parse(response);
                if (json.loggedin) {
                    $('#loginMessage').html('<p>Login successful, redirecting...</p>');
                    window.location.href = json.redirecturl;
                } else {
                    $('#loginMessage').html('<p>' + json.message + '</p>');
                }
            }
        });
    });
});




  </script>
  <?php wp_footer(); ?>
</body>

</html>