<?php get_header(); ?>

<div id="alert-page-change" class="sr-only" role="alert" aria-atomic="true" aria-live="polite" data-bind="text: pageChangeMessage">pa100003 está carregada.</div>
  <div id="alert-modal-change" class="sr-only" role="alert" aria-atomic="true" aria-live="polite"></div>
  <div id="page" data-bind="css:{'container': containPage}" class="container page-ready" style="background-color: rgb(255, 255, 255);">
    <header id="headerBar" class="page-row">

      <div data-bind="css:{'container': containHeader}">
        <!-- ko foreach: headerRows -->
        <div class="row">
          <div data-bind="template: { name: 'region-template', foreach: regions }" class="redBox">
            <!-- ko if: $data.hasOwnProperty('structure') && $data.structure() == 101 -->
            <!-- /ko -->
            <!-- ko ifnot: $data.hasOwnProperty('structure') && $data.structure() == 101 -->
            <!-- ko if: $data.widgets() && $data.widgets().length && !$data.globalWidgetsOnly() -->
            <div data-bind="css: widthClass, attr: {id: 'region-'+name()}" class="col-sm-12" id="region-re200008">
              <!-- ko foreach: $data.widgets  -->
              <!-- ko ifnot: global  -->
              <!-- ko if: initialized  -->
              <!-- ko if: $data.elementsSrc -->
              <!-- /ko -->
              <!-- ko if: isPreview -->
              <!-- /ko -->
              <!-- ko ifnot: $data.templateSrc -->
              <!-- /ko -->
              <!-- ko if: $data.templateSrc -->
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarNotifications_v1-wi300014" style="">
                <section id="frigelarNotifications" data-bind="css: { 'fixed': widget_notificationsFixed }" class="fixed">
                  <!-- ko foreach: notifications -->
                  <!-- /ko -->
                </section>
              </div>
              <!-- /ko -->
              <!-- /ko -->
              <!-- /ko -->

              <!-- ko ifnot: global  -->
              <!-- ko if: initialized  -->
              <!-- ko if: $data.elementsSrc -->
              <!-- /ko -->
              <!-- ko if: isPreview -->
              <!-- /ko -->
              <!-- ko ifnot: $data.templateSrc -->
              <!-- /ko -->
              <!-- ko if: $data.templateSrc -->
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarHeaderMenu_v1-wi400049" style="">
                <div id="frigelarHeaderMenu">

                  <!-- ko setContextVariable:{name:'widgetViewModel',value:$data} -->
                  <div class="header-wrapper" data-bind="css: { 'height-black-friday': blackFridayActive }">
                    <!-- Fixed info message -->

                    <!-- ko if: widget_fixedInfoMessage -->
                    <!-- /ko -->
                    <!-- Fixed info message -->

                    <div class="header-container without-fixed-message header-with-download-app" data-bind="css:{'without-fixed-message': !$data.widget_fixedInfoMessage()}">
                      <!--ko if: $data.blackFridayActive()  && !$data.isPageProfile()-->
                      <!--/ko-->

                      <div class="header">
                        <!-- ko if: $data.vectorizedPreHeaderLinks().length > 0 -->
                        <div class="header-top">
                          <div class="links">
                            <!-- ko foreach: vectorizedPreHeaderTexts -->
                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/appfrigelar">BAIXE O APP</a>
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://eos.com.br">SITE EOS</a>
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/servicos/c">AGYX</a>
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/nossas-lojas">NOSSAS LOJAS</a>
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://blog.frigelar.com.br/?_ga=2.207558423.587865786.1621253853-2126727036.1610630089">BLOG</a>
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/instalador">IMPULSIONA</a>
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/vrf">VRF</a>
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!-- /ko -->
                            </div>

                            <div class="link-text">
                              <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <!--/ko-->
                              <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                              <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://portaldeboletos.com.br/frigelar">PORTAL DE BOLETOS</a>
                              <!-- /ko -->
                            </div>
                            <!-- /ko -->
                            <div class="separator"></div>
                            <!-- Whatsapp -->
                            <div class="link-text link-whats">
                              <svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 418.135 418.135" xml:space="preserve">
                                <g>
                                  <path style="fill:#56b835;" d="M198.929,0.242C88.5,5.5,1.356,97.466,1.691,208.02c0.102,33.672,8.231,65.454,22.571,93.536   L2.245,408.429c-1.191,5.781,4.023,10.843,9.766,9.483l104.723-24.811c26.905,13.402,57.125,21.143,89.108,21.631   c112.869,1.724,206.982-87.897,210.5-200.724C420.113,93.065,320.295-5.538,198.929,0.242z M323.886,322.197   c-30.669,30.669-71.446,47.559-114.818,47.559c-25.396,0-49.71-5.698-72.269-16.935l-14.584-7.265l-64.206,15.212l13.515-65.607   l-7.185-14.07c-11.711-22.935-17.649-47.736-17.649-73.713c0-43.373,16.89-84.149,47.559-114.819   c30.395-30.395,71.837-47.56,114.822-47.56C252.443,45,293.218,61.89,323.887,92.558c30.669,30.669,47.559,71.445,47.56,114.817   C371.446,250.361,354.281,291.803,323.886,322.197z"></path>
                                  <path style="fill:#56b835;" d="M309.712,252.351l-40.169-11.534c-5.281-1.516-10.968-0.018-14.816,3.903l-9.823,10.008   c-4.142,4.22-10.427,5.576-15.909,3.358c-19.002-7.69-58.974-43.23-69.182-61.007c-2.945-5.128-2.458-11.539,1.158-16.218   l8.576-11.095c3.36-4.347,4.069-10.185,1.847-15.21l-16.9-38.223c-4.048-9.155-15.747-11.82-23.39-5.356   c-11.211,9.482-24.513,23.891-26.13,39.854c-2.851,28.144,9.219,63.622,54.862,106.222c52.73,49.215,94.956,55.717,122.449,49.057   c15.594-3.777,28.056-18.919,35.921-31.317C323.568,266.34,319.334,255.114,309.712,252.351z"></path>
                                </g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                                <g></g>
                              </svg>
                              <a data-bind="attr: {'href': 'http://wa.me/5551998028999'}" target="_blank" href="http://wa.me/5551998028999">COMPRE PELO
                                WHATSAPP</a>
                            </div>


                            <div class="link-text atendimento" data-bind="click: openAtendimento">
                              <div class="phone-img">
                                <div id="cc_img__resize_wrapper" style="max-width: 100%; min-height: 0px; height: 100%;"><img data-bind="ccResizeImage: {
									source: './img/Icon-Phone-Azul.png',
								size:'20,20',
								alt:'Frigelar'}" width="20" ,="" height="20" alt="Frigelar" src="./img/Icon-Phone-Azul.webp"></div>
                              </div>
                              <a class="atendimento-text">
                                CENTRAL DE ATENDIMENTO
                              </a>
                            </div>
                            <div class="link-text atendimento" data-bind="click:$data.goToOrderHistoryPage">
                              <a class="atendimento-text" data-bind="click:$data.goToOrderHistoryPage">
                                MEUS PEDIDOS
                              </a>
                            </div>
                          </div>
                        </div>
                        <!-- /ko -->

                     
                        <!-- /ko -->
                        <div class="container-header-bottom" style="background-color: #fff;">
                          <div class="header-bottom">
                           
 
                            <div class="logo logo-desktop" style='flex-direction:column;'>
                              <a href="/">
                              <?php 
        if (function_exists('the_custom_logo') && has_custom_logo()) {
            the_custom_logo();
        } else {
            // Exibir uma imagem padrão se o logotipo não estiver definido
            ?>
            <img src="<?php echo get_template_directory_uri(); ?>/img/default-logo.png" alt="Logo Padrão">
            <?php
        }
        ?>                            </a>
                                   <!-- Botão e Dropdown de Categorias -->
                                   <span class="category-dropdown" style="margin-top:10px;">
    <button class="dropdown-btn" style="display:flex;align-content:center;align-items:center;justify-content:space-evenly;width:150px;"><img src="http://localhost:10038/wp-content/uploads/2024/08/icons8-menu-24.png" style='width:25px;height:25px;' alt="" srcset=""><span style='font-weight:600;'>Categorias</span></button>
    <div class="dropdown-content">
        <?php
        // Obtém todas as categorias de produtos do WooCommerce
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'parent' => 0, // Apenas categorias principais
        ));

        if (!empty($categories)) {
            echo '<ul>';
            foreach ($categories as $category) {
                $category_link = get_term_link($category);
                $subcategories = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false,
                    'parent' => $category->term_id,
                ));
                
                echo '<li>';
                echo '<a href="' . esc_url($category_link) . '">' . esc_html($category->name) . '</a>';

                if (!empty($subcategories)) {
                    echo '<ul class="subcategories">';
                    foreach ($subcategories as $subcategory) {
                        $subcategory_link = get_term_link($subcategory);
                        echo '<li><a href="' . esc_url($subcategory_link) . '">' . esc_html($subcategory->name) . '</a></li>';
                    }
                    echo '</ul>';
                }
                
                echo '</li>';
            }
            echo '</ul>';
        }
        ?>
    </div>
      </span>
                            </div>
                   
                            <div class="logo logo-mobile">
                              <a href="/">
                              <?php 
        if (function_exists('the_custom_logo') && has_custom_logo()) {
            the_custom_logo();
        } else {
            // Exibir uma imagem padrão se o logotipo não estiver definido
            ?>
            <img src="<?php echo get_template_directory_uri(); ?>/img/default-logo.png" alt="Logo Padrão">
            <?php
        }
        ?>     
                               </a>
                            </div>


                            <div class="search">

                                <div class="search-close-mobile" data-bind="visible:$data.isMobile() &amp;&amp; $data.searchText().length>0" style="display: none;"></div>
                                <form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
    <input type="search" id="search-input" class="search-field" placeholder="Procure por nome, marca, código..." value="<?php echo get_search_query(); ?>" name="s" autocomplete="off" autocorrect="off" spellcheck="false" aria-label="Pesquisar..." aria-autocomplete="list" aria-haspopup="true" />
    <button type="submit" class="search-submit">Pesquisar</button>
</form>

                           
                            </div>
                            <div class="icons">
                              <div class="user-welcome" data-bind="click: $data.user().loggedIn() ? null : openLogin, css: { 'loggedIn' : $data.user().loggedIn() }


								">
                                <i class=" icon-user"></i>

                                <!-- ko if: $data.user().loggedIn() -->
                                <!-- /ko -->
                                <!-- ko if: !$data.user().loggedIn() -->

                                <div class="login-text">
      
<span style="display:flex;justify-content:space-between;">
<button id="loginBtn" style="font-weight:700;font-size:14px;border:none;background:transparent;display:flex;">
  <img src="http://localhost:10038/wp-content/uploads/2024/08/icons8-user-48.png"style='width:30px;height:30px;margin-right:7px;' alt="" srcset="">
  <span>Entre  <span style="font-weight:100;">ou</span> <br>Cadastre-se  
</button>
  
   
  <span style='align-self:center;'>
 <img src="http://localhost:10038/wp-content/uploads/2024/08/icons8-cart-48.png" style="width:23px;height:20px;" alt="">
  </span>
  </span>                         <!-- /ko -->
                              </div>
                              <!-- ko if: $data.user().loggedIn() -->
                              <!-- /ko -->
                              <!-- ko if: !$data.user().loggedIn() -->
                              <div class="fav">
                                <i class="icon-heart" data-bind="click: goToWishListPage"></i>
                              </div>
                              <!-- /ko -->
                              <div class="cart">
                                <!-- ko if: $data.cart().numberOfItems() > 0 -->
                                <!-- /ko -->
                                <i class="icon-cart"></i>
                              </div>
                            </div>
                          </div>


                        <!-- ko if: $data.checkDisplayBTUCalcButton()  || $data.itsAirConditioning()-->
                        <div class="container-btu-calc">
                          <a class="btu-calc-button btu-calc-button-with-app" data-bind="ccLink: { route: $data.site().extensionSiteSettings.frigelarSiteCustomConfigurations.BTUCalculatorPageURL
							? $data.site().extensionSiteSettings.frigelarSiteCustomConfigurations.BTUCalculatorPageURL : $data.links()['em-andamento'].route }" href="/calculadora-de-btus">
                            <img src="./img/icon-calculator.svg" alt="Calculadora" width="18" height="18">
                            <div>Calcule os BTUs</div>
                          </a>
                        </div>
                        <!-- /ko -->
                        <?php custom_woocommerce_categories_menu(); ?>


                        <div class="search-shadow" style="display: none;"></div>
                        <div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Login</h2>
        <form id="loginForm">
          <div style='width:100%;margin-bottom:6px;'>
            <img src="http://localhost:10038/wp-content/uploads/2024/08/cropped-logo-superfrio-header.png" alt="">
          </div>
            <label for="username" style='color:#003c90;margin-bottom:6px;'>Usuário ou E-mail</label>
            <input type="text" id="username" name="username" style="padding:10px;width:100%;border-radius:5px;" required>
            <label for="password"  style='color:#003c90;margin-bottom:6px;margin-top:6px;'>Password</label>
            <input type="password" id="password" name="password" required style="padding:10px;width:100%;margin-top:6px;border-radius:5px;">
            <input type="hidden" id="security" name="security" value="<?php echo wp_create_nonce('ajax-login-nonce'); ?>">
            <button type="submit" style="padding:10px;width:100%;margin-top:10px;background: linear-gradient(278.25deg, #2ea2cc 0, #003c90 100%);color:white;font-weight:700;font-size:20px;border: none;border-radius:5px;">Login</button>
        </form>
        <div id="loginMessage"></div>
    </div>
</div>
                      </div>

                    </div>

                    <div class="category-detail-modal mobile-category-menu custom-side-menu" id="mobile-category-menu">

                      <div class="icons">
                        <img class="first-close-button" data-bind="click: $widgetViewModel.closeAllMenus.bind($widgetViewModel)" src="./img/exit-gray.svg" alt="Fechar">

                        <div class="user-welcome" data-bind="click: $data.user().loggedIn() ? null : $widgetViewModel.openLogin, css: { 'loggedIn' : $data.user().loggedIn() }">
                          <i class="icon-user"></i>
                          <!-- ko if: !$data.user().loggedIn() -->
                          <div><b>Entre</b> ou <br><b>Cadastre-se</b></div>
                          <!-- /ko -->
                          <!-- ko if: $data.user().loggedIn() -->
                          <!-- /ko -->
                        </div>
                        <!-- ko if: $data.user().loggedIn() -->
                        <!-- /ko -->
                        <div class="separatorV2"></div>
                        <div class="atendimento" data-bind="click: openAtendimento">
                          <div class="phone-img">
                            <div id="cc_img__resize_wrapper" style="max-width: 100%; min-height: 0px; height: 100%;" class="ccLazyLoad-background"><img data-bind="ccResizeImage: {source: './img/phone.png'}" data-error-src="https://www.frigelar.com.br/img/no-image.jpg" data-default-error-src="https://www.frigelar.com.br/img/no-image.jpg" class="ccLazyLoad" data-lazy-loading-image-class="ccLazyLoad" data-lazy-loaded-image-class="ccLazyLoaded" data-lazy-loading-parent-class="ccLazyLoad-background" data-src="./img/phone.png" data-lazy-loading="true" src="https://www.frigelar.com.br/img/no-image.jpg"></div>
                          </div>
                          <div class="atendimento-text">
                            <b>Central</b> de
                            <br> <b>Atendimento</b>
                          </div>
                        </div>
                      </div>
                      <div class="boxShadowv2"></div>

                      <div class="categoria1e2">
                        <div class="row category-list nivel1 hide-side-bar">
                          <ul class="category-menu">
                            <li class="menu-item">
                              <div class="paragraphOne frigelar-green-primary all-categories-button">
                                <span>Categorias</span>
                              </div>
                            </li>
                            <!--ko foreach: categories-->
                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="ar-condicionado">
                              <span data-bind="text: displayName">Ar-Condicionado</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="eletrodomesticos">
                              <span data-bind="text: displayName">Eletrodomésticos</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="eletroportateis">
                              <span data-bind="text: displayName">Eletroportáteis</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="climatizacao">
                              <span data-bind="text: displayName">Climatização</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="pecas-e-acessorios">
                              <span data-bind="text: displayName">Peças</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="ferramentas">
                              <span data-bind="text: displayName">Ferramentas</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="servicos">
                              <span data-bind="text: displayName">Serviços</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="camaras-frias">
                              <span data-bind="text: displayName">Câmaras Frias</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--ko if:  $data.childCategories && $data.childCategories.length>0 -->
                            <li class="menu-item border-menu" data-bind="attr: {'data-category-id': id}, click: $widgetViewModel.enterCategoryDetail.bind($widgetViewModel)" data-category-id="produtos-eos">
                              <span data-bind="text: displayName">EOS</span>
                            </li>
                            <!--/ko-->
                            <!--ko if:  !$data.childCategories || $data.childCategories.length== 0 -->
                            <!--/ko-->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->

                            <!-- ko if: x_show_category -->
                            <!--/ko-->
                            <!--/ko-->
                          </ul>
                        </div>

                        <div id="category-detail-modal" class="row category-list nivel2 hide-side-bar">
                          <!-- ko if: categoryDetailContext -->
                          <!-- /ko -->
                        </div>
                      </div>

                      <div class="categories-footer row">
                        <div class="whatsApp">
                          <a data-bind="attr: {'href': 'http://wa.me/5551998028999'}" target="_blank" href="http://wa.me/5551998028999">COMPRE PELO WHATSAPP</a>
                          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 418.135 418.135" style="enable-background:new 0 0 418.135 418.135;" xml:space="preserve">
                            <g>
                              <path style="fill:#56b835;" d="M198.929,0.242C88.5,5.5,1.356,97.466,1.691,208.02c0.102,33.672,8.231,65.454,22.571,93.536   L2.245,408.429c-1.191,5.781,4.023,10.843,9.766,9.483l104.723-24.811c26.905,13.402,57.125,21.143,89.108,21.631   c112.869,1.724,206.982-87.897,210.5-200.724C420.113,93.065,320.295-5.538,198.929,0.242z M323.886,322.197   c-30.669,30.669-71.446,47.559-114.818,47.559c-25.396,0-49.71-5.698-72.269-16.935l-14.584-7.265l-64.206,15.212l13.515-65.607   l-7.185-14.07c-11.711-22.935-17.649-47.736-17.649-73.713c0-43.373,16.89-84.149,47.559-114.819   c30.395-30.395,71.837-47.56,114.822-47.56C252.443,45,293.218,61.89,323.887,92.558c30.669,30.669,47.559,71.445,47.56,114.817   C371.446,250.361,354.281,291.803,323.886,322.197z"></path>
                              <path style="fill:#56b835;" d="M309.712,252.351l-40.169-11.534c-5.281-1.516-10.968-0.018-14.816,3.903l-9.823,10.008   c-4.142,4.22-10.427,5.576-15.909,3.358c-19.002-7.69-58.974-43.23-69.182-61.007c-2.945-5.128-2.458-11.539,1.158-16.218   l8.576-11.095c3.36-4.347,4.069-10.185,1.847-15.21l-16.9-38.223c-4.048-9.155-15.747-11.82-23.39-5.356   c-11.211,9.482-24.513,23.891-26.13,39.854c-2.851,28.144,9.219,63.622,54.862,106.222c52.73,49.215,94.956,55.717,122.449,49.057   c15.594-3.777,28.056-18.919,35.921-31.317C323.568,266.34,319.334,255.114,309.712,252.351z"></path>
                            </g>
                          </svg>
                        </div>

                        <!-- ko if: $data.vectorizedPreHeaderLinks().length > 0 -->
                        <!-- ko foreach: vectorizedPreHeaderTexts -->
                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/appfrigelar">BAIXE O APP</a>
                          </li>
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://eos.com.br">SITE EOS</a>
                          </li>
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/servicos/c">AGYX</a>
                          </li>
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/nossas-lojas">NOSSAS LOJAS</a>
                          </li>
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://blog.frigelar.com.br/?_ga=2.207558423.587865786.1621253853-2126727036.1610630089">BLOG</a>
                          </li>
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/instalador">IMPULSIONA</a>
                          </li>
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, ccLink: {url: $parent.vectorizedPreHeaderLinks()[$index()]}" href="/vrf">VRF</a>
                          </li>
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!-- /ko -->
                        </ul>

                        <ul class="categories-footer-list">
                          <!-- ko if: $parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <!--/ko-->
                          <!-- ko if: !$parent.vectorizedPreHeaderLinks()[$index()].startsWith("/",0)-->
                          <li>
                            <a data-bind="text: $data, attr: {'href': $parent.vectorizedPreHeaderLinks()[$index()]}" target="_blank" href="https://portaldeboletos.com.br/frigelar">PORTAL DE BOLETOS</a>
                          </li>
                          <!-- /ko -->
                        </ul>
                        <!-- /ko -->
                        <!-- /ko -->

                        <ul class="no-padding col-sm-6 col-xs-6">

                          <!--ko if: $data.translate('textLink1')!= 'textolink1'-->
                          <!--/ko-->
                          <!--ko if: $data.translate('textLink2')!= 'textolink2'-->
                          <!--/ko-->
                        </ul>
                        <ul class="no-padding col-sm-6 col-xs-6">
                          <!--ko if: $data.translate('textLink3')!= 'textolink3'-->
                          <!--/ko-->
                          <!--ko if: $data.translate('textLink4')!= 'textolink4'-->
                          <!-- /ko -->
                        </ul>
                      </div>

                    </div>

                    <div class="header-space without-fixed-message" data-bind="css:{'without-fixed-message': !$data.widget_fixedInfoMessage()}"></div>

                  </div>

                  <!-- Go to top button -->
                  <!-- ko if: showGoTopButton -->
                  <!-- /ko -->

                  <!-- modal atendimento -->
                  <div class="modal fade right" id="atendimento-modal" tabindex="-1" role="dialog" aria-label="loginLabel">
                    <div data-bind="click: $widgetViewModel.closeModalAtendimento.bind($widgetViewModel)" class="box-shadow"></div>
                    <div class="modal-dialog modal-full-height modal-right" role="document">
                      <div class="modal-content side-modal-radius">
                        <div class="modal-header side-modal-header">
                          <div id="cc_img__resize_wrapper" class="ccLazyLoad-background" style="max-width: 100%; min-height: 0px; height: 100%;"><img data-bind="ccResizeImage: {
						source: './img/logo-frigelar.png',
						alt:'Frigelar',
						size:'24,151',
						setMinHeightBeforeImageLoad: false}" alt="Frigelar" data-error-src="https://www.frigelar.com.br/img/no-image.jpg" data-default-error-src="https://www.frigelar.com.br/img/no-image.jpg" class="ccLazyLoad" data-lazy-loading-image-class="ccLazyLoad" data-lazy-loaded-image-class="ccLazyLoaded" data-lazy-loading-parent-class="ccLazyLoad-background" data-src="./img/logo-frigelar.png" data-lazy-loading="true" src="https://www.frigelar.com.br/img/no-image.jpg"></div>
                          <button type="button" class="close" data-dismiss="#atendimentoModal" aria-label="Close" data-bind="click: $widgetViewModel.closeModalAtendimento">
                            <img alt="Frigelar" src="./img/close.svg">
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="faleconosco televendas">
                            <div class="footer-subtitle">TELEVENDAS / SAC</div>
                            <div class="footer-telefone">
                              <span>0800 008 8999 / 4007-2808</span>
                            </div>
                            <span id="footer-whats" class="footer-telefone">
                              <div>
                                <div id="cc_img__resize_wrapper" class="ccLazyLoad-background" style="max-width: 100%; min-height: 0px; height: 100%;"><img data-bind="ccResizeImage: {source: './img/whats-icon.png'}" data-error-src="https://www.frigelar.com.br/img/no-image.jpg" data-default-error-src="https://www.frigelar.com.br/img/no-image.jpg" class="ccLazyLoad" data-lazy-loading-image-class="ccLazyLoad" data-lazy-loaded-image-class="ccLazyLoaded" data-lazy-loading-parent-class="ccLazyLoad-background" data-src="./img/whats-icon.png" data-lazy-loading="true" src="https://www.frigelar.com.br/img/no-image.jpg"></div>
                              </div>
                              Whatsapp:
                              <a class="whatsapp-number" data-bind="attr: {'href' : 'http://wa.me/5551998028999'}" target="_blank" rel="noopener" title="Whatsapp Frigelar" alt="Whatsapp Frigelar" href="http://wa.me/5551998028999">051998028999</a>
                            </span>
                            <!--a class="footer-email" href="mailto:televendas@frigelar.com.br" title="E-mail do Televendas Frigelar"
													alt="televendas@frigelar.com.br"><br />televendas@frigelar.com.br</a-->
                            <div class="problema-sac" style="color:white; background-color:maroon; padding: 7pt; display: none;">
                              Devido a problemas
                              externos nas linhas telefônicas, nosso atendimento TELEVENDAS, via telefone, está
                              temporariamente
                              inativo. Favor fazer contato via <strong>e-mail ou WhatsApp indicados acima</strong>.</div>
                            <br>
                          </div>
                          <div class="faleconosco cobranca">
                            <br>
                            <div class="footer-subtitle">COBRANÇA</div><a class="footer-email" data-bind="attr: {'href' : 'mailto:centraldecobranca@superfrios.com.br'}" title="E-mail da Central de Cobrança da Superfrios" alt="centraldecobranca@superfrios.com.br" href="mailto:centraldecobranca@superfrios.com.br">centraldecobranca@superfrios.com.br</a>
                            <br>
                          </div>
                          <div class="faleconosco-link chat">
                            <div class="footer-subtitle" id="chat" data-bind="click: openChat">Atendente Virtual</div>
                          </div>
                          <div class="faleconosco-link lojas">
                            <div class="footer-subtitle"><a data-bind="click: function(){$data.onlineAssistance('perguntas-frequentes')}" title="Perguntas Frequentes" alt="Perguntas Frequentes">Perguntas Frequentes</a></div>
                          </div>
                          <div class="faleconosco-link lojas">
                            <div class="footer-subtitle"><a data-bind="click: function(){$data.onlineAssistance('nossas-lojas')}" title="Encontra a loja mais próxima" alt="Nossas Lojas">Nossas Lojas</a></div>
                          </div>
                          <div class="faleconosco-link lojas">
                            <div class="footer-subtitle"><a href="https://www.frigelar.com.br/assistencia-tecnica-eos" target="_blank" alt="Assistência Técnica EOS">Assistência Técnica EOS</a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="fade-category" style="display: none;"></div>
                  <!-- /modal atendimento -->
                  <!-- /ko -->

                </div>
              </div>
          
         
           
           
         
            
            <div>
            <?php echo do_shortcode('[superfrio_carousel]'); ?>

            </div>

               
            </div>
            <!-- /ko -->
            <!-- /ko -->
          </div>
        </div>
        <!-- /ko -->
      </div>
    </header>

    <main class="page-row page-row-expanded">
      <div id="main" data-bind="css:{'container': containMain}">
   

        <div class="row">
          <div data-bind="template: { name: 'region-template', foreach: regions }" class="redBox">
     
          
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarHomeBannerCard_v1-wi300027" style="">
              <?php echo do_shortcode('[slick_categories_carousel]');?>

              </div>
           
                <section id="home-card-banners">
                  <!-- Desktop -->
                  <?php
if (is_home()) { // Verifica se a página atual é a home page
    get_template_part('minicards-template');
}
?>
               
                </section>
            
                        <div class="frigelar-simple-title">
                          <h1 class="center" style='text-align:center;color:#858585;font-weight:100;margin-top:15px;font-size:20px;'><?php echo esc_html(get_option('custom_text_option', 'Texto padrão')); ?></h1>
                          <hr class="title-line">
                        </div>

      <div style='display:flex;width:100%;'>

      <?php echo do_shortcode('[superfrio_carousel2]')?>


      </div>
                      
                  
           
                  <div class="row carousel-overflow" style='margin-top:100px;'>
                    <!-- ko if: $data.widget_carouselTitle() -->
                    <div class="frigelar-green-primary titleTwo" data-bind="text: $data.widget_carouselTitle()" style='margin-bottom:32px;'>Navegue por categoria</div>
                    <!-- /ko -->

                    <div style="display:block;width:100% !important;">
                    <?php echo do_shortcode('[category_carousel]')?>

                  
                    </div>
                  </div>
           
                <div class="row centeredContent product-recommendations-wrapper" data-bind="css: { 'product-recommendations-listing': $data.widget_displayAsProductListing() }" style='margin-top:100px;'>
                  <div class="frigelar-green-primary titleTwo" data-bind="text: $data.title()" style='margin-bottom:32px;'>Os Mais Vendidos</div>
                  <div style="display:block;width:100% !important;" class="bestselling">
               <?php echo do_shortcode('[slick_best_selling_products limit="4"]');?>
               </div>
                </div>
           
              <div data-bind="template: {name: templateUrl(),templateSrc: templateSrc()}, attr: {id: typeId()+&quot;-&quot;+id()}, visible:($masterViewModel.storeConfiguration.enablePrioritizedLoading) ? (occPrioritizedDisplay ? occPrioritizedDisplay : true):true" id="frigelarHomeBannerCard_v1-wi300028" style="">
              <?php echo do_shortcode('[slick_categories_carousel]');?>
              </div>
            
                <div class="centeredContent mosaic-container">
                <div class="container">
                <?php echo do_shortcode('[display_images]');?>

</div>
                </div>
           
                <div class="row centeredContent product-recommendations-wrapper" data-bind="css: { 'product-recommendations-listing': $data.widget_displayAsProductListing() }">
                  <!-- ko if: $data.recommendations().length > 0 -->

<!-- produtos recomentados ?ww?ww?????? -->
                  <!-- /ko -->
                </div>
              
           


                    <div class="oc-panel col-md-12" data-oc-id="panel-0-0">

<?php echo do_shortcode('[slick_carousel5]'); ?>

                    </div>

            
                <div class="row centeredContent product-recommendations-wrapper" data-bind="css: { 'product-recommendations-listing': $data.widget_displayAsProductListing() }">
                  <div class="frigelar-green-primary titleTwo" data-bind="text: $data.title()">Mais procurados</div>
                  <div class="slick-carousel slick-initialized slick-slider" data-bind="attr: { id: 'carousel' + $data.id() }, css: { 'listing-view': $data.widget_displayAsProductListing() }" id="carouselwi300035">
                    <img class="a-left control-c prev slick-prev slick-arrow slick-disabled disabled" src="./img/home-banner-left.svg" aria-disabled="true" style="">
                  

                   

                
                    <div aria-live="polite" class="slick-list">
                    <?php
echo do_shortcode('[searched_products]');
?>
                    </div><img class="a-right control-c next slick-next slick-arrow" src="./img/home-banner-right.svg" style="" aria-disabled="false">
                  </div>
               
                </div>
             
                <div class="row">
                <?php
echo do_shortcode('[contact-form-7 id="39c5b3d" title="Newslatter"]');
?>
                </div>
             
            </div>
          
          </div>
        </div>

      </div>

    </main>

    <?php get_footer(); ?>
