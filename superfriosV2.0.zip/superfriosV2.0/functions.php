<?php
function superfrio() {
    // Registrar e enfileirar o arquivo CSS principal
    wp_enqueue_style('superfrio-style', get_stylesheet_uri(), array(), filemtime(get_template_directory() . '/style.css'));

    // Registrar e enfileirar arquivos CSS adicionais
    wp_enqueue_style('custom-css', get_template_directory_uri() . '/css/style.css');
    wp_enqueue_style('base-css', get_template_directory_uri() . '/css/base.css');
    wp_enqueue_style('common-css', get_template_directory_uri() . '/css/common.css');
    wp_enqueue_style('icons-css', get_template_directory_uri() . '/css/icons.css');
    wp_enqueue_style('reviews-css', get_template_directory_uri() . '/css/reviews.css');
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/css/bootstrap.min.css');
    wp_enqueue_style('fontawesome-css', get_template_directory_uri() . '/css/font-awesome.min.css');

    wp_enqueue_style('font-woff2', get_template_directory_uri() . '/fonts/JTURjIg1_i6t8kCHKm45_cJD3gnD_g.woff2');
    wp_enqueue_style('font2-woff2', get_template_directory_uri() . '/fonts/JTURjIg1_i6t8kCHKm45_dJE3gnD_g.woff2');
    wp_enqueue_style('font3-woff2', get_template_directory_uri() . '/fonts/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2');
    wp_enqueue_style('font4-woff2', get_template_directory_uri() . '/fonts/JTURjIg1_i6t8kCHKm45_epG3gnD_g.woff2');


    wp_enqueue_style('slick-carousel-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css');
    wp_enqueue_style('slick-carousel-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css');
    wp_enqueue_script('jquery');

    // Registrar e enfileirar arquivos JS
    wp_enqueue_script('slick-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js', array('jquery'), null, true);
    wp_enqueue_script('custom-carousel-js', get_template_directory_uri() . '/js/custom-carousel.js', array('jquery', 'slick-carousel-js'), null, true);
}
add_action('wp_enqueue_scripts', 'superfrio');

function superfrio_setup() {
    // Suporte para Imagens Destacadas
    add_theme_support('post-thumbnails');

    // Suporte para Título do Documento
    add_theme_support('title-tag');

    // Suporte para Logotipo Customizado
    add_theme_support('custom-logo');

    // Suporte para Menus Customizados
    add_theme_support('menus');

    // Suporte para HTML5
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

    // Suporte para Imagem de Fundo Customizada
    add_theme_support('custom-background');

    // Suporte para Cabeçalho Customizado
    add_theme_support('custom-header');

    // Suporte para Formatos de Post
    add_theme_support('post-formats', array('aside', 'image', 'video', 'quote', 'link'));

    // Suporte para WooCommerce
    add_theme_support('woocommerce');

    // Suporte para Editor de Estilos (Gutenberg)
    add_theme_support('editor-styles');
    add_editor_style('editor-style.css');

    // Suporte para RSS Feeds Automáticos
    add_theme_support('automatic-feed-links');

    // Suporte para Alinhamento Largo e Completo no Gutenberg
    add_theme_support('align-wide');

    add_theme_support('woocommerce');

    // Suporte para Cor de Fundo Customizada no Editor de Blocos
    add_theme_support('editor-color-palette', array(
        array(
            'name' => 'Primary',
            'slug' => 'primary',
            'color' => '#0073AA',
        ),
        array(
            'name' => 'Secondary',
            'slug' => 'secondary',
            'color' => '#005075',
        ),
    ));

    // Suporte para Tamanhos de Fonte Customizados no Editor de Blocos
    add_theme_support('editor-font-sizes', array(
        array(
            'name' => 'Small',
            'size' => 12,
            'slug' => 'small',
        ),
        array(
            'name' => 'Regular',
            'size' => 16,
            'slug' => 'regular',
        ),
        array(
            'name' => 'Large',
            'size' => 36,
            'slug' => 'large',
        ),
    ));

    // Suporte para Logos Customizados
    add_theme_support('custom-logo', array(
        'height' => 100,
        'width' => 400,
        'flex-height' => true,
        'flex-width' => true,
        'header-text' => array('site-title', 'site-description'),
    ));
}

add_action('after_setup_theme', 'superfrio_setup');

function superfrio_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Sidebar', 'superfrios_widgets_init' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Add widgets here to appear in your sidebar.', 'your-theme-name' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'superfrio_widgets_init' );



// Adicionar a página de configurações do tema
function superfrio_add_admin_page() {
    add_menu_page(
        'Configurações do Carrossel', // Título da página
        'Carrossel',                  // Título do menu
        'manage_options',             // Capacidade
        'superfrio_carousel',         // Slug do menu
        'superfrio_carousel_page',    // Função de callback
        'dashicons-images-alt2',      // Ícone do menu
        110                           // Posição do menu
    );
}
add_action('admin_menu', 'superfrio_add_admin_page');

// Adicionar campos de configuração
function superfrio_carousel_page() {
    ?>
    <div class="wrap">
        <h1>Configurações do Carrossel</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('superfrio_carousel_settings');
                do_settings_sections('superfrio_carousel');
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Registrar configurações
function superfrio_register_settings() {
    register_setting('superfrio_carousel_settings', 'superfrio_carousel_images', 'superfrio_sanitize_images');
    add_settings_section('superfrio_carousel_section', 'Banners do Carrossel', null, 'superfrio_carousel');
    add_settings_field('superfrio_carousel_images', 'URLs das Imagens (separadas por vírgula)', 'superfrio_carousel_images_callback', 'superfrio_carousel', 'superfrio_carousel_section');

      // Carrossel 2
      register_setting('superfrio_carousel_settings', 'superfrio_carousel_images2', 'superfrio_sanitize_images');
    add_settings_section('superfrio_carousel_section2', 'Banners do Carrossel 2', null, 'superfrio_carousel');
    add_settings_field('superfrio_carousel_images2', 'URLs das Imagens (separadas por vírgula) para o Carrossel 2', 'superfrio_carousel_images2_callback', 'superfrio_carousel', 'superfrio_carousel_section2');
}
add_action('admin_init', 'superfrio_register_settings');

// Callback para o campo de URLs de imagens
function superfrio_carousel_images_callback() {
    $images = get_option('superfrio_carousel_images', '');
    echo '<textarea name="superfrio_carousel_images" rows="5" cols="50" class="large-text code">' . esc_textarea($images) . '</textarea>';
}




// Sanitizar a entrada
function superfrio_sanitize_images($input) {
    $output = explode(',', $input);
    $output = array_map('trim', $output);
    $output = array_filter($output, 'esc_url_raw');
    return implode(',', $output);
}


// Shortcode para exibir o carrossel
function superfrio_carousel_shortcode() {
    $images = get_option('superfrio_carousel_images', '');
    if (empty($images)) {
        return '<p>No images found for the carousel.</p>';
    }

    $images = explode(',', $images);
    $output = '<div class="superfrio-carousel">';
    foreach ($images as $image) {
        $output .= '<div><img src="' . esc_url(trim($image)) . '" alt="Carousel Image"></div>';
    }
    $output .= '</div>';
    return $output;
}
add_shortcode('superfrio_carousel', 'superfrio_carousel_shortcode');





// Inicializar o Slick Carousel
// Inicializar o Slick Carousel
function superfrio_enqueue_slick_scripts() {
    wp_enqueue_script('slick-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js', array('jquery'), null, true);
    wp_enqueue_style('slick-carousel-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css');
    wp_enqueue_style('slick-carousel-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css');

    // Adicionar script para inicializar os Slick Carousels
    wp_add_inline_script('slick-carousel-js', "
        jQuery(document).ready(function($) {
            $('.superfrio-carousel').slick({
                dots: true,
                infinite: true,
                speed: 500,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
            });
            $('.superfrio-carousel2').slick({
                dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        centerMode: false,
        focusOnSelect: true

            });
            $('.slick-carousel5').slick({
                dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        centerMode: false,
        focusOnSelect: true

            });
            $('.category-carousel').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 3000,
                arrows: true,
                dots: false
            });

            $('.banner-cards-container').slick({
                infinite: true,
                slidesToShow: 4,
                slidesToScroll: 1,
                autoplay: false,
                autoplaySpeed: 2000,
                arrows: true,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        
        });
    ");
}
add_action('wp_enqueue_scripts', 'superfrio_enqueue_slick_scripts');



// Register Custom Post Type for Cards
function register_card_post_type() {
    $args = array(
        'public' => true,
        'label'  => 'Cards',
        'supports' => array('title', 'thumbnail', 'editor'),
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-image',
    );
    register_post_type('card', $args);
}
add_action('init', 'register_card_post_type');

// Register Custom Fields for Card
function add_card_meta_boxes() {
    add_meta_box(
        'card_meta_box',
        'Card Details',
        'render_card_meta_box',
        'card',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_card_meta_boxes');

function render_card_meta_box($post) {
    $firstCardTitle = get_post_meta($post->ID, '_first_card_title', true);
    $firstCardImage01 = get_post_meta($post->ID, '_first_card_image01', true);
    $firstCardLink = get_post_meta($post->ID, '_first_card_link', true);
    // Add more fields as needed...

    // Display fields
    ?>
    <p>
        <label for="first_card_title">Title:</label>
        <input type="text" id="first_card_title" name="first_card_title" value="<?php echo esc_attr($firstCardTitle); ?>" />
    </p>
    <p>
        <label for="first_card_image01">Image URL:</label>
        <input type="text" id="first_card_image01" name="first_card_image01" value="<?php echo esc_url($firstCardImage01); ?>" />
    </p>
    <p>
        <label for="first_card_link">Link:</label>
        <input type="text" id="first_card_link" name="first_card_link" value="<?php echo esc_url($firstCardLink); ?>" />
    </p>
    <!-- Add more fields as needed... -->
    <?php
}

function save_card_meta_box_data($post_id) {
    if (array_key_exists('first_card_title', $_POST)) {
        update_post_meta($post_id, '_first_card_title', sanitize_text_field($_POST['first_card_title']));
    }
    if (array_key_exists('first_card_image01', $_POST)) {
        update_post_meta($post_id, '_first_card_image01', esc_url_raw($_POST['first_card_image01']));
    }
    if (array_key_exists('first_card_link', $_POST)) {
        update_post_meta($post_id, '_first_card_link', esc_url_raw($_POST['first_card_link']));
    }
    // Save other fields...
}
add_action('save_post', 'save_card_meta_box_data');



// Adicionar a página de configurações
function custom_images_settings_page() {
    add_menu_page(
        'Imagens do Site', // Título da página
        'Imagens do Site', // Título do menu
        'manage_options', // Capacidade
        'custom_images_settings', // Slug do menu
        'custom_images_settings_page_html', // Função de callback
        'dashicons-format-image', // Ícone do menu
        20 // Posição do menu
    );
}
add_action('admin_menu', 'custom_images_settings_page');

// Função de callback para a página de configurações
function custom_images_settings_page_html() {
    ?>
    <div class="wrap">
        <h1>Imagens do Site</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('custom_images_settings');
                do_settings_sections('custom_images_settings');
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Registrar configurações
function custom_images_settings_init() {
    register_setting('custom_images_settings', 'custom_images');

    add_settings_section(
        'custom_images_section',
        'Gerenciar Imagens',
        null,
        'custom_images_settings'
    );

    for ($i = 1; $i <= 4; $i++) {
        add_settings_field(
            "custom_image_{$i}",
            "Imagem {$i} URL",
            'custom_image_field_callback',
            'custom_images_settings',
            'custom_images_section',
            array('id' => "custom_image_{$i}")
        );
        add_settings_field(
            "custom_link_{$i}",
            "Link {$i}",
            'custom_link_field_callback',
            'custom_images_settings',
            'custom_images_section',
            array('id' => "custom_link_{$i}")
        );
    }
}
add_action('admin_init', 'custom_images_settings_init');

// Callback para campos de imagem
function custom_image_field_callback($args) {
    $options = get_option('custom_images');
    $value = isset($options[$args['id']]) ? esc_url($options[$args['id']]) : '';
    echo '<input type="text" name="custom_images[' . esc_attr($args['id']) . ']" value="' . $value . '" class="regular-text">';
}

// Callback para campos de link
function custom_link_field_callback($args) {
    $options = get_option('custom_images');
    $value = isset($options[$args['id']]) ? esc_url($options[$args['id']]) : '';
    echo '<input type="text" name="custom_images[' . esc_attr($args['id']) . ']" value="' . $value . '" class="regular-text">';
}


// Adicionar um texto personalizado
function get_custom_text() {
    return 'Seu texto personalizado aqui';
}

function register_custom_text_option() {
    // Registrar a opção com um valor padrão
    add_option('custom_text_option', 'Texto padrão');
    
    // Registrar a configuração para a página de administração
    register_setting('general', 'custom_text_option', 'esc_attr');
    
    // Adicionar o campo na página de Configurações Gerais
    add_settings_field(
        'custom_text_option', // ID do campo
        'Texto Personalizado', // Título
        'custom_text_option_html', // Função de callback
        'general' // Página de configurações
    );
}
add_action('admin_init', 'register_custom_text_option');

function custom_text_option_html() {
    $value = get_option('custom_text_option', 'Texto padrão');
    echo '<input type="text" id="custom_text_option" name="custom_text_option" value="' . esc_attr($value) . '" />';
}


// Shortcode para o segundo carrossel
function superfrio_carousel2_shortcode() {
    $images = get_option('superfrio_carousel_images2', '');
    if (empty($images)) {
        return '<p>No images found for the second carousel.</p>';
    }

    $images = explode(',', $images);
    $output = '<div class="superfrio-carousel2">';
    foreach ($images as $image) {
        $output .= '<div><img src="' . esc_url(trim($image)) . '" alt="Carousel Image"></div>';
    }
    $output .= '</div>';
    return $output;
}
add_shortcode('superfrio_carousel2', 'superfrio_carousel2_shortcode');


// Registrar configurações do segundo carrossel
function superfrio_register_settings2() {
    register_setting('superfrio_carousel_settings2', 'superfrio_carousel_images2', 'superfrio_sanitize_images');
    add_settings_section('superfrio_carousel_section2', 'Banners do Segundo Carrossel', null, 'superfrio_carousel');
    add_settings_field('superfrio_carousel_images2', 'URLs das Imagens (separadas por vírgula)', 'superfrio_carousel_images2_callback', 'superfrio_carousel', 'superfrio_carousel_section2');
}
add_action('admin_init', 'superfrio_register_settings2');

// Callback para o campo de URLs de imagens do segundo carrossel
function superfrio_carousel_images2_callback() {
    $images = get_option('superfrio_carousel_images2', '');
    echo '<textarea name="superfrio_carousel_images2" rows="5" cols="50" class="large-text code">' . esc_textarea($images) . '</textarea>';
}


// Inicializar o segundo Slick Carousel
function superfrio_enqueue_slick_scripts2() {
    wp_enqueue_script('slick-carousel-js', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js', array('jquery'), null, true);
    wp_enqueue_style('slick-carousel-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css');
    wp_enqueue_style('slick-carousel-theme-css', 'https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css');

    // Adicionar script para inicializar o segundo Slick Carousel
    wp_add_inline_script('slick-carousel-js', "
        jQuery(document).ready(function($) {
            $('.superfrio-carousel2').slick({
                dots: true,
                infinite: true,
                speed: 500,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
            });




        });
    ");
}
add_action('wp_enqueue_scripts', 'superfrio_enqueue_slick_scripts2');






function slick_carousel_best_selling_products($atts) {
    $atts = shortcode_atts(
        array(
            'limit' => '8', // Número de produtos a serem exibidos
        ),
        $atts,
        'slick_best_selling_products'
    );

    // Query para obter os produtos mais vendidos
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $atts['limit'],
        'meta_key' => 'total_sales',
        'orderby' => 'meta_value_num',
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        ob_start();
        ?>
        <div class="slick-carousel">
            <?php while ($query->have_posts()) : $query->the_post(); global $product; ?>
                <div class="product-box-container slick-slide">
                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                        <div class="link-container">
                            <div class="item-image">
                                <div style="max-width: 100%; min-height: 0px; height: 100%;">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('medium', array('class' => 'center-block ccLazyLoaded')); ?>
                                    <?php else : ?>
                                        <img src="<?php echo wc_placeholder_img_src(); ?>" alt="Sem Imagem" class="center-block ccLazyLoaded">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="item-labels">
                                <div class="stamps-container">
                                    <?php
                                    // Exibe os labels personalizados (se houver)
                                    $labels = get_post_meta($product->get_id(), '_custom_labels_images', true);
                                    if (!empty($labels) && is_array($labels)) {
                                        foreach ($labels as $label) {
                                            echo '<img src="' . esc_url($label) . '" alt="Label" class="custom-label-image" />';
                                        }
                                    }
                                    ?>
                                </div>
                                <div class="labels-container">
                                    <!-- Exibe o nome da categoria principal -->
                                    <?php
                                    $terms = get_the_terms($product->get_id(), 'product_cat');
                                    if ($terms && !is_wp_error($terms)) {
                                        $main_term = array_shift($terms);
                                        echo '<span class="product-category" style="color: #003c90;">' . esc_html($main_term->name) . '</span>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="item-price">
                                <div class="item-detail">
                                    <h2 class="paragraphOne" style="color: #003c90;font-weight:800;"><?php the_title(); ?></h2>
                                </div>
                                <div class="old-price">
                                    <?php if ($product->get_sale_price()) : ?>
                                        <div class="old-price" style="color: #686868;font-weight:700;"><?php echo wc_price($product->get_regular_price()); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="new-price-container">
                                    <div class="salepriceNotDiscont">
                                        <span>Por: <b><?php echo wc_price($product->get_price()); ?></b></span>
                                    </div>
                                </div>
                                <div class="in-cash-label paragraphFour">
                                    <?php if ($product->is_on_sale()) : ?>
                                        <span>à vista com desconto</span>
                                    <?php endif; ?>
                                </div>
                                <div class="parcels paragraphThree">
                                    <?php if ($product->get_sale_price()) : ?>
                                        <?php
                                        // Verifica se o método get_max_installment() existe antes de chamá-lo
                                        if (method_exists($product, 'get_max_installment')) {
                                            $max_installment = $product->get_max_installment();
                                            echo '<span>Ou ' . wc_price($product->get_price()) . ' em até ' . esc_html($max_installment) . 'x sem juros</span>';
                                        } else {
                                            echo '<span>Parcelamento disponível</span>'; // Mensagem padrão ou alternativa
                                        }
                                        ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </a>
                    <div class="primaryGreenBtn buy-btn">
                        <a href="?add-to-cart=<?php echo $product->get_id(); ?>">COMPRAR</a>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.slick-carousel').slick({
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    autoplay: false,
                    autoplaySpeed: 2000,
                    dots: true,
                    arrows: true,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1,
                                infinite: true,
                                dots: true
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 1
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }
    return '<p>No products found</p>';
}
add_shortcode('slick_best_selling_products', 'slick_carousel_best_selling_products');




function slick_categories_carousel_shortcode() {
    // Obter categorias de produtos
    $args = array(
        'taxonomy' => 'product_cat',
        'orderby' => 'name',
        'order' => 'ASC',
        'hide_empty' => true,
    );

    $product_categories = get_terms($args);

    ob_start();
    ?>
    <div class="banner-cards-container hidden-sm hidden-xs">
        <?php foreach ($product_categories as $category) : ?>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 condensed-padding home-card">
                <div class="banner-card-wrapper">
                    <p class="title"><strong><?php echo esc_html($category->name); ?></strong></p>
                    <div class="image-wrapper" id="cc_img__resize_wrapper">
                        <a href="<?php echo esc_url(get_term_link($category)); ?>">
                            <?php
                            $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                            $image = wp_get_attachment_url($thumbnail_id);
                            if ($image) :
                            ?>
                                <div id="cc_img__resize_wrapper" style="max-width: 100%; min-height: 0px; height: 100%;">
                                    <img class="card-cover" src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($category->name); ?>" width="257" height="280">
                                </div>
                            <?php else : ?>
                                <div id="cc_img__resize_wrapper" style="max-width: 100%; min-height: 0px; height: 100%;">
                                    <img class="card-cover" src="URL_DA_IMAGEM_PADRAO" alt="<?php echo esc_attr($category->name); ?>" width="257" height="280">
                                </div>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <script>
        
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('slick_categories_carousel', 'slick_categories_carousel_shortcode');


////////////////////////////////////////////////////////////////////////////////// DISPLAY IMAGES ////////////////////////////

// Adiciona a página de opções no menu do painel administrativo
function custom_admin_menu() {
    add_menu_page(
        'Configurações das 5 imagens', // Título da página
        'Upload 5 imagens banners',       // Título do menu
        'manage_options',             // Capacidade
        'carousel-images',           // Slug do menu
        'carousel_images_page',      // Função para exibir a página
        'dashicons-images-alt',      // Ícone do menu
        20                           // Posição
    );
}
add_action('admin_menu', 'custom_admin_menu');

// Função para exibir a página de upload de imagens
function carousel_images_page() {
    ?>
    <div class="wrap">
        <h1>Faça upload das 5 imagens</h1>
        <form method="post" action="options.php" enctype="multipart/form-data">
            <?php
            settings_fields('carousel_images_options_group');
            do_settings_sections('carousel-images');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Registra as configurações e campos
function carousel_images_settings() {
    register_setting('carousel_images_options_group', 'carousel_image01');
    register_setting('carousel_images_options_group', 'carousel_image02');
    register_setting('carousel_images_options_group', 'carousel_image03');
    register_setting('carousel_images_options_group', 'carousel_image04');
    register_setting('carousel_images_options_group', 'carousel_image05');
    
    add_settings_section(
        'carousel_images_section',
        'Configurações das Imagens',
        null,
        'carousel-images'
    );
    
    add_settings_field(
        'carousel_image01',
        'Imagem 1',
        'carousel_image_callback',
        'carousel-images',
        'carousel_images_section',
        array('id' => 'carousel_image01', 'preview_id' => 'carousel_image01_preview')
    );
    add_settings_field(
        'carousel_image02',
        'Imagem 2',
        'carousel_image_callback',
        'carousel-images',
        'carousel_images_section',
        array('id' => 'carousel_image02', 'preview_id' => 'carousel_image02_preview')
    );
    add_settings_field(
        'carousel_image03',
        'Imagem 3',
        'carousel_image_callback',
        'carousel-images',
        'carousel_images_section',
        array('id' => 'carousel_image03', 'preview_id' => 'carousel_image03_preview')
    );
    add_settings_field(
        'carousel_image04',
        'Imagem 4',
        'carousel_image_callback',
        'carousel-images',
        'carousel_images_section',
        array('id' => 'carousel_image04', 'preview_id' => 'carousel_image04_preview')
    );
    add_settings_field(
        'carousel_image05',
        'Imagem 5',
        'carousel_image_callback',
        'carousel-images',
        'carousel_images_section',
        array('id' => 'carousel_image05', 'preview_id' => 'carousel_image05_preview')
    );
}
add_action('admin_init', 'carousel_images_settings');

// Função de callback para os campos de upload de imagem
function carousel_image_callback($args) {
    $image_url = esc_url(get_option($args['id']));
    ?>
    <input type="text" id="<?php echo $args['id']; ?>" name="<?php echo $args['id']; ?>" value="<?php echo $image_url; ?>" class="regular-text" />
    <input type="button" class="button button-primary" value="Selecionar Imagem" id="<?php echo $args['id']; ?>_button" />
    <div id="<?php echo $args['preview_id']; ?>" style="margin-top: 10px;">
        <?php if ($image_url) : ?>
            <img src="<?php echo $image_url; ?>" style="max-width: 100%; height: auto;" />
        <?php endif; ?>
    </div>
    <?php
}

// Enfileira scripts e estilos para o upload de imagem
function custom_admin_scripts($hook) {
    if ($hook !== 'toplevel_page_carousel-images') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('custom-admin-script', get_template_directory_uri() . '/js/custom-admin-script.js', array('jquery'), null, true);
}
add_action('admin_enqueue_scripts', 'custom_admin_scripts');

// Shortcode para exibir as imagens
function display_images_shortcode() {
    ob_start();
    ?>
    <div class="custom-carousel">
        <div class="row" style='gap:10px;width:100%;justify-content:center;'>
            <div class="" style='width:40%;' class="imgs5">
                <div class="image-wrapper first-image">
                    <img src="<?php echo esc_url(get_option('carousel_image01')); ?>" style="width: 100%; height: auto;" alt="Imagem 1">
                </div>
            </div>
        <div style='width:40%;display:flex; flex-direction:column;gap:10px;' class="imgs5">
                <div style='display:flex !important;width:100%;height:50%;gap:10px;' class="imgs55">
                <div class="image-wrapper">
                    <img src="<?php echo esc_url(get_option('carousel_image02')); ?>" style="width: 100%; height: auto;" alt="Imagem 2">
                </div>
                <div class="image-wrapper">
                    <img src="<?php echo esc_url(get_option('carousel_image03')); ?>" style="width: 100%; height: auto;" alt="Imagem 3">
                </div>
            </div>

            <div style='display:flex !important;width:100%;height:50%;gap:10px;'>
                <div class="image-wrapper">
                    <img src="<?php echo esc_url(get_option('carousel_image04')); ?>" style="width: 100%; height: auto;" alt="Imagem 4">
                </div>
                <div class="image-wrapper">
                    <img src="<?php echo esc_url(get_option('carousel_image05')); ?>" style="width: 100%; height: auto;" alt="Imagem 5">
                </div>
            </div>
            </div>
            
        </div>
    </div>
    <style>
        .custom-carousel .row {
            display: flex;
            flex-wrap: wrap;
        }
        .custom-carousel .image-wrapper img {
            border-radius: 8px;
        }
        .custom-carousel .first-image img {
            width: 100%;
            height: auto;
        }
        .custom-carousel .col-lg-4:not(:first-child) {
            flex: 0 0 50%;
            max-width: 50%;
        }
        .custom-carousel .first-image {
            flex: 0 0 100%;
            max-width: 100%;
        }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('display_images', 'display_images_shortcode');

/////////////////////////////////////////////////////////////////////////////////  FIM DISPLAY IMAGES /////////////////////////////////////////////









function searched_products_shortcode() {
    ob_start();
    ?>
    <div id="searched-products-container">
        <!-- Os produtos pesquisados serão exibidos aqui -->
    </div>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            var container = document.getElementById('searched-products-container');
            var searchedProducts = JSON.parse(localStorage.getItem('searchedProducts')) || [];
            
            if (searchedProducts.length > 0) {
                searchedProducts.forEach(function(product) {
                    var productHTML = `
                        <div class="product-box-container">
                            <a href="${product.url}" title="${product.title}">
                                <div class="link-container">
                                    <div class="item-image">
                                        <img src="${product.image}" alt="${product.title}" />
                                    </div>
                                    <div class="item-price">
                                        <h2>${product.title}</h2>
                                        <span class="price">${product.price}</span>
                                    </div>
                                </div>
                            </a>
                            <div class="buy-btn">
                                <a href="?add-to-cart=${product.id}">Comprar</a>
                            </div>
                        </div>`;
                    container.insertAdjacentHTML('beforeend', productHTML);
                });
            } else {
                container.innerHTML = '<p>Nenhum produto pesquisado ainda.</p>';
            }
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('searched_products', 'searched_products_shortcode');




//////////////////////////////////////////////////////////// searched ajustar /////////////////////////////////////////////////////////

function custom_carousel_css5() {
    echo `<style>
    .slick-carousel5 {
        width: 100%;
        margin: 0 auto;
    }
    .slick-slide {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    </style>`;
}
add_action('wp_head', 'custom_carousel_css5');

function create_carousel_admin_menu5() {
    add_menu_page(
        'Carousel Images',
        'Banners altura curta',
        'manage_options',
        'carousel_images5',
        'carousel_images_page5',
        'dashicons-images-alt2',
        20
    );
}
add_action('admin_menu', 'create_carousel_admin_menu5');

function carousel_images_page5() {
    ?>
    <div class="wrap">
        <h1>Upload Carousel Images</h1>
        <form method="post" action="" enctype="multipart/form-data">
            <input type="file" name="carousel_images5[]" multiple="multiple" />
            <?php submit_button('Upload Images'); ?>
        </form>
        <h2>Gerencie o upload dos banners</h2>
        <form method="post" action="">
            <?php
            $images5 = get_option('carousel_images5', array());
            if (!empty($images5)) {
                echo '<ul>';
                foreach ($images5 as $index => $image) {
                    echo '<li>';
                    echo '<img src="' . esc_url($image) . '" style="height: 100px; width: auto;" />';
                    echo '<input type="text" name="carousel_images5[]" value="' . esc_url($image) . '" style="width: 80%;" />';
                    echo '<button type="submit" name="delete_image5" value="' . $index . '">Delete</button>';
                    echo '</li>';
                }
                echo '</ul>';
                submit_button('Save Changes');
            } else {
                echo '<p>No images found</p>';
            }
            ?>
        </form>
    </div>
    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_FILES['carousel_images5'])) {
            handle_carousel_images_upload5();
        } elseif (isset($_POST['delete_image5'])) {
            delete_carousel_image5($_POST['delete_image5']);
        } elseif (!empty($_POST['carousel_images5'])) {
            update_option('carousel_images5', array_map('esc_url_raw', $_POST['carousel_images5']));
        }
    }
}

function handle_carousel_images_upload5() {
    $uploaded_files5 = $_FILES['carousel_images5'];
    $upload_overrides5 = array('test_form' => false);
    $uploaded_images5 = get_option('carousel_images5', array());

    foreach ($uploaded_files5['name'] as $key => $value) {
        if ($uploaded_files5['name'][$key]) {
            $file5 = array(
                'name'     => $uploaded_files5['name'][$key],
                'type'     => $uploaded_files5['type'][$key],
                'tmp_name' => $uploaded_files5['tmp_name'][$key],
                'error'    => $uploaded_files5['error'][$key],
                'size'     => $uploaded_files5['size'][$key]
            );

            $upload5 = wp_handle_upload($file5, $upload_overrides5);

            if (isset($upload5['url'])) {
                $uploaded_images5[] = $upload5['url'];
            }
        }
    }

    update_option('carousel_images5', $uploaded_images5);
}

function delete_carousel_image5($index) {
    $images5 = get_option('carousel_images5', array());
    if (isset($images5[$index])) {
        unset($images5[$index]);
        update_option('carousel_images5', array_values($images5));
    }
}


function render_slick_carousel5() {
    $images5 = get_option('carousel_images5');
    if (!empty($images5)) {
        $output5 = '<div class="slick-carousel5">';
        foreach ($images5 as $image) {
            $output5 .= '<div class="frigelar-simple-image5">';
            $output5 .= '<img src="' . esc_url($image) . '" style="height: 200px; width: 1650px;" />';
            $output5 .= '</div>';
        }
        $output5 .= '</div>';
        return $output5;
    } else {
        return '<p>No images found</p>';
    }
}
add_shortcode('slick_carousel5', 'render_slick_carousel5');


///////////////////////////////////// redes sociais //////////////////////////////////////////////////////////////////////////////

function create_social_media_admin_menu5() {
    add_menu_page(
        'Social Media Images',
        'Social Media Images',
        'manage_options',
        'social_media_images5',
        'social_media_images_page5',
        'dashicons-share',
        20
    );
}
add_action('admin_menu', 'create_social_media_admin_menu5');

function social_media_images_page5() {
    ?>
    <div class="wrap">
        <h1>Upload Social Media Images</h1>
        <form method="post" action="" enctype="multipart/form-data">
            <input type="file" name="social_media_images5[]" multiple="multiple" />
            <?php submit_button('Upload Images'); ?>
        </form>
        <h2>Manage Uploaded Images</h2>
        <form method="post" action="">
            <?php
            $images5 = get_option('social_media_images5', array());
            if (!empty($images5)) {
                echo '<ul class="listing horizontal-list">';
                foreach ($images5 as $index => $image) {
                    echo '<li>';
                    echo '<a target="_blank" href="' . esc_url($image['url']) . '">';
                    echo '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
                    echo '</a>';
                    echo '<input type="text" name="social_media_images5[' . $index . '][url]" value="' . esc_url($image['url']) . '" placeholder="URL" />';
                    echo '<input type="text" name="social_media_images5[' . $index . '][src]" value="' . esc_url($image['src']) . '" placeholder="Image Source" />';
                    echo '<input type="text" name="social_media_images5[' . $index . '][alt]" value="' . esc_attr($image['alt']) . '" placeholder="Alt Text" />';
                    echo '<button type="submit" name="delete_image5" value="' . $index . '">Delete</button>';
                    echo '</li>';
                }
                echo '</ul>';
                submit_button('Save Changes');
            } else {
                echo '<p>No images found</p>';
            }
            ?>
        </form>
    </div>
    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_FILES['social_media_images5'])) {
            handle_social_media_images_upload5();
        } elseif (isset($_POST['delete_image5'])) {
            delete_social_media_image5($_POST['delete_image5']);
        } elseif (!empty($_POST['social_media_images5'])) {
            update_option('social_media_images5', array_map('sanitize_social_media_image5', $_POST['social_media_images5']));
        }
    }
}

function handle_social_media_images_upload5() {
    $uploaded_files5 = $_FILES['social_media_images5'];
    $upload_overrides5 = array('test_form' => false);
    $uploaded_images5 = get_option('social_media_images5', array());

    foreach ($uploaded_files5['name'] as $key => $value) {
        if ($uploaded_files5['name'][$key]) {
            $file5 = array(
                'name'     => $uploaded_files5['name'][$key],
                'type'     => $uploaded_files5['type'][$key],
                'tmp_name' => $uploaded_files5['tmp_name'][$key],
                'error'    => $uploaded_files5['error'][$key],
                'size'     => $uploaded_files5['size'][$key]
            );

            $upload5 = wp_handle_upload($file5, $upload_overrides5);

            if (isset($upload5['url'])) {
                $uploaded_images5[] = array(
                    'url' => '',
                    'src' => $upload5['url'],
                    'alt' => ''
                );
            }
        }
    }

    update_option('social_media_images5', $uploaded_images5);
}

function delete_social_media_image5($index) {
    $images5 = get_option('social_media_images5', array());
    if (isset($images5[$index])) {
        unset($images5[$index]);
        update_option('social_media_images5', array_values($images5));
    }
}

function sanitize_social_media_image5($image) {
    return array(
        'url' => esc_url_raw($image['url']),
        'src' => esc_url_raw($image['src']),
        'alt' => sanitize_text_field($image['alt'])
    );
}


function render_social_media_images5() {
    $images5 = get_option('social_media_images5', array());
    if (!empty($images5)) {
        $output5 = '<ul class="listing horizontal-list">';
        foreach ($images5 as $image) {
            $output5 .= '<li>';
            $output5 .= '<a target="_blank" href="' . esc_url($image['url']) . '">';
            $output5 .= '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
            $output5 .= '</a>';
            $output5 .= '</li>';
        }
        $output5 .= '</ul>';
        return $output5;
    } else {
        return '<p>No images found</p>';
    }
}
add_shortcode('social_media_images5', 'render_social_media_images5');


function custom_social_media_css5() {
    echo `<style>
    .horizontal-list {
        display: flex;
        list-style-type: none;
        padding: 0;
    }
    .horizontal-list li {
        margin-right: 10px;
    }
    </style>`;
}
add_action('wp_head', 'custom_social_media_css5');




///////////////////////////////////////////////////////   payment methodsa //////////////////////////////


function create_payment_methods_admin_menu() {
    add_menu_page(
        'Payment Methods Images',
        'Payment Methods Images',
        'manage_options',
        'payment_methods_images',
        'payment_methods_images_page',
        'dashicons-money-alt',
        20
    );
}
add_action('admin_menu', 'create_payment_methods_admin_menu');


function payment_methods_images_page() {
    ?>
    <div class="wrap">
        <h1>Upload Payment Methods Images</h1>
        <form method="post" action="" enctype="multipart/form-data">
            <input type="file" name="payment_methods_images[]" multiple="multiple" />
            <?php submit_button('Upload Images'); ?>
        </form>
        <h2>Manage Uploaded Images</h2>
        <form method="post" action="">
            <?php
            $images = get_option('payment_methods_images', array());
            if (!empty($images)) {
                echo '<ul class="listing horizontal-list">';
                foreach ($images as $index => $image) {
                    echo '<li>';
                    echo '<a target="_blank" href="' . esc_url($image['url']) . '">';
                    echo '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
                    echo '</a>';
                    echo '<input type="text" name="payment_methods_images[' . $index . '][url]" value="' . esc_url($image['url']) . '" placeholder="URL" />';
                    echo '<input type="text" name="payment_methods_images[' . $index . '][src]" value="' . esc_url($image['src']) . '" placeholder="Image Source" />';
                    echo '<input type="text" name="payment_methods_images[' . $index . '][alt]" value="' . esc_attr($image['alt']) . '" placeholder="Alt Text" />';
                    echo '<button type="submit" name="delete_image" value="' . $index . '">Delete</button>';
                    echo '</li>';
                }
                echo '</ul>';
                submit_button('Save Changes');
            } else {
                echo '<p>No images found</p>';
            }
            ?>
        </form>
    </div>
    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_FILES['payment_methods_images'])) {
            handle_payment_methods_images_upload();
        } elseif (isset($_POST['delete_image'])) {
            delete_payment_methods_image($_POST['delete_image']);
        } elseif (!empty($_POST['payment_methods_images'])) {
            update_option('payment_methods_images', array_map('sanitize_payment_methods_image', $_POST['payment_methods_images']));
        }
    }
}


function handle_payment_methods_images_upload() {
    $uploaded_files = $_FILES['payment_methods_images'];
    $upload_overrides = array('test_form' => false);
    $uploaded_images = get_option('payment_methods_images', array());

    foreach ($uploaded_files['name'] as $key => $value) {
        if ($uploaded_files['name'][$key]) {
            $file = array(
                'name'     => $uploaded_files['name'][$key],
                'type'     => $uploaded_files['type'][$key],
                'tmp_name' => $uploaded_files['tmp_name'][$key],
                'error'    => $uploaded_files['error'][$key],
                'size'     => $uploaded_files['size'][$key]
            );

            $upload = wp_handle_upload($file, $upload_overrides);

            if (isset($upload['url'])) {
                $uploaded_images[] = array(
                    'url' => '',
                    'src' => $upload['url'],
                    'alt' => ''
                );
            }
        }
    }

    update_option('payment_methods_images', $uploaded_images);
}


function delete_payment_methods_image($index) {
    $images = get_option('payment_methods_images', array());
    if (isset($images[$index])) {
        unset($images[$index]);
        update_option('payment_methods_images', array_values($images));
    }
}


function render_payment_methods_images() {
    $images = get_option('payment_methods_images', array());
    if (!empty($images)) {
        $output = '<ul class="listing horizontal-list">';
        foreach ($images as $image) {
            $output .= '<li>';
            $output .= '<a target="_blank" href="' . esc_url($image['url']) . '">';
            $output .= '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
            $output .= '</a>';
            $output .= '</li>';
        }
        $output .= '</ul>';
        return $output;
    } else {
        return '<p>No images found</p>';
    }
}
add_shortcode('payment_methods_images', 'render_payment_methods_images');


function custom_payment_methods_css() {
    echo `<style>
    .horizontal-list {
        display: flex;
        list-style-type: none;
        padding: 0;
    }
    .horizontal-list li {
        margin-right: 10px;
    }
    </style>`;
}
add_action('wp_head', 'custom_payment_methods_css');




////////////////////////////////////// CERTIFICATES UPLOAD IAMGENS /////////////////////////////


function create_certificates_admin_menu() {
    add_menu_page(
        'Certificates Images',
        'Certificates Images',
        'manage_options',
        'certificates_images',
        'certificates_images_page',
        'dashicons-awards',
        20
    );
}
add_action('admin_menu', 'create_certificates_admin_menu');


function certificates_images_page() {
    ?>
    <div class="wrap">
        <h1>Upload Certificates Images</h1>
        <form method="post" action="" enctype="multipart/form-data">
            <input type="file" name="certificates_images[]" multiple="multiple" />
            <?php submit_button('Upload Images'); ?>
        </form>
        <h2>Manage Uploaded Images</h2>
        <form method="post" action="">
            <?php
            $images = get_option('certificates_images', array());
            if (!empty($images)) {
                echo '<ul class="listing horizontal-list">';
                foreach ($images as $index => $image) {
                    echo '<li>';
                    echo '<a target="_blank" href="' . esc_url($image['url']) . '">';
                    echo '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
                    echo '</a>';
                    echo '<input type="text" name="certificates_images[' . $index . '][url]" value="' . esc_url($image['url']) . '" placeholder="URL" />';
                    echo '<input type="text" name="certificates_images[' . $index . '][src]" value="' . esc_url($image['src']) . '" placeholder="Image Source" />';
                    echo '<input type="text" name="certificates_images[' . $index . '][alt]" value="' . esc_attr($image['alt']) . '" placeholder="Alt Text" />';
                    echo '<button type="submit" name="delete_image" value="' . $index . '">Delete</button>';
                    echo '</li>';
                }
                echo '</ul>';
                submit_button('Save Changes');
            } else {
                echo '<p>No images found</p>';
            }
            ?>
        </form>
    </div>
    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!empty($_FILES['certificates_images'])) {
            handle_certificates_images_upload();
        } elseif (isset($_POST['delete_image'])) {
            delete_certificates_image($_POST['delete_image']);
        } elseif (!empty($_POST['certificates_images'])) {
            update_option('certificates_images', array_map('sanitize_certificates_image', $_POST['certificates_images']));
        }
    }
}


function handle_certificates_images_upload() {
    $uploaded_files = $_FILES['certificates_images'];
    $upload_overrides = array('test_form' => false);
    $uploaded_images = get_option('certificates_images', array());

    foreach ($uploaded_files['name'] as $key => $value) {
        if ($uploaded_files['name'][$key]) {
            $file = array(
                'name'     => $uploaded_files['name'][$key],
                'type'     => $uploaded_files['type'][$key],
                'tmp_name' => $uploaded_files['tmp_name'][$key],
                'error'    => $uploaded_files['error'][$key],
                'size'     => $uploaded_files['size'][$key]
            );

            $upload = wp_handle_upload($file, $upload_overrides);

            if (isset($upload['url'])) {
                $uploaded_images[] = array(
                    'url' => '',
                    'src' => $upload['url'],
                    'alt' => ''
                );
            }
        }
    }

    update_option('certificates_images', $uploaded_images);
}


function delete_certificates_image($index) {
    $images = get_option('certificates_images', array());
    if (isset($images[$index])) {
        unset($images[$index]);
        update_option('certificates_images', array_values($images));
    }
}


function render_certificates_images() {
    $images = get_option('certificates_images', array());
    if (!empty($images)) {
        $output = '<ul class="listing horizontal-list">';
        foreach ($images as $image) {
            $output .= '<li>';
            $output .= '<a target="_blank" href="' . esc_url($image['url']) . '">';
            $output .= '<img src="' . esc_url($image['src']) . '" width="32" height="32" alt="' . esc_attr($image['alt']) . '" />';
            $output .= '</a>';
            $output .= '</li>';
        }
        $output .= '</ul>';
        return $output;
    } else {
        return '<p>No images found</p>';
    }
}
add_shortcode('certificates_images', 'render_certificates_images');


function custom_certificates_css() {
    echo `<style>
    .horizontal-list {
        display: flex;
        list-style-type: none;
        padding: 0;
    }
    .horizontal-list li {
        margin-right: 10px;
    }
    </style>`;
}
add_action('wp_head', 'custom_certificates_css');

////////////////////////////////////// DROPDOWN MENU CATEGORIES //////////////////////

function my_theme_enqueue_scripts() {
    // Caminho para o arquivo do walker
    require_once get_template_directory() . '/inc/class-wp-custom-nav-walker.php';
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_scripts');


/////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////// CATEGORY CARDS ////////////////////////////////////



/////////////////////////////////CETEGORY MENU /////////////////////////////////////////

// Função para exibir categorias do WooCommerce
function custom_woocommerce_categories_menu() {
    $args = array(
        'taxonomy'   => 'product_cat',
        'orderby'    => 'name',
        'show_count' => false,
        'pad_counts' => false,
        'hierarchical' => true,
        'title_li'   => '',
        'hide_empty' => true,
    );
    
    $categories = get_terms($args);

    if ($categories) {
        echo '<ul class="woocommerce-categories-menu">';
        foreach ($categories as $category) {
            echo '<li class="menu-item">';
            echo '<a href="' . get_term_link($category) . '">' . $category->name . '</a>';
            
            // Se a categoria tiver subcategorias, adicione um submenu
            $subcategories = get_terms(array(
                'taxonomy'   => 'product_cat',
                'parent'     => $category->term_id,
                'hide_empty' => true,
            ));
            
            if ($subcategories) {
                echo '<ul class="submenu">';
                foreach ($subcategories as $subcategory) {
                    echo '<li><a href="' . get_term_link($subcategory) . '">' . $subcategory->name . '</a></li>';
                }
                echo '</ul>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
}

function my_custom_nav_menu_args($args) {
    if ( 'primary' === $args['theme_location'] ) {
        $args['walker'] = new WP_Custom_Nav_Walker(); // Ou o walker customizado que você estiver usando
    }
    return $args;
}
add_filter('wp_nav_menu_args', 'my_custom_nav_menu_args');


// Adiciona campos para múltiplas imagens de labels na página de edição do produto
// Adiciona um campo personalizado para imagens de labels na página de edição do produto
function add_custom_product_labels_field() {
    global $post;

    // Recupera as imagens salvas
    $labels = get_post_meta($post->ID, '_custom_labels_images', true);

    echo '<div class="custom_labels_field">';
    echo '<h3>' . __('Labels Imagens', 'woocommerce') . '</h3>';

    echo '<p><a class="add_label_image button" href="#">' . __('Adicionar Imagem do Label', 'woocommerce') . '</a></p>';

    echo '<ul class="custom_labels_images">';
    if (!empty($labels)) {
        foreach ($labels as $label) {
            echo '<li><img src="' . esc_url($label) . '" style="max-width: 100px; max-height: 100px;"/><a href="#" class="remove_label_image">' . __('Remover', 'woocommerce') . '</a></li>';
        }
    }
    echo '</ul>';

    echo '<input type="hidden" id="_custom_labels_images" name="_custom_labels_images" value="' . esc_attr(implode(',', (array)$labels)) . '" />';
    echo '</div>';
}
add_action('woocommerce_product_options_general_product_data', 'add_custom_product_labels_field');

// Salva as imagens dos labels
function save_custom_product_labels_field($post_id) {
    if (isset($_POST['_custom_labels_images'])) {
        $labels = explode(',', sanitize_text_field($_POST['_custom_labels_images']));
        update_post_meta($post_id, '_custom_labels_images', array_filter($labels));
    }
}
add_action('woocommerce_process_product_meta', 'save_custom_product_labels_field');

// Adiciona script e estilo para o upload e remoção de imagens
function custom_labels_field_scripts() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Adicionar imagem
            $('a.add_label_image').on('click', function(e) {
                e.preventDefault();
                var frame = wp.media({
                    title: 'Selecione a Imagem do Label',
                    button: { text: 'Adicionar Imagem' },
                    multiple: false
                }).on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    var imageUrl = attachment.url;
                    var $ul = $('.custom_labels_images');
                    $ul.append('<li><img src="' + imageUrl + '" style="max-width: 100px; max-height: 100px;"/><a href="#" class="remove_label_image">Remover</a></li>');
                    updateHiddenField();
                }).open();
            });

            // Remover imagem
            $('body').on('click', 'a.remove_label_image', function(e) {
                e.preventDefault();
                $(this).closest('li').remove();
                updateHiddenField();
            });

            // Atualiza o campo oculto com as URLs das imagens
            function updateHiddenField() {
                var labels = [];
                $('.custom_labels_images img').each(function() {
                    labels.push($(this).attr('src'));
                });
                $('#_custom_labels_images').val(labels.join(','));
            }
        });
    </script>
    <style>
        .custom_labels_field img {
            margin-right: 10px;
        }
        .custom_labels_field a.remove_label_image {
            color: red;
            text-decoration: none;
            margin-left: 10px;
        }
    </style>
    <?php
}
add_action('admin_footer', 'custom_labels_field_scripts');

// Exibe as imagens dos labels na página do produto e na loja
function display_custom_product_labels() {
    global $product;

    $labels = get_post_meta($product->get_id(), '_custom_labels_images', true);

    if (!empty($labels) && is_array($labels)) {
        echo '<div class="custom-product-labels">';
        foreach ($labels as $label) {
            echo '<img src="' . esc_url($label) . '" alt="Label" class="custom-label-image" />';
        }
        echo '</div>';
    }
}
add_action('woocommerce_before_shop_loop_item_title', 'display_custom_product_labels', 20);
add_action('woocommerce_before_single_product_summary', 'display_custom_product_labels', 20);

// Adiciona CSS para estilizar as imagens dos labels
function custom_labels_styles() {
    echo `<style>
        .custom-product-labels {
            margin-top: 10px; /* Ajuste conforme necessário */
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .custom-label-image {
            max-width: 100px; /* Ajuste conforme necessário */
            max-height: 100px;
            margin-right: 5px;
        }
        .product-box-container .item-image {
            position: relative;
        }
    </style>`;
}
add_action('wp_head', 'custom_labels_styles');




function category_carousel_shortcode() {
    // Obtém todas as categorias de produtos do WooCommerce
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'parent' => 0, // Apenas categorias principais
    ));

    if (empty($categories)) {
        return '<p>No categories found</p>';
    }

    $output = '<div class="category-carousel">';

    foreach ($categories as $category) {
        $category_link = get_term_link($category);
        $category_image_id = get_term_meta($category->term_id, 'thumbnail_id', true);
        $category_image_url = wp_get_attachment_url($category_image_id);

        $output .= '<div class="carousel-item">';
        $output .= '<a href="' . esc_url($category_link) . '">';
        if ($category_image_url) {
            $output .= '<img src="' . esc_url($category_image_url) . '" alt="' . esc_attr($category->name) . '" />';
        }
        $output .= '<h3 style="color:#003c90 !important;" class="crc">' . esc_html($category->name) . '</h3>';
        $output .= '</a>';
        $output .= '</div>';
    }

    $output .= '</div>';

    return $output;
}
add_shortcode('category_carousel', 'category_carousel_shortcode');


function custom_woocommerce_product_search($query) {
    if ($query->is_search() && !is_admin() && $query->is_main_query()) {
        $search_term = $query->get('s');

        // Verifica se o termo de busca corresponde a uma categoria de produto
        $term = get_term_by('name', $search_term, 'product_cat');
        if ($term) {
            $query->set('post_type', 'product');
            $tax_query = array(
                'relation' => 'OR',
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $term->term_id,
                ),
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'slug',
                    'terms'    => $search_term,
                ),
            );
            $query->set('tax_query', $tax_query);
        } else {
            // Busca por produtos que correspondem ao termo de busca
            $query->set('post_type', array('product'));
        }
    }
}
add_action('pre_get_posts', 'custom_woocommerce_product_search');



function enqueue_custom_scripts() {
    // Enfileira o jQuery, se ainda não estiver incluído
    wp_enqueue_script('jquery');

    // Enfileira seu script customizado
    wp_enqueue_script('custom-login-script', get_template_directory_uri() . '/path-to-your-js-file.js', array('jquery'), null, true);

    // Localiza o script para passar a URL de AJAX
    wp_localize_script('custom-login-script', 'ajax_params', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('ajax-login-nonce')
    ));
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');



add_action('wp_ajax_woocommerce_ajax_login', 'woocommerce_ajax_login');
add_action('wp_ajax_nopriv_woocommerce_ajax_login', 'woocommerce_ajax_login');

function woocommerce_ajax_login() {
    check_ajax_referer('ajax-login-nonce', 'security');

    $username = sanitize_user($_POST['username']);
    $password = $_POST['password'];

    $info = array();
    $info['user_login'] = $username;
    $info['user_password'] = $password;
    $info['remember'] = true;

    $user = wp_signon($info, false);

    if (is_wp_error($user)) {
        echo json_encode(array('loggedin' => false, 'message' => $user->get_error_message()));
    } else {
        echo json_encode(array('loggedin' => true, 'redirecturl' => home_url()));
    }

    wp_die();
}



?>
