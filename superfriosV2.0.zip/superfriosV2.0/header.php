<html <?php language_attributes(); ?> id="oracle-cc" data-bind="setContextVariable:{name:'masterViewModel', value:$data}" dir="ltr" data-lt-installed="true" style="overflow: hidden; height: auto;">

<head>

  <meta http-equiv="origin-trial" content="A/kargTFyk8MR5ueravczef/wIlTkbVk1qXQesp39nV+xNECPdLBVeYffxrM8TmZT6RArWGQVCJ0LRivD7glcAUAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZzIiLCJleHBpcnkiOjE3NDIzNDIzOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
  
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta charset="<?php bloginfo('charset'); ?> ">


  <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon-new-frigelar2.png">


  <title data-bind="text: $data.title"><?php wp_title(); ?></title>
  <!-- ko noIndexMeta: noindex() -->
  <!-- /ko -->
  <!-- ko if: $data.description -->
  <meta name="description" data-bind="attr: { content: $data.description }" content="As melhores ofertas em ar-condicionado e refrigeração estão na Frigelar. Aparelhos com 10% OFF à vista ou em 8x SEM JUROS. Entrega segura em todo o Brasil!">
  <!-- /ko -->
  <!-- ko if: ((typeof($data.keywords) === "function") && ($data.keywords() && $data.keywords().length > 0)) -->
  <meta name="keywords" data-bind="attr: { content: $data.keywords }" content="Frigelar,ar-condicionado,ar-condicionado inverter,split,ar split,inverter,ar-condicionado split,piso teto,cassete,multi split,frio,refrigeração,btus,comprar, onde comprar ar-condicionado,climatização">
  <!-- /ko -->
  <!-- ko foreach: $data.metaTags -->
  <!-- /ko -->

  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">


  <!--[if lte IE 9]>
    <link href="/css/storefront-ie.css?bust=24.05" rel="stylesheet" type="text/css"/>

    <![endif]-->





  <link href="https://www.superfrios.com.br" rel="canonical">


  <!--<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/store-libs.js" src="./js/store-libs.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarGlobalPaymentUtils.min.js" src="./js/frigelarGlobalPaymentUtils.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarGlobalUtils.min.js" src="./js/frigelarGlobalUtils.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarJqueryPlugins.min.js" src="./js/frigelarJqueryPlugins.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="ojtranslations/nls/pt/ojtranslations" src="./js/ojtranslations.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="viewModels/shopperContext" src="./js/shopperContext.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="viewModels/inventoryViewModel" src="./js/inventoryViewModel.js"></script>-->
  <style type="text/css">
    @font-face {
      font-weight: 400;
      font-style: normal;
      font-family: circular;

      src: url('chrome-extension://liecbddmkiiihnedobmlmillhodjkdmb/fonts/CircularXXWeb-Book.woff2') format('woff2');
    }

    @font-face {
      font-weight: 700;
      font-style: normal;
      font-family: circular;

      src: url('chrome-extension://liecbddmkiiihnedobmlmillhodjkdmb/fonts/CircularXXWeb-Bold.woff2') format('woff2');
    }
  </style>
 
  <style type="text/css" id="-402178705">
    #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper {
      margin-top: 25px;
      margin-bottom: 25px;
      display: block
    }

    #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper h1,
    #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper .title {
      font-size: 21px
    }

    @media (min-width:991px) {

      #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper h1,
      #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper .title {
        line-height: 1em
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper .product-box-container {
      margin-top: 28px;
      margin-bottom: 20px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper .product-box-container {
        margin-left: 0;
        margin-right: 0
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300034 .product-recommendations-wrapper {
        margin-top: 40px;
        margin-bottom: 40px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300034 .product-recommendations-listing {
        display: flex;
        flex-wrap: wrap;
        margin-left: -16px;
        margin-right: -16px
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .title {
      color: #52ae32;
      margin-bottom: 16px;
      padding-left: 25px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300034 .title {
        font-size: 20px;
        line-height: 26px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300034 .title {
        padding-left: 0;
        margin-left: 16px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-slider {
        margin-left: -16px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-slider .product-box-container {
        width: 178px;
        box-shadow: none
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-slider .product-box-container .link-container {
        border-right: 2px solid #d6d6d6
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-slider .product-box-container .item-price .new-price-container .discount {
        width: 28px;
        padding: 1px 0
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-slider .product-box-container .item-price .new-price-container .discount p {
        font-size: 8px;
        line-height: 11px;
        letter-spacing: .2px
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel {
      position: relative;
      display: block;
      overflow: visible
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .stamps-container {
        width: 100%
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .stamps-container .discount .sel {
        width: 100%;
        align-items: center;
        font-size: .5rem;
        padding-left: 8px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .stamps-container .discount .sel.formated {
        display: flex
      }
    }

    @media only screen and (max-width : 991px) and (min-width:577px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .product-box-container .item-image img {
        width: 100%;
        height: 100%
      }
    }

    @media only screen and (max-width : 991px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .product-box-container {
        padding: 0;
        margin-bottom: 28px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .product-box-container .item-image {
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .product-box-container .item-image img {
        width: 132px;
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    @media only screen and (max-width : 991px) and (max-width:650px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-track {
      display: inline-flex
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-list {
      width: 93%;
      overflow: hidden;
      margin: 0 auto
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-list {
        width: 100%;
        overflow: visible
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-prev {
      color: #4e77ad;
      left: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-prev.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-next {
      color: #4e77ad;
      right: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel .slick-next.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view {
      width: 100%
    }

    @media (min-width:1980px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .product-box-container {
        width: 300px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .product-box-container {
        width: calc(50% - 2px)
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .product-box-container:nth-child(2n + 1) {
        margin-right: 4px
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .product-box-container .item-image {
        height: 160px
      }

      #frigelarProductRecommendations_v1-wi300034 .slick-carousel.listing-view .product-box-container .item-image img {
        width: 160px;
        height: 160px
      }
    }

    #frigelarProductRecommendations_v1-wi300034 .show-modal {
      display: flex;
      margin: 0 20px 0 auto;
      color: #4e77ad
    }

    #frigelarProductRecommendations_v1-wi300034 .show-modal svg {
      margin: auto 5px
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 6;
      width: 100%;
      height: 100%;
      background: #fff
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products .top {
      background-color: #52ae32;
      height: 50px;
      display: flex;
      color: #fff;
      font-weight: bolder;
      z-index: 7
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products .top .text {
      margin: auto auto auto 15px
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products .top .close-button {
      margin: auto 15px auto auto
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products .product-listing {
      display: grid;
      grid-template-columns: 50% 50%;
      position: fixed;
      top: 0;
      overflow-y: scroll;
      height: 100%;
      width: 100%;
      padding-top: 50px;
      padding-bottom: 50px;
      z-index: -1
    }

    #frigelarProductRecommendations_v1-wi300034 .modal-listing-products .product-listing .product-box-container {
      display: flex;
      margin: 30px auto
    }

    #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper {
      margin-top: 25px;
      margin-bottom: 25px;
      display: block
    }

    #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper h1,
    #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper .title {
      font-size: 21px
    }

    @media (min-width:991px) {

      #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper h1,
      #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper .title {
        line-height: 1em
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper .product-box-container {
      margin-top: 28px;
      margin-bottom: 20px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper .product-box-container {
        margin-left: 0;
        margin-right: 0
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300035 .product-recommendations-wrapper {
        margin-top: 40px;
        margin-bottom: 40px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300035 .product-recommendations-listing {
        display: flex;
        flex-wrap: wrap;
        margin-left: -16px;
        margin-right: -16px
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .title {
      color: #52ae32;
      margin-bottom: 16px;
      padding-left: 25px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300035 .title {
        font-size: 20px;
        line-height: 26px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300035 .title {
        padding-left: 0;
        margin-left: 16px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-slider {
        margin-left: -16px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-slider .product-box-container {
        width: 178px;
        box-shadow: none
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-slider .product-box-container .link-container {
        border-right: 2px solid #d6d6d6
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-slider .product-box-container .item-price .new-price-container .discount {
        width: 28px;
        padding: 1px 0
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-slider .product-box-container .item-price .new-price-container .discount p {
        font-size: 8px;
        line-height: 11px;
        letter-spacing: .2px
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel {
      position: relative;
      display: block;
      overflow: visible
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .stamps-container {
        width: 100%
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .stamps-container .discount .sel {
        width: 100%;
        align-items: center;
        font-size: .5rem;
        padding-left: 8px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .stamps-container .discount .sel.formated {
        display: flex
      }
    }

    @media only screen and (max-width : 991px) and (min-width:577px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .product-box-container .item-image img {
        width: 100%;
        height: 100%
      }
    }

    @media only screen and (max-width : 991px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .product-box-container {
        padding: 0;
        margin-bottom: 28px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .product-box-container .item-image {
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .product-box-container .item-image img {
        width: 132px;
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    @media only screen and (max-width : 991px) and (max-width:650px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-track {
      display: inline-flex
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-list {
      width: 93%;
      overflow: hidden;
      margin: 0 auto
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-list {
        width: 100%;
        overflow: visible
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-prev {
      color: #4e77ad;
      left: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-prev.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-next {
      color: #4e77ad;
      right: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel .slick-next.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view {
      width: 100%
    }

    @media (min-width:1980px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .product-box-container {
        width: 300px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .product-box-container {
        width: calc(50% - 2px)
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .product-box-container:nth-child(2n + 1) {
        margin-right: 4px
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .product-box-container .item-image {
        height: 160px
      }

      #frigelarProductRecommendations_v1-wi300035 .slick-carousel.listing-view .product-box-container .item-image img {
        width: 160px;
        height: 160px
      }
    }

    #frigelarProductRecommendations_v1-wi300035 .show-modal {
      display: flex;
      margin: 0 20px 0 auto;
      color: #4e77ad
    }

    #frigelarProductRecommendations_v1-wi300035 .show-modal svg {
      margin: auto 5px
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 6;
      width: 100%;
      height: 100%;
      background: #fff
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products .top {
      background-color: #52ae32;
      height: 50px;
      display: flex;
      color: #fff;
      font-weight: bolder;
      z-index: 7
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products .top .text {
      margin: auto auto auto 15px
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products .top .close-button {
      margin: auto 15px auto auto
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products .product-listing {
      display: grid;
      grid-template-columns: 50% 50%;
      position: fixed;
      top: 0;
      overflow-y: scroll;
      height: 100%;
      width: 100%;
      padding-top: 50px;
      padding-bottom: 50px;
      z-index: -1
    }

    #frigelarProductRecommendations_v1-wi300035 .modal-listing-products .product-listing .product-box-container {
      display: flex;
      margin: 30px auto
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-container {
      display: block;
      margin: 0;
      position: relative;
      width: 100%
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .frigelar-green-primary.titleTwo {
      padding-left: 0;
      margin-bottom: 32px
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .titleTwo,
    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel h2 {
      font-size: 21px
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .parent {
      background-size: cover;
      position: fixed;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      z-index: -100
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .wrapper,
    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .row {
      height: 100%;
      max-width: 100%
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-prev,
    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-next {
      top: 42%;
      z-index: 1
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-prev.disabled,
    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-next.disabled {
      opacity: .1
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-prev {
      left: 0
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-next {
      right: 0
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-track {
      display: flex
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-list {
      max-width: 100%
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item {
      display: inline-block;
      padding: 0;
      vertical-align: top;
      min-width: 92px
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item>* {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 100%
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item * {
      outline: none !important
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .thumbnail {
      border: 0;
      border-radius: 50%;
      position: relative;
      overflow: hidden;
      display: block;
      margin: 0 auto;
      filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.16));
      max-height: 140px;
      max-width: 140px
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .thumbnail img {
      display: block;
      margin: 0 auto
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .category-title {
      display: flex;
      justify-content: center;
      line-height: 1em;
      text-align: center;
      width: 100%;
      margin: 12px auto 0
    }

    #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .category-title>* {
      overflow-wrap: break-word
    }

    @media (min-width:991px) {
      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel {
        margin-top: 42px;
        margin-bottom: 42px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .frigelar-green-primary.titleTwo {
        line-height: 1em
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .slick-list {
        overflow: hidden;
        margin: 0 20px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item {
        width: 174px;
        margin-left: 18px;
        margin-right: 18px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .thumbnail img {
        width: 140px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-item .category-title {
        font-size: 16px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .wrapper,
      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .row {
        padding-left: 40px;
        padding-right: 20px
      }
    }

    @media (max-width:991px) {
      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel {
        margin-top: 20px;
        margin-bottom: 0
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-container .thumbnail img {
        width: 75px;
        height: 75px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .category-carousel .carousel-container .category-title {
        font-size: 10px
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .carousel-overflow {
        overflow: visible;
        margin: 0;
        padding-left: 0;
        padding-right: 0
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .titleTwo {
        display: none
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .carousel-item {
        width: 92px;
        min-height: 98px;
        margin-right: 20px;
        margin-left: 0
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .carousel-item:last-child {
        margin-right: 0
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .wrapper,
      #frigelarHomeCategoryCarousel_v1-wi300030 .row {
        padding-left: 0;
        padding-right: 0
      }

      #frigelarHomeCategoryCarousel_v1-wi300030 .slick-list {
        margin-top: 20px;
        margin-bottom: 20px;
        margin-left: -5px
      }
    }

    #frigelarHomeImageMosaic_v1-wi300031 .mosaic-container {
      margin-top: 42px;
      margin-bottom: 42px;
      padding-left: 16px;
      padding-right: 16px
    }

    #frigelarHomeImageMosaic_v1-wi300031 img {
      width: 100%;
      display: block
    }

    #frigelarHomeImageMosaic_v1-wi300031 .row {
      margin: 0
    }

    #frigelarHomeImageMosaic_v1-wi300031 .no-padding {
      padding: 0
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeImageMosaic_v1-wi300031 .mosaic-container {
        margin-top: 40px;
        margin-bottom: 40px
      }
    }

    #frigelarChatbot_v1-wi4100002 .chat {
      position: fixed;
      bottom: 35px;
      right: 15px;
      height: 4vw;
      min-height: 48px;
      max-height: 60px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 5
    }

    #frigelarChatbot_v1-wi4100002 .chat__btn {
      width: 18px;
      height: 18px;
      background-color: #183a68;
      color: #fff;
      border: none;
      border-radius: 50%;
      padding: 1px;
      cursor: pointer
    }

    #frigelarChatbot_v1-wi4100002 .chat__btn:not(:last-child) {
      margin-bottom: 2px
    }

    #frigelarChatbot_v1-wi4100002 .chat__icon {
      width: 100%;
      height: 100%;
      border-radius: 50%
    }

    #frigelarChatbot_v1-wi4100002 .hide {
      display: none
    }

    #frigelarPasswordReset_v6-wi300018 *,
    #frigelarPasswordReset_v6-wi300018 *:focus,
    #frigelarPasswordReset_v6-wi300018 *:hover {
      outline: none
    }

    #frigelarPasswordReset_v6-wi300018 #resetPasswordModal {
      -ms-overflow-style: none;
      scrollbar-width: none
    }

    #frigelarPasswordReset_v6-wi300018 #resetPasswordModal::-webkit-scrollbar {
      display: none
    }

    #frigelarPasswordReset_v6-wi300018 .close {
      opacity: 1
    }

    #frigelarPasswordReset_v6-wi300018 .modal-body {
      padding: 0;
      display: flex;
      justify-content: center
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password {
      display: flex;
      align-items: center;
      justify-content: center
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper {
      width: 100%;
      max-width: 420px;
      padding: 32px 16px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .page-title {
      margin-bottom: 32px;
      font-weight: 900
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .row+.row {
      margin-top: 16px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .row #passStrong {
      margin-top: 4px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .row #passStrong #statusBar {
      height: 4px;
      border-radius: 4px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .row #passStrong #textStatus {
      color: #686868;
      font-size: 10px;
      float: inline-end;
      margin-top: 4px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message {
      padding-left: 15px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message .message-container {
      display: flex
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message .message-container li {
      list-style: disc
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message .message-container .message-password {
      margin-top: 4px;
      font-size: 10px;
      line-height: 16px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message .message-container .confirmation {
      color: #52ae32
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .container-message .message-container .icon-checked {
      width: 10px;
      color: #52ae32;
      margin-left: 5px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper {
      position: relative
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input-label {
      width: 100%;
      display: block;
      margin-bottom: 4px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input {
      width: 100%;
      height: 40px;
      border: 1px solid #9e9e9e;
      box-sizing: border-box;
      border-radius: 4px;
      padding: 0 16px;
      color: #1d1d1d;
      font-family: "Montserrat";
      font-style: normal;
      font-weight: normal;
      font-size: 14px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input::placeholder {
      color: #dadada
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input:focus {
      outline: none;
      border: 1px solid #686868;
      box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.16);
      background-color: transparent
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input:focus::placeholder {
      opacity: 0
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .custom-input:disabled {
      border: 1px solid #dadada
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .input-error {
      border: 1px solid #d00000
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .show-password {
      position: absolute;
      top: 48%;
      right: 16px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .field-wrapper .lower-position {
      top: 58%
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .save-button {
      width: 100%;
      margin-top: 40px;
      font-weight: bold
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .validation-error {
      background: #ffd6d6;
      border-radius: 4px;
      height: 40px;
      margin-left: 0;
      margin-right: 0;
      display: flex
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .validation-error div {
      display: flex;
      align-items: center;
      justify-content: center
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .validation-error div img {
      width: 16px;
      height: 16px;
      margin-right: 16px
    }

    #frigelarPasswordReset_v6-wi300018 .frigelar-reset-password .form-wrapper .validation-error .validation-error-msg {
      font-style: normal;
      font-weight: bold;
      font-size: 10px;
      line-height: 40px;
      text-align: center;
      color: #d00000
    }

    #frigelarHomeBannerCard_v1-wi300027 .overflow-upper {
      margin-top: 0 !important
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container {
      margin-top: -42vh !important;
      max-width: 1360px;
      display: block;
      margin: 0 auto;
      padding-right: 8px;
      padding-left: 8px;
      display: flex
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding {
      padding: 0 8px;
      display: flex
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper {
      background-color: #fafafa;
      padding: 17px 17px 16px 17px;
      box-shadow: 0 0 8px -3px rgba(0, 0, 0, 0.4);
      width: 100%;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .title {
      color: #154585;
      font-size: 16px !important;
      margin-bottom: 9px
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-wrapper .card-cover {
      width: 100%;
      object-fit: cover;
      height: 297px
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid {
      overflow: hidden;
      display: flex;
      align-items: top;
      flex-wrap: wrap;
      justify-content: flex-start
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a {
      text-align: center;
      width: calc(50% - 8px);
      text-decoration: none;
      font-size: 9px;
      font-family: 'Montserrat';
      letter-spacing: 0;
      color: #000;
      opacity: 1
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a:hover {
      text-shadow: 0 0 .01px #000;
      text-decoration: underline
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a:nth-child(2n + 1) {
      margin-right: 16px
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a:nth-child(1n + 3) {
      margin-top: 16px
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a #cc_img__resize_wrapper {
      height: auto !important;
      min-height: 0 !important
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .image-grid a p {
      text-align: center;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      width: 100%
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .card-link {
      margin-top: auto;
      display: flex;
      justify-content: flex-end
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .card-link a {
      font-size: .8em;
      color: #52ae32
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .card-link a:hover {
      text-decoration: underline
    }

    #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .banner-card-wrapper .card-link a:hover p {
      text-shadow: 0 0 .01px #000
    }

    @media (max-width:1239px) and (min-width:768px) {
      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .home-card:nth-child(4) {
        display: none
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .home-card {
        width: 33%
      }
    }

    @media (max-width:850px) {
      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container {
        flex-wrap: wrap;
        margin-top: 0
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding {
        height: 230px;
        margin-bottom: 16px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper {
        margin-top: 0;
        height: 230px;
        padding: 8px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper .title {
        height: 56px;
        font-size: 14px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper .image-wrapper img {
        height: 120px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .card-link a.primaryBtn {
        font-size: .7em;
        padding: 8px 12px
      }
    }

    @media (max-width:576px) {
      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container {
        flex-wrap: wrap;
        margin-top: 0
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding {
        height: 230px;
        margin-bottom: 16px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper {
        margin-top: 0;
        height: 230px;
        padding: 8px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper .title {
        height: 56px
      }

      #frigelarHomeBannerCard_v1-wi300027 .banner-cards-container .condensed-padding .banner-card-wrapper .image-wrapper img {
        height: 120px
      }
    }

    #frigelarHomeBannerCard_v1-wi300028 .overflow-upper {
      margin-top: 0 !important
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container {
      max-width: 1360px;
      display: block;
      margin: 0 auto;
      padding-right: 8px;
      padding-left: 8px;
      display: flex
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container.card-overflow .banner-card-wrapper {
      margin-top: -42vh
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding {
      padding: 0 8px;
      display: flex
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper {
      background-color: #fafafa;
      padding: 17px 17px 16px 17px;
      box-shadow: 0 0 8px -3px rgba(0, 0, 0, 0.4);
      width: 100%;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .title {
      color: #154585;
      font-size: 16px !important;
      margin-bottom: 9px
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-wrapper .card-cover {
      width: 100%;
      object-fit: cover;
      height: 297px
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid {
      overflow: hidden;
      display: flex;
      align-items: top;
      flex-wrap: wrap;
      justify-content: flex-start
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a {
      text-align: center;
      width: calc(50% - 8px);
      text-decoration: none;
      font-size: 9px;
      font-family: 'Montserrat';
      letter-spacing: 0;
      color: #000;
      opacity: 1
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a:hover {
      text-shadow: 0 0 .01px #000;
      text-decoration: underline
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a:nth-child(2n + 1) {
      margin-right: 16px
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a:nth-child(1n + 3) {
      margin-top: 16px
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a #cc_img__resize_wrapper {
      height: auto !important;
      margin-bottom: .2em;
      min-height: 0 !important
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .image-grid a p {
      text-align: center;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      width: 100%
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .card-link {
      margin-top: auto;
      display: flex;
      justify-content: flex-end
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .card-link a {
      font-size: .8em;
      color: #52ae32
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .card-link a:hover {
      text-decoration: underline
    }

    #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .banner-card-wrapper .card-link a:hover p {
      text-shadow: 0 0 .01px #000
    }

    @media (max-width:1239px) and (min-width:768px) {
      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .home-card:nth-child(4) {
        display: none
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .home-card {
        width: 33%
      }
    }

    @media (max-width:850px) {
      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container {
        flex-wrap: wrap;
        margin-top: 0
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding {
        height: 230px;
        margin-bottom: 16px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper {
        margin-top: 0;
        height: 230px;
        padding: 8px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper .title {
        height: 56px;
        font-size: 14px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper .image-wrapper img {
        height: 120px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .card-link a.primaryBtn {
        font-size: .7em;
        padding: 8px 12px
      }
    }

    @media (max-width:576px) {
      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container {
        flex-wrap: wrap;
        margin-top: 0
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding {
        height: 230px;
        margin-bottom: 16px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper {
        margin-top: 0;
        height: 230px;
        padding: 8px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper .title {
        height: 56px
      }

      #frigelarHomeBannerCard_v1-wi300028 .banner-cards-container .condensed-padding .banner-card-wrapper .image-wrapper img {
        height: 120px
      }
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal {
      background: rgba(0, 0, 0, 0.5)
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal .checkbox-container {
      margin-bottom: 30px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal {
      min-height: 500px;
      display: flex;
      flex-direction: column;
      justify-content: space-between
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-mini-header {
      font-size: 12px;
      display: flex;
      align-items: center;
      color: #3a7a23;
      background: #fafafa;
      border-radius: 4px;
      padding: 0 16px 16px;
      justify-content: center
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-mini-header img {
      margin-right: 8px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .mdl-body {
      min-height: 280px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list-btn {
      background-color: transparent;
      border: 0;
      border-top: 1px solid #9e9e9e;
      border-bottom: 1px solid #9e9e9e;
      outline: none;
      margin-top: 16px;
      padding: 12px;
      width: 100%;
      transition: color .4s ease
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list-btn .icon-plus {
      margin-right: 8px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list-btn:hover,
    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list-btn.active {
      color: #52ae32 !important
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list {
      display: none;
      height: 38px;
      margin-bottom: 24px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list.active {
      display: block !important
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list.active .check {
      animation: fadeIn .1s ease forwards;
      -webkit-animation: fadeIn .1s ease forwards
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list.active #new-list-name {
      animation: bounceIn .3s ease forwards;
      -webkit-animation: bounceIn .3s ease forwards
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list .checkbox-container {
      height: 100%;
      display: flex;
      align-items: center
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list .checkbox-container .check {
      top: 50%;
      transform: translateY(-50%)
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list .checkbox-container #new-list-name {
      border: 1px solid #686868;
      box-sizing: border-box;
      cursor: text;
      filter: drop-shadow(2px 2px 8px rgba(0, 0, 0, 0.16));
      border-radius: 4px;
      opacity: 1;
      width: calc(60%);
      margin-left: 40px;
      height: 38px;
      outline: none;
      padding: 0 8px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .new-list .checkbox-container #new-list-name.error {
      border: 1px solid #d00000
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .checkbox-container {
      font-family: "Montserrat";
      font-style: normal;
      font-weight: normal;
      font-size: 14px;
      line-height: 17px;
      color: #686868;
      padding-left: 40px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .checkbox-container+label {
      margin-top: 32px
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-footer {
      border: 0;
      padding: 24px 32px;
      display: flex;
      margin-top: auto;
      width: 100%;
      justify-content: space-between
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-footer button {
      width: 45%;
      max-width: 160px
    }

    @media (max-width:767px) {
      #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-footer button {
        max-width: 320px
      }
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-footer button:first-child {
      margin-right: auto
    }

    #frigelarAddToWishList_v1-wi300025 #addToWishListSection #wishListModal #addWishlist-modal .modal-footer button:last-child {
      margin-left: auto
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu {
      font-family: 'Montserrat', Arial, sans-serif;
      font-size: 14px;
      color: #686868
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .modal .modal-content {
      border: none
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .row {
      margin: 0
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu *,
    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu *:focus,
    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu *:hover {
      outline: none
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .paragraphTwo.frigelar-gray-one.service {
      margin-top: 32px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .icon-warning {
      font-size: 32px;
      color: #dba210
    }

    @media (min-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .modal .modal-full-height {
        width: 582px
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .close {
      position: absolute;
      right: 32px;
      z-index: 15;
      opacity: 1
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .subtitle {
      margin-top: 16px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .modal-body {
      padding-left: 16px;
      padding-right: 16px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .full-width-button {
      width: 100%
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .attributes-container {
      margin-bottom: 84px;
      text-align: center
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .attributes-container .tension-content {
      margin: 24px auto;
      display: block
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .attributes-container .cicle-content {
      margin: 24px auto;
      display: block
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .attributes-container .cicle-content img {
      width: 24px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .modal-footer {
      padding: 0
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .underline {
      text-decoration: underline
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .product-details {
      margin-top: 16px;
      display: flex;
      justify-content: center;
      align-items: center
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .product-details img {
      height: 140px;
      margin-right: 40px
    }

    @media (max-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .product-details {
        text-align: center;
        display: block
      }

      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .product-details p {
        text-align: center
      }

      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .product-details img {
        margin: 0
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .title-wrapper {
      position: relative;
      margin-top: -48px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options {
      display: flex;
      justify-content: left;
      align-items: center;
      flex-wrap: wrap;
      margin-top: 16px
    }

    @media (max-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options {
        justify-content: center
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .warranty-item {
      height: 100px;
      width: 48%;
      display: inline-flex;
      justify-content: left;
      align-items: center;
      box-shadow: 0 4px 4px rgba(0, 0, 0, 0.08);
      background: #fafafa;
      margin-right: 8px;
      padding: 16px 12px 12px 8px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .warranty-item span {
      font-weight: normal
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .warranty-item input {
      margin-top: 0;
      margin-right: 8px
    }

    @media (max-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .warranty-item {
        width: 80%;
        margin-top: 16px
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .no-warranty {
      margin-top: 16px;
      height: 48px;
      display: flex;
      width: 100%;
      align-items: center;
      justify-content: flex-start;
      justify-items: flex-start
    }

    @media (max-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .warranty-options .no-warranty {
        width: 80%;
        margin-top: 16px
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .input-block {
      margin-top: 32px;
      margin-bottom: 32px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .input-block .row {
      margin-top: 16px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .buttons-wrapper {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 48px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .buttons-wrapper button {
      width: 45%
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .buttons-wrapper .cancel-btn {
      border-color: #686868
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .buttons-wrapper .cancel-btn:hover {
      background: none
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container {
      display: flex;
      justify-content: center;
      align-items: center
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content {
      width: 95%
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 10px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-icon img {
      width: 30px
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-text {
      padding: 0 25px;
      text-align: center;
      font-size: 12px;
      font-weight: normal;
      line-height: 17px;
      letter-spacing: 0
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-text span {
      display: inline-block
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-text>*:nth-child(1n) {
      margin-top: 10px
    }

    @media only screen and (max-width : 991px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .panel-container .panel-content .panel-text {
        padding: 0
      }
    }

    @media (max-width:576px) {
      #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .modal-body {
        padding-left: 30px;
        padding-right: 30px
      }
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .button-disabled {
      opacity: .6
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .button-disabled:hover {
      cursor: not-allowed
    }

    #frigelarWarrantySidemenu_v1-wi300020 .frigelar-warranty-sidemenu .separator {
      margin: 1rem auto;
      width: 514px;
      height: 0;
      border: 1px solid #707070
    }

    #frigelarHomeBanner_v1-wi4000002 .header-line {
      width: 100%;
      text-align: center;
      overflow: hidden;
      max-width: 1350px
    }

    #frigelarHomeBanner_v1-wi4000002 .header-background,
    #frigelarHomeBanner_v1-wi4000002 .centeredContent {
      position: relative;
      max-width: 1350px;
      display: block;
      margin: 0 auto;
      display: flex;
      max-height: 250px;
      background: none !important
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-carousel {
      position: relative;
      display: block;
      overflow: visible
    }

    @media (min-width:577px) {
      #frigelarHomeBanner_v1-wi4000002 .slick-carousel {
        padding-left: 0
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-carousel .slick-track {
      display: inline-flex
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-carousel .slick-list {
      margin: 0 auto
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .slick-carousel .slick-list {
        width: 100%;
        overflow: visible
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slider-wrapper {
      display: none
    }

    #frigelarHomeBanner_v1-wi4000002 .arrow-wrapper2 {
      justify-content: space-between;
      width: 100%;
      display: flex;
      top: 40%;
      position: absolute
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .arrow-wrapper2 {
        top: 30%
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .arrow-wrapper2 .prev {
      z-index: 1;
      left: 5px;
      top: 100px;
      cursor: pointer;
      color: #fff;
      font-size: 25px;
      text-shadow: 0 2px #183a68
    }

    #frigelarHomeBanner_v1-wi4000002 .arrow-wrapper2 .next {
      z-index: 1;
      right: 15px;
      top: 100px;
      cursor: pointer;
      color: #fff;
      font-size: 25px;
      text-shadow: 0 2px #183a68
    }

    #frigelarHomeBanner_v1-wi4000002 .item {
      position: relative;
      max-width: 1350px
    }

    #frigelarHomeBanner_v1-wi4000002 .item a {
      width: auto
    }

    #frigelarHomeBanner_v1-wi4000002 .item .item-link {
      display: block;
      margin: 0 auto;
      padding-right: 8px;
      padding-left: 8px;
      width: 100%;
      height: calc(58%);
      position: absolute
    }

    #frigelarHomeBanner_v1-wi4000002 .item .item-link>* {
      height: 100%;
      width: 100%;
      max-width: 1340px;
      display: block;
      margin: 0 auto
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .item .item-link {
        height: 100%
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-banner .pointer {
      cursor: pointer
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control {
      background: none;
      width: 100px;
      left: -70px;
      opacity: 1
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control.right {
      width: 100px;
      right: -70px;
      left: unset
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control .banner-arrow {
      color: #fff;
      font-size: 25px;
      position: absolute;
      top: 30%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .carousel-control .banner-arrow {
        top: 50%;
        transform: translateY(-50%)
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slider-wrapper {
      display: none
    }

    @media only screen and (min-width : 992px) {
      #frigelarHomeBanner_v1-wi4000002 .gradient {
        display: flex;
        margin: auto auto 0 auto;
        height: 50%;
        width: 100vw;
        position: absolute;
        top: 50%;
        background: none
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .item {
      position: relative
    }

    #frigelarHomeBanner_v1-wi4000002 .item .item-link {
      display: block;
      margin: 0 auto;
      padding-right: 8px;
      padding-left: 8px;
      width: 100%;
      height: calc(58%);
      position: absolute
    }

    #frigelarHomeBanner_v1-wi4000002 .item .item-link>* {
      height: 100%;
      width: 100%;
      max-width: 1340px;
      display: block;
      margin: 0 auto
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .item .item-link {
        height: 100%
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-banner .pointer {
      cursor: pointer
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-banner img {
      max-height: 200px;
      width: 100%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .carousel-banner img {
        width: 100vw;
        height: auto
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control {
      background: none;
      width: 100px;
      left: -70px;
      opacity: 1
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control.right {
      width: 100px;
      right: -70px;
      left: unset
    }

    #frigelarHomeBanner_v1-wi4000002 .carousel-control .banner-arrow {
      color: #fff;
      font-size: 25px;
      position: absolute;
      top: 30%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .carousel-control .banner-arrow {
        top: 50%;
        transform: translateY(-50%)
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .right .banner-arrow {
      right: unset;
      left: 0
    }

    #frigelarHomeBanner_v1-wi4000002 .left .banner-arrow {
      left: unset;
      right: 0
    }

    #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box {
      top: 10%;
      left: 20%;
      position: absolute;
      pointer-events: none;
      max-width: 1000px;
      width: 100%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box {
        left: 10%;
        width: 80%
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box .description {
      margin: 0;
      font-size: 20px;
      text-shadow: 1px 2px 6px rgba(0, 0, 0, 0.5);
      max-height: 60px;
      overflow: hidden
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box .description {
        font-size: 14px;
        max-height: 45px
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box .title {
      font-size: 32px;
      line-height: 1.4;
      font-weight: bold;
      text-shadow: 1px 2px 6px rgba(0, 0, 0, 0.5);
      margin-bottom: 8px;
      max-height: 90px;
      overflow: hidden
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi4000002 .home-banner-title-box .title {
        font-size: 24px;
        max-height: 65px
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .banner-content-wrapper {
      position: relative;
      left: calc(-50vw + 50%);
      width: 100vw
    }

    #frigelarHomeBanner_v1-wi4000002 .banner-content-wrapper #cc_img__resize_wrapper {
      align-items: flex-start;
      display: flex;
      overflow: hidden
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .banner-content-wrapper #cc_img__resize_wrapper {
        align-items: center
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-dots {
      position: relative;
      max-width: 1350px;
      display: flex;
      justify-content: center;
      bottom: 0;
      margin: 0;
      padding: 1rem 0;
      list-style-type: none
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .slick-dots {
        bottom: -42px
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-dots li {
      margin: 0 3px
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-dots button {
      display: block;
      width: 12px;
      height: 12px;
      padding: 0;
      border-radius: 100%;
      background-color: #52ae32;
      opacity: .35;
      text-indent: -9999px;
      border: 1px solid #a29f9f
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi4000002 .slick-dots button {
        background-color: #52ae32
      }
    }

    #frigelarHomeBanner_v1-wi4000002 .slick-dots li.slick-active button {
      opacity: 1
    }

    #frigelarHomeBanner_v1-wi2200005 .header-background {
      position: relative
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-carousel {
      position: relative;
      display: block;
      overflow: visible
    }

    @media (min-width:577px) {
      #frigelarHomeBanner_v1-wi2200005 .slick-carousel {
        padding-left: 0
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-carousel .slick-track {
      display: inline-flex
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-carousel .slick-list {
      margin: 0 auto
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .slick-carousel .slick-list {
        width: 100%;
        overflow: visible
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .slider-wrapper {
      display: none
    }

    #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper {
      position: relative;
      max-height: 0;
      overflow: visible
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper {
        position: absolute;
        bottom: 0;
        left: 0;
        margin: auto;
        padding-bottom: 25px;
        right: 0;
        top: 0
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper .prev {
      position: absolute;
      z-index: 1;
      left: 5px;
      top: 10vw;
      cursor: pointer;
      color: #fff;
      font-size: 25px;
      text-shadow: 0 2px #183a68
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper .prev {
        top: 0
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper .next {
      position: absolute;
      z-index: 1;
      right: 5px;
      top: 10vw;
      cursor: pointer;
      color: #fff;
      font-size: 25px;
      text-shadow: 0 2px #183a68
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .arrow-wrapper .next {
        top: 0
      }
    }

    @media only screen and (min-width : 992px) {
      #frigelarHomeBanner_v1-wi2200005 .gradient {
        display: flex;
        margin: auto auto 0 auto;
        height: 50%;
        width: 100vw;
        position: absolute;
        top: 50%;
        background: linear-gradient(to top, #fff, transparent)
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .item {
      width: 100vw !important;
      position: relative
    }

    #frigelarHomeBanner_v1-wi2200005 .item .item-link {
      display: block;
      margin: 0 auto;
      padding-right: 8px;
      padding-left: 8px;
      width: 100%;
      height: calc(58%);
      position: absolute
    }

    #frigelarHomeBanner_v1-wi2200005 .item .item-link>* {
      height: 100%;
      width: 100%;
      max-width: 1340px;
      display: block;
      margin: 0 auto
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi2200005 .item .item-link {
        height: 100%
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .carousel-banner .pointer {
      cursor: pointer
    }

    #frigelarHomeBanner_v1-wi2200005 .carousel-banner img {
      width: 100vw;
      height: auto
    }

    #frigelarHomeBanner_v1-wi2200005 .carousel-control {
      background: none;
      width: 100px;
      left: -70px;
      opacity: 1
    }

    #frigelarHomeBanner_v1-wi2200005 .carousel-control.right {
      width: 100px;
      right: -70px;
      left: unset
    }

    #frigelarHomeBanner_v1-wi2200005 .carousel-control .banner-arrow {
      color: #fff;
      font-size: 25px;
      position: absolute;
      top: 30%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .carousel-control .banner-arrow {
        top: 50%;
        transform: translateY(-50%)
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .right .banner-arrow {
      right: unset;
      left: 0
    }

    #frigelarHomeBanner_v1-wi2200005 .left .banner-arrow {
      left: unset;
      right: 0
    }

    #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box {
      top: 10%;
      left: 20%;
      position: absolute;
      pointer-events: none;
      max-width: 1000px;
      width: 100%
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box {
        left: 10%;
        width: 80%
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box .description {
      margin: 0;
      font-size: 20px;
      text-shadow: 1px 2px 6px rgba(0, 0, 0, 0.5);
      max-height: 60px;
      overflow: hidden
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box .description {
        font-size: 14px;
        max-height: 45px
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box .title {
      font-size: 32px;
      line-height: 1.4;
      font-weight: bold;
      text-shadow: 1px 2px 6px rgba(0, 0, 0, 0.5);
      margin-bottom: 8px;
      max-height: 90px;
      overflow: hidden
    }

    @media (max-width:991px) {
      #frigelarHomeBanner_v1-wi2200005 .home-banner-title-box .title {
        font-size: 24px;
        max-height: 65px
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .banner-content-wrapper {
      position: relative;
      left: calc(-50vw + 50%);
      width: 100vw
    }

    #frigelarHomeBanner_v1-wi2200005 .banner-content-wrapper #cc_img__resize_wrapper {
      align-items: flex-start;
      display: flex;
      overflow: hidden
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi2200005 .banner-content-wrapper #cc_img__resize_wrapper {
        align-items: center
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-dots {
      display: flex;
      justify-content: center;
      bottom: 42vh;
      margin: 0;
      padding: 1rem 0;
      list-style-type: none
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi2200005 .slick-dots {
        bottom: -42px
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-dots li {
      margin: 0 3px
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-dots button {
      display: block;
      width: 12px;
      height: 12px;
      padding: 0;
      border-radius: 100%;
      background-color: #fff;
      opacity: .35;
      text-indent: -9999px;
      border: 1px solid #a29f9f
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeBanner_v1-wi2200005 .slick-dots button {
        background-color: #52ae32
      }
    }

    #frigelarHomeBanner_v1-wi2200005 .slick-dots li.slick-active button {
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modal-header {
      margin: 0 auto;
      border-bottom: 0 solid #e5e5e5
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modal-dialog {
      width: 872px;
      padding: 4px 4px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalTitleText {
      text-align: center;
      font: normal normal 800 22px/31px Montserrat;
      letter-spacing: 0;
      opacity: 1;
      max-width: 426px;
      margin: 0 auto
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modal-header .close {
      position: absolute;
      right: 16px;
      top: 16px;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalCloseButtonText {
      text-align: center;
      font: normal normal normal 10px/13px Montserrat;
      letter-spacing: 0;
      color: #686868;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .boxRight {
      padding: 6px 15px 0 15px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .boxRight .primaryBtn {
      width: 100%
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .inputBoxRight {
      padding: 3px 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#nameAbandonCart {
      width: 100%;
      padding: 10px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#nameAbandonCart::placeholder {
      color: #dadada
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#celularAbandonCart {
      width: 100%;
      padding: 10px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#celularAbandonCart::placeholder {
      color: #dadada
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#emailAbandonCart {
      width: 100%;
      padding: 10px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 input#emailAbandonCart::placeholder {
      color: #dadada
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .labelModal {
      padding: 0 0 4px 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalSubtitleText {
      margin-top: 10px;
      text-align: center;
      font: normal normal bold 12px/15px Montserrat;
      letter-spacing: 0;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalInformacoesTab {
      border: 1px solid #50ae32;
      border-radius: 4px;
      opacity: 1;
      padding: 10px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalInputLabel {
      text-align: left;
      font: normal normal normal 10px/13px Montserrat;
      letter-spacing: 0;
      color: #686868;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalInput {
      background: #fff 0 0 no-repeat padding-box;
      border: 1px solid #9e9e9e;
      border-radius: 4px;
      opacity: 1;
      text-align: left;
      font: normal normal normal 14px/18px Montserrat;
      letter-spacing: 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalBodyDisclamer {
      text-align: center;
      font: normal normal normal 10px/13px Montserrat;
      letter-spacing: 0;
      opacity: 1;
      padding: 10px 0 0 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalMessageNormal {
      font-weight: bold;
      padding: 0 0 8px 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .btnReceberPopup {
      padding: 10px 0 0 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalMessageGreen {
      font-weight: bold
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .product-img {
      width: 100px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalProductName {
      text-align: left;
      font: normal normal normal 12px/17px Montserrat;
      letter-spacing: 0;
      color: #1d1d1d;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalProducQuantity {
      text-align: left;
      font: normal normal normal 10px/13px Montserrat;
      letter-spacing: 0;
      color: #9e9e9e;
      opacity: 1;
      padding: 3px 0 3px 0
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalProducPrice {
      text-align: left;
      font: normal normal bold 10px/13px Montserrat;
      letter-spacing: 0;
      color: #1d1d1d;
      opacity: 1
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalProductsPading {
      padding-left: 10px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalItemContainer {
      padding-bottom: 20px;
      padding-top: 15px;
      border-bottom: 1px solid #dadada
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .modalItemContainer:last-of-type {
      border-bottom: 0 solid;
      border-bottom: none
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .error-message {
      color: #d00000;
      display: inline-block;
      font-size: 10px;
      margin-top: 2px
    }

    #frigelarpopupabandonodepagina_v1-wi3100001 .input-error {
      border-color: #d00000
    }

    #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper {
      margin-top: 25px;
      margin-bottom: 25px;
      display: block
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper {
        margin-top: 0
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper h1,
    #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper .title {
      font-size: 21px
    }

    @media (min-width:991px) {

      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper h1,
      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper .title {
        line-height: 1em
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper .product-box-container {
      margin-top: 28px;
      margin-bottom: 20px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper .product-box-container {
        margin-left: 0;
        margin-right: 0
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-wrapper {
        margin-top: 20px;
        margin-bottom: 40px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi900006 .product-recommendations-listing {
        display: flex;
        flex-wrap: wrap;
        margin-left: -16px;
        margin-right: -16px
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .title {
      color: #52ae32;
      margin-bottom: 16px;
      padding-left: 25px
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi900006 .title {
        font-size: 20px;
        line-height: 26px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi900006 .title {
        padding-left: 0;
        margin-left: 16px
      }
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-slider {
        margin-left: -16px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-slider .product-box-container {
        width: 178px;
        box-shadow: none
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-slider .product-box-container .link-container {
        border-right: 2px solid #d6d6d6
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-slider .product-box-container .item-price .new-price-container .discount {
        width: 28px;
        padding: 1px 0
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-slider .product-box-container .item-price .new-price-container .discount p {
        font-size: 8px;
        line-height: 11px;
        letter-spacing: .2px
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel {
      position: relative;
      display: block;
      overflow: visible
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .stamps-container {
        width: 100%
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .stamps-container .discount .sel {
        width: 100%;
        align-items: center;
        font-size: .5rem;
        padding-left: 8px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .stamps-container .discount .sel.formated {
        display: flex
      }
    }

    @media only screen and (max-width : 991px) and (min-width:577px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .product-box-container .item-image img {
        width: 100%;
        height: 100%
      }
    }

    @media only screen and (max-width : 991px) and (max-width:991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .product-box-container {
        padding: 0;
        margin-bottom: 28px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .product-box-container .item-image {
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .product-box-container .item-image img {
        width: 132px;
        height: 132px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    @media only screen and (max-width : 991px) and (max-width:650px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .slick-track {
        display: flex;
        flex-wrap: wrap;
        max-width: 100% !important
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-track {
      display: inline-flex
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-list {
      width: 93%;
      overflow: hidden;
      margin: 0 auto
    }

    @media (max-width:991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-list {
        width: 100%;
        overflow: visible
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-prev {
      color: #4e77ad;
      left: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-prev.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-next {
      color: #4e77ad;
      right: 25px;
      top: 250px
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel .slick-next.disabled {
      opacity: .1
    }

    #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view {
      width: 100%
    }

    @media (min-width:1980px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .product-box-container {
        width: 300px
      }
    }

    @media only screen and (max-width : 991px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .product-box-container {
        width: calc(50% - 2px)
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .product-box-container:nth-child(2n + 1) {
        margin-right: 4px
      }
    }

    @media (max-width:576px) {
      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .product-box-container .item-image {
        height: 160px
      }

      #frigelarProductRecommendations_v1-wi900006 .slick-carousel.listing-view .product-box-container .item-image img {
        width: 160px;
        height: 160px
      }
    }

    #frigelarProductRecommendations_v1-wi900006 .show-modal {
      display: flex;
      margin: 0 20px 0 auto;
      color: #4e77ad
    }

    #frigelarProductRecommendations_v1-wi900006 .show-modal svg {
      margin: auto 5px
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 6;
      width: 100%;
      height: 100%;
      background: #fff
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products .top {
      background-color: #52ae32;
      height: 50px;
      display: flex;
      color: #fff;
      font-weight: bolder;
      z-index: 7
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products .top .text {
      margin: auto auto auto 15px
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products .top .close-button {
      margin: auto 15px auto auto
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products .product-listing {
      display: grid;
      grid-template-columns: 50% 50%;
      position: fixed;
      top: 0;
      overflow-y: scroll;
      height: 100%;
      width: 100%;
      padding-top: 50px;
      padding-bottom: 50px;
      z-index: -1
    }

    #frigelarProductRecommendations_v1-wi900006 .modal-listing-products .product-listing .product-box-container {
      display: flex;
      margin: 30px auto
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content {
      background: linear-gradient(92.13deg, #52ae32 0, #6cd9bf 100%);
      height: 283px;
      width: 100%;
      text-align: center
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content {
      max-width: 861px;
      display: inline-block;
      text-align: center
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .btn-container {
      text-align: center;
      margin-top: 32px
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .btn-container .submmitNews,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .btn-container .submmitNewsMobile {
      width: 425px;
      background: #fff;
      border: 1px solid #88d96c;
      box-sizing: border-box;
      border-radius: 4px;
      color: #52ae32;
      font-weight: bold;
      font-size: 16px;
      display: inline-block
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content input.form-error,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content select.form-error {
      border-color: rgba(218, 13, 13, 0.698) !important
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content span.error-message {
      visibility: hidden;
      color: rgba(218, 13, 13, 0.698);
      position: absolute;
      left: 0;
      font-weight: bold;
      bottom: -20px;
      font-size: 12px
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content span.show {
      visibility: visible
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .custom-select {
      position: relative;
      font-family: Arial;
      outline: none;
      color: #fff;
      border: 1px solid #fff;
      box-sizing: border-box;
      border-radius: 4px;
      text-align: left;
      font-weight: bold;
      max-width: 200px;
      height: 43px;
      margin-left: -10px;
      background-color: transparent
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .custom-select.gray {
      color: #686868
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-selected {
      background: none
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-selected:after {
      position: absolute;
      content: "";
      top: 20px;
      right: 10px;
      width: 0;
      height: 0;
      border: 6px solid transparent;
      border-color: #fff transparent transparent transparent
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-selected.select-arrow-active:after {
      border-color: transparent transparent #fff transparent;
      top: 12px
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-items div,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-selected {
      color: #fff;
      padding: 12px 7px;
      border: 1px solid transparent;
      border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
      cursor: pointer
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-items {
      position: absolute;
      background-color: #5cbf69;
      top: 100%;
      left: 0;
      right: 0;
      z-index: 99;
      height: 252px;
      overflow-y: auto
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-hide {
      display: none
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .select-items div:hover,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .same-as-selected {
      background-color: rgba(0, 0, 0, 0.1)
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .news-title {
      color: #fff;
      margin-top: 28px;
      text-align: center
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      max-width: 850px;
      margin: 32px auto 0
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group.msg-box,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box.msg-box {
      color: #fff
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group.hide,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box.hide,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group.msg-box,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box.msg-box {
      display: none
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group.show,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box.show {
      display: block
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content {
      width: 37.5%;
      max-width: 314px;
      position: relative
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content.select,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content.select {
      width: 25%
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content input,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content input {
      outline: none;
      color: #fff;
      border: 1px solid #fff;
      box-sizing: border-box;
      border-radius: 4px;
      font-family: "Montserrat";
      font-style: normal;
      font-weight: bold;
      font-size: 14px;
      line-height: 17px;
      padding-left: 8px;
      padding-top: 12px;
      padding-bottom: 12px;
      background: none;
      width: 100%
    }

    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content input::placeholder,
    #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content input::placeholder {
      color: #fff !important;
      opacity: 1
    }

    @media (max-width:980px) {
      #frigelarFormNewsletter_v1-wi600026 .news-content {
        height: auto !important
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content {
        width: 80%
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box {
        width: 100%;
        flex-wrap: wrap;
        margin-top: 20px
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content.select,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content.select {
        width: 100%;
        max-width: unset
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content span.error-message,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content span.error-message,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content.select span.error-message,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content.select span.error-message {
        position: relative;
        bottom: 0;
        text-align: left;
        margin: .2em 0 .5em
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .input-group .input-content input,
      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .msg-box .input-content input {
        margin: 4px auto;
        width: 100%
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .custom-select {
        width: 100%;
        max-width: unset;
        margin-top: 4px;
        margin-left: 0
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .btn-container {
        margin-bottom: 15px;
        margin-top: 13px
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-centered-content .btn-container .submmitNews {
        width: 100%
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .news-title {
        font-size: 16px;
        margin-top: 15px !important
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields {
        position: relative;
        padding: 1.5em 0
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields .input-name,
      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields .input-mail,
      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields .select {
        position: absolute;
        -webkit-transition: opacity .7s ease-in-out;
        -moz-transition: opacity .7s ease-in-out;
        -ms-transition: opacity .7s ease-in-out;
        -o-transition: opacity .7s ease-in-out;
        opacity: 0
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields .show {
        opacity: 1
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .input-group.fields .hide-container {
        display: none
      }

      #frigelarFormNewsletter_v1-wi600026 .news-content .submmitNewsMobile {
        width: 100% !important
      }
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-web-content {
      margin: 0 20px
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-description {
      color: #1d1d1d;
      font-size: 16px;
      line-height: 20px;
      margin: 28px auto
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-description>* {
      line-height: 20px
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-title {
      color: #1d1d1d;
      font-size: 36px;
      margin: 28px auto;
      width: fit-content
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-title .title-line {
      margin: 0 32px !important;
      background-color: #52ae32;
      border: 2px solid #52ae32
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-image {
      margin: 0 auto 17px auto;
      width: 100%
    }

    #frigelarWebContent_v1-wi1000001 .frigelar-simple-image * {
      width: 100%
    }

    @media only screen and (max-width : 991px) {
      #frigelarWebContent_v1-wi1000001 .frigelar-spacing {
        display: none
      }
    }

    #frigelarWebContent_v1-wi1000001 .gray {
      color: #686868
    }

    #frigelarWebContent_v1-wi1000001 .left {
      text-align: left
    }

    #frigelarWebContent_v1-wi1000001 .center {
      text-align: center
    }

    #frigelarWebContent_v1-wi1000001 .right {
      text-align: right
    }

    #frigelarWebContent_v1-wi3500001 .frigelar-web-content {
      margin: 0 auto;
      height: 100%;
      max-width: 100%;
      padding-right: 20px
    }

    #frigelarWebContent_v1-wi3500001 .frigelar-simple-title {
      font-size: 16px;
      line-height: 1.4em;
      font-weight: 100 !important;
      color: #686868 !important;
      font-family: "Montserrat", Arial, sans-serif;
      font-style: normal;
      text-align: center;
      display: block;
      width: 100%;
      margin-top: -35px
    }

    #frigelarWebContent_v1-wi3500001 .frigelar-simple-title h1 {
      font-weight: 100
    }

    #frigelarWebContent_v1-wi3500001 .title-line {
      display: none
    }

    @media only screen and (max-width : 991px) {
      #frigelarWebContent_v1-wi3500001 .frigelar-spacing {
        display: none
      }
    }

    #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy {
      position: fixed;
      z-index: 9999;
      max-width: 1300px;
      transition: .3s ease-in-out;
      background: #fff;
      bottom: 25px;
      left: 10px;
      right: 10px;
      padding: 20px;
      box-shadow: 0 0 10px #aaa;
      border-radius: 12px;
      display: -webkit-flex;
      display: -ms-flexbox;
      display: flex;
      -webkit-align-items: center;
      -ms-flex-align: center;
      align-items: center;
      -webkit-transform: translateY(300px);
      -ms-transform: translateY(300px);
      transform: translateY(300px);
      margin: 0 auto
    }

    @media (max-width:700px) {
      #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy {
        flex-direction: column
      }
    }

    #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy p {
      margin-bottom: 0 !important
    }

    #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy #modalPrivacyPolicy-btn {
      background: #183a68 0 0 no-repeat padding-box;
      border: 1px solid #183a68;
      color: #fff;
      border-radius: 8px;
      text-align: center;
      font-size: 16px;
      padding: 10px 20px;
      letter-spacing: 0;
      margin-left: 15px;
      cursor: pointer;
      white-space: nowrap
    }

    @media (max-width:700px) {
      #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy #modalPrivacyPolicy-btn {
        margin-left: 0;
        margin-top: 1em;
        width: 100%
      }
    }

    #frigelarAvisoCookies_v1-wi600010 #modalPrivacyPolicy.opened {
      transition: .1s ease-in-out;
      -webkit-transform: translate(0);
      -ms-transform: translate(0);
      transform: translate(0)
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners {
      margin: 50px auto;
      text-align: center;
      max-width: 1360px
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container {
      height: 52px;
      display: flex;
      justify-content: center
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .separator {
      height: 80%;
      position: absolute;
      right: 0;
      top: 8px;
      bottom: 0;
      width: 1px;
      background-color: #686868
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .fourthCard {
      cursor: pointer
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .fourthCard div,
    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .fourthCard img {
      height: 100%
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .col-lg-3 {
      height: 100%
    }

    #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container img {
      max-width: 100%;
      height: 100%
    }

    @media only screen and (max-width : 991px) {
      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners {
        margin: 48px auto
      }

      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container {
        margin: 24px auto;
        height: auto;
        display: flex;
        justify-content: center
      }

      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .fourthCard div,
      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container .fourthCard img {
        height: auto
      }

      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container img {
        height: auto
      }

      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container:first-child {
        margin-top: 0
      }

      #frigelarHomeInformativeBanner_v1-wi400052 #home-card-banners .items-container:last-child {
        margin-bottom: 0
      }
    }
  </style>
  <!--<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="momentLangs/pt-br" src="./js/pt-br.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarNotifications.min.js" src="./js/frigelarNotifications.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHeaderMenu.min.js" src="./js/frigelarHeaderMenu.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/FrigelarProductBox.min.js" src="./js/FrigelarProductBox.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarWarrantySidemenu.min.js" src="./js/frigelarWarrantySidemenu.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarLogin.min.js" src="./js/frigelarLogin.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarPasswordReset.min.js" src="./js/frigelarPasswordReset.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarRegistration.min.js" src="./js/frigelarRegistration.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelar-minicart.min.js" src="./js/frigelar-minicart.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHomeBanner.min.js" src="./js/frigelarHomeBanner.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarAddToWishList.min.js" src="./js/frigelarAddToWishList.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHomeBannerCard.min.js" src="./js/frigelarHomeBannerCard.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHomeInformativeBanner.min.js" src="./js/frigelarHomeInformativeBanner.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarWebContent.min.js" src="./js/frigelarWebContent.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHomeCategoryCarousel.min.js" src="./js/frigelarHomeCategoryCarousel.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarProductRecommendations.min.js" src="./js/frigelarProductRecommendations.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarHomeImageMosaic.min.js" src="./js/frigelarHomeImageMosaic.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarFormNewsletter.min.js" src="./js/frigelarFormNewsletter.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarpopupabandonodepagina.min.js" src="./js/frigelarpopupabandonodepagina.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelaradditemstocartbyurl.min.js" src="./js/frigelaradditemstocartbyurl.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarChatbot.min.js" src="./js/frigelarChatbot.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarFooter.min.js" src="./js/frigelarFooter.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarAvisoCookies.min.js" src="./js/frigelarAvisoCookies.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/web-content.min.js" src="./js/web-content.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/recsTracking.min.js" src="./js/recsTracking.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/frigelarGlobalGoogleAnalytics.min.js" src="./js/frigelarGlobalGoogleAnalytics.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/oracleunifiedvisit.js" src="./js/oracleunifiedvisit.js"></script>
  <script type="text/javascript" src="https://staticfiles.yviews.com.br/static/commom/jquery.min.js"></script>
  <script src="https://www.google.com/recaptcha/api.js?onload=onloadCaptchaCallback&amp;render=6Lfjdu0jAAAAALVlbq3H0HYOaasxpCOyPdlnTvW1" id="frigelar-recaptcha-script"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/recsRequest.min.js" src="./js/recsRequest.min.js"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://unpkg.com/blip-chat-widget" src="https://unpkg.com/blip-chat-widget?bust=24.05"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://www.frigelar.com.br/file/v9080620603328175187/widget/recommendationsTracking/js/recsRequest.min.js" src="https://www.frigelar.com.br/file/v9080620603328175187/widget/recommendationsTracking/js/recsRequest.min.js?bust=24.05"></script>
  <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="./js/gdprConsent.min.js" src="./js/gdprConsent.min.js"></script>-->

  <!--<link rel="stylesheet" type="text/css" href="https://service.yourviews.com.br/script/style?storeKey=1f9c4ade-92c2-4be7-b795-fa843628b6bd&amp;callback=?">-->
  <style type="text/css">
    @media screen and (max-width: 480px),
    screen and (max-height: 420px) {
      .chatParent {
        overflow-y: hidden !important;
        position: static !important;
        height: 0px;
        width: 0px;
      }
    }

    #blip-chat-notifications {
      background-color: #F76556;
      color: #fff;
      border-radius: 50%;
      line-height: 21px;
      font-size: 12px;
      width: 21px;
      height: 21px;
      position: fixed;
      text-align: center;
      bottom: 65px;
      right: 30px;
      opacity: 0;
    }

    #blip-chat-container {
      position: fixed;
      bottom: 40px;
      right: 80px;
      z-index: 1000000;
    }

    @media screen and (max-width: 480px),
    screen and (max-height: 420px) {
      #blip-chat-container {
        bottom: 0px;
        right: 0px;
        position: absolute;
        height: 100%;
      }
    }

    #blip-chat-container #blip-chat-iframe {
      position: fixed;
      bottom: 90px;
      right: 38px;
      opacity: 0;
      transition: opacity 500ms, transform 500ms, visibility 500ms, height 0s 500ms;
      transform: translateY(10%);
      z-index: 1;
      height: 0;
      width: 400px;
      box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.2);
      border-radius: 5px;
      background: #faf9f8;
    }

    @media screen and (max-width: 480px),
    screen and (max-height: 420px) {
      #blip-chat-container #blip-chat-iframe {
        right: 0px;
        bottom: 0px !important;
        max-height: 100vh !important;
        width: 100vw;
        position: absolute;
        box-shadow: none;
      }
    }

    #blip-chat-container #blip-chat-iframe.blip-chat-iframe-opened {
      opacity: 1;
      transform: translateY(0);
      visibility: visible;
      transition: opacity 500ms 10ms, transform 500ms 10ms, visibility 500ms 10ms, height 0ms;
      height: 610px;
    }

    @media screen and (max-width: 480px),
    screen and (max-height: 420px) {
      #blip-chat-container #blip-chat-iframe.blip-chat-iframe-opened {
        height: 100%;
      }
    }

    #blip-chat-container #blip-chat-open-iframe {
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 2;
      position: fixed;
      width: 4%;
      max-width: 60px;
      min-width: 48px;
      max-height: 60px;
      min-height: 48px;
      right: 35px;
      bottom: 35px;
      transition: transform 200ms, opacity 500ms, visibility 500ms;
      box-shadow: 0 1px 6px rgba(0, 0, 0, 0.1), 0 2px 32px rgba(0, 0, 0, 0.1);
      background-size: 100%;
      background-repeat: no-repeat;
      background-position: center;
    }

    @media screen and (max-width: 480px),
    screen and (max-height: 420px) {
      #blip-chat-container #blip-chat-open-iframe.opened {
        visibility: hidden !important;
        opacity: 0 !important;
      }
    }

    #blip-chat-container #blip-chat-open-iframe:active {
      transform: scale(0.9);
    }

    #blip-chat-container #blip-chat-open-iframe img,
    #blip-chat-container #blip-chat-open-iframe svg {
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }

    #blip-chat-open-iframe {
      display: none;
    }

    #blip-chat-iframe {
      width: 100%;
      height: 100%;
    }
  </style>
  <!--<script src="https://bat.bing.com/p/action/6027511.js" type="text/javascript" async="" data-ueto="ueto_484474805d"></script>-->


  <style>
    ._hj-Pbej5__styles__resetStyles * {
      line-height: normal;
      font-family: Arial, sans-serif, Tahoma !important;
      text-transform: initial !important;
      letter-spacing: normal !important
    }

    ._hj-Pbej5__styles__resetStyles *::before,
    ._hj-Pbej5__styles__resetStyles *::after {
      box-sizing: initial
    }

    ._hj-Pbej5__styles__resetStyles div {
      height: auto
    }

    ._hj-Pbej5__styles__resetStyles button {
      display: inline-block;
      height: auto;
      font-size: 1rem
    }

    ._hj-Pbej5__styles__resetStyles div,
    ._hj-Pbej5__styles__resetStyles span,
    ._hj-Pbej5__styles__resetStyles p,
    ._hj-Pbej5__styles__resetStyles a,
    ._hj-Pbej5__styles__resetStyles button {
      font-weight: normal !important
    }

    ._hj-Pbej5__styles__resetStyles div,
    ._hj-Pbej5__styles__resetStyles span,
    ._hj-Pbej5__styles__resetStyles p,
    ._hj-Pbej5__styles__resetStyles a,
    ._hj-Pbej5__styles__resetStyles img,
    ._hj-Pbej5__styles__resetStyles strong,
    ._hj-Pbej5__styles__resetStyles form,
    ._hj-Pbej5__styles__resetStyles label {
      border: 0;
      font-size: 100%;
      vertical-align: baseline;
      background: transparent;
      margin: 0;
      padding: 0;
      float: none !important
    }

    ._hj-Pbej5__styles__resetStyles span {
      color: inherit
    }

    ._hj-Pbej5__styles__resetStyles ol,
    ._hj-Pbej5__styles__resetStyles ul,
    ._hj-Pbej5__styles__resetStyles li {
      list-style: none !important;
      margin: 0 !important;
      padding: 0 !important
    }

    ._hj-Pbej5__styles__resetStyles li:before,
    ._hj-Pbej5__styles__resetStyles li:after {
      content: none !important
    }

    ._hj-Pbej5__styles__resetStyles hr {
      display: block;
      height: 1px;
      border: 0;
      border-top: 1px solid #ccc;
      margin: 1em 0;
      padding: 0
    }

    ._hj-Pbej5__styles__resetStyles input[type='submit'],
    ._hj-Pbej5__styles__resetStyles input[type='button'],
    ._hj-Pbej5__styles__resetStyles button {
      margin: 0;
      padding: 0;
      float: none !important
    }

    ._hj-Pbej5__styles__resetStyles input,
    ._hj-Pbej5__styles__resetStyles select,
    ._hj-Pbej5__styles__resetStyles a img {
      vertical-align: middle
    }

    ._hj-s3UIi__styles__globalStyles *,
    ._hj-s3UIi__styles__globalStyles *::before,
    ._hj-s3UIi__styles__globalStyles *::after {
      box-sizing: border-box
    }

    /*@font-face {
      font-family: 'hotjar';
      src: url(https://script.hotjar.com/font-hotjar_5.f4b154.eot);
      src: url(https://script.hotjar.com/font-hotjar_5.f4b154.eot#iefix) format("embedded-opentype"), url(https://script.hotjar.com/font-hotjar_5.65042d.woff2) format("woff2"), url(https://script.hotjar.com/font-hotjar_5.0ddfe2.ttf) format("truetype"), url(https://script.hotjar.com/font-hotjar_5.17b429.woff) format("woff"), url(https://script.hotjar.com/font-hotjar_5.2c7ab2.svg#hotjar) format("svg");
      font-weight: normal;
      font-style: normal
    } */

    @keyframes _hj-eYRYp__styles__spin {
      0% {
        transform: rotate(0deg)
      }

      100% {
        transform: rotate(360deg)
      }
    }

    @keyframes _hj-5\+Z5O__styles__colors {
      0% {
        border-color: #f4364c;
        border-top-color: transparent
      }

      25% {
        border-color: #00a2f2;
        border-top-color: transparent
      }

      50% {
        border-color: #efb60c;
        border-top-color: transparent
      }

      75% {
        border-color: #42ca49;
        border-top-color: transparent
      }

      100% {
        border-color: #f4364c;
        border-top-color: transparent
      }
    }

    ._hj-s3UIi__styles__globalStyles p {
      color: inherit !important
    }

    ._hj-s3UIi__styles__globalStyles a,
    ._hj-s3UIi__styles__globalStyles a:link,
    ._hj-s3UIi__styles__globalStyles a:hover,
    ._hj-s3UIi__styles__globalStyles a:active {
      color: inherit !important;
      text-decoration: underline
    }

    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon {
      speak: none !important;
      font-style: normal !important;
      font-weight: normal !important;
      font-variant: normal !important;
      text-transform: none !important;
      overflow-wrap: normal !important;
      word-break: normal !important;
      word-wrap: normal !important;
      white-space: nowrap !important;
      line-height: normal !important;
      -webkit-font-smoothing: antialiased !important;
      -moz-osx-font-smoothing: grayscale !important;
      vertical-align: middle !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon,
    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:before,
    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:after,
    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *,
    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *:before,
    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon *:after {
      font-family: 'hotjar' !important;
      display: inline-block !important;
      direction: ltr !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-L5SMl__styles__icon:before {
      color: inherit !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-dk3Fb__styles__iconX:before {
      content: '\e803'
    }

    ._hj-s3UIi__styles__globalStyles ._hj-9iDZB__styles__iconOk:before {
      content: '\e804'
    }

    ._hj-s3UIi__styles__globalStyles ._hj-t13KX__styles__iconError:before {
      content: '\e90c'
    }

    ._hj-s3UIi__styles__globalStyles ._hj-D\+oDX__styles__iconLogo:before {
      content: '\e806'
    }

    ._hj-s3UIi__styles__globalStyles ._hj-Nbq9C__styles__iconSelectElement:before {
      content: '\e91a'
    }

    ._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons {
      background-repeat: no-repeat;
      width: 16px;
      height: 16px;
      display: inline-block !important;
      zoom: 1;
      vertical-align: middle
    }

   /* ._hj-widget-theme-light ._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons {
      background-image: url(https://script.hotjar.com/widget_icons_light.766225.png)
    }

    ._hj-widget-theme-dark ._hj-s3UIi__styles__globalStyles ._hj-mtJG6__styles__surveyIcons {
      background-image: url(https://script.hotjar.com/widget_icons_dark.ad934a.png)
    }
*/
    ._hj-s3UIi__styles__globalStyles ._hj-EZqbk__styles__inputField {
      font-family: Arial, sans-serif, Tahoma;
      font-size: 14px;
      color: #333 !important;
      padding: 6px !important;
      text-indent: 0 !important;
      height: 30px;
      width: 100%;
      min-width: 100%;
      background: white;
      border: 1px solid !important;
      outline: none !important;
      max-width: none !important;
      float: none;
      border-radius: 3px
    }

    ._hj-s3UIi__styles__globalStyles ._hj-AwaE7__styles__textarea {
      resize: none;
      height: 100px
    }

    ._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton {
      cursor: pointer;
      text-decoration: none;
      text-transform: capitalize;
      font-size: 14px;
      font-weight: bold;
      padding: 6px 16px !important;
      border: 0;
      outline: 0;
      display: inline-block;
      vertical-align: top;
      width: auto;
      zoom: 1;
      transition: all 0.2s ease-in-out;
      box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.15);
      border-radius: 4px;
      color: white
    }

    ._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:hover,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover,
    ._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:focus,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus,
    ._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton:active,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:active {
      background: #00a251
    }

    ._hj-s3UIi__styles__globalStyles ._hj-EIBGi__styles__basicButton[disabled],
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton[disabled] {
      cursor: default
    }

    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton {
      font-size: 14px !important;
      font-weight: 500 !important;
      padding: 6px 16px !important;
      border: 0 !important;
      outline: 0 !important;
      min-height: initial !important;
      width: auto !important;
      min-width: initial !important;
      background: var(--hjFeedbackAccentColor) !important;
      color: var(--hjFeedbackAccentTextColor) !important;
      box-shadow: none !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus,
    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:active {
      background: var(--hjFeedbackAccentActiveColor) !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:focus {
      background: var(--hjFeedbackAccentColor) !important;
      box-shadow: 0 0 0 1px var(--hjFeedbackPrimaryColor), 0 0 0 3px var(--hjFeedbackAccentColor) !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton:hover {
      background: var(--hjFeedbackAccentHoverColor) !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-SU8LU__styles__primaryButton[disabled] {
      cursor: default;
      background: var(--hjFeedbackDisabledAccentColor) !important;
      color: var(--hjFeedbackDisabledAccentTextColor) !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-F457\+__styles__clearButton {
      cursor: pointer;
      text-decoration: underline;
      font-size: 13px !important;
      padding: 0 10px !important;
      border: 0 !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-F457\+__styles__clearButton,
    ._hj-s3UIi__styles__globalStyles ._hj-F457\+__styles__clearButton:hover,
    ._hj-s3UIi__styles__globalStyles ._hj-F457\+__styles__clearButton:focus,
    ._hj-s3UIi__styles__globalStyles ._hj-F457\+__styles__clearButton:active {
      background: transparent !important
    }

    ._hj-s3UIi__styles__globalStyles ._hj-hTm4\+__styles__answersContentWrapper {
      padding: 4px 12px 16px 12px
    }

    ._hj-s3UIi__styles__globalStyles ._hj-ag9y\+__styles__spinner {
      border: 1px solid rgba(0, 0, 0, 0.6);
      border-top-color: transparent !important;
      border-radius: 50%;
      transform: rotate(0deg);
      animation: _hj-eYRYp__styles__spin 0.4s linear infinite, _hj-5\+Z5O__styles__colors 5.6s ease-in-out infinite
    }

    ._hj-s3UIi__styles__globalStyles ._hj-H1LCt__styles__widget {
      font-size: 13px !important;
      position: fixed;
      z-index: 2147483640;
      bottom: -400px;
      right: 100px;
      width: 300px;
      -webkit-border-radius: 5px 5px 0 0;
      -moz-border-radius: 5px 5px 0 0;
      border-radius: 5px 5px 0 0;
      -webkit-transform: translateZ(0) !important;
      transform: translateZ(0) !important
    }

    ._hj-AwaE7__styles__textarea {}

    ._hj-dk3Fb__styles__iconX,
    ._hj-9iDZB__styles__iconOk,
    ._hj-t13KX__styles__iconError,
    ._hj-D\+oDX__styles__iconLogo,
    ._hj-Nbq9C__styles__iconSelectElement {}

    ._hj-eJm8p__styles__rtl,
    ._hj-eJm8p__styles__rtl * {
      direction: rtl !important
    }

    ._hj-hc6BA__styles__roundedCorners {
      border-radius: 3px
    }

    @media screen and (max-width: 480px) {
      ._hj-A4W17__styles__inlineSurvey {
        max-width: 100%;
        overflow-x: auto
      }
    }
  </style>
  <style>
    ._hj-1rd6z__styles__embeddedContainer {
      width: 100%;
      display: flex;
      justify-content: center
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-zRk2h__Feedback__feedback,
    ._hj_feedback_container ._hj-zRk2h__Feedback__feedback * {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif !important;
      -webkit-font-smoothing: auto;
      -moz-osx-font-smoothing: auto
    }

    ._hj-YR-2H__Feedback__container {
      position: relative;
      z-index: 2147483640
    }

    ._hj-YR-2H__Feedback__container._hj-soF-G__Feedback__isEmbedded {
      z-index: auto
    }

    ._hj-zRk2h__Feedback__feedback {
      color: #333333
    }

    ._hj-zRk2h__Feedback__feedback._hj-z1NGf__Feedback__button {
      position: fixed
    }

    ._hj-zRk2h__Feedback__feedback button {
      height: auto;
      min-height: auto;
      opacity: 1;
      border: none
    }

    ._hj-zRk2h__Feedback__feedback textarea {
      margin: 0;
      min-height: auto;
      box-shadow: none
    }

    ._hj-zRk2h__Feedback__feedback input {
      margin: 0;
      height: auto
    }

    ._hj-zRk2h__Feedback__feedback input::placeholder,
    ._hj-zRk2h__Feedback__feedback textarea::placeholder {
      color: #636c72;
      font-weight: normal;
      opacity: 1
    }

    ._hj-zRk2h__Feedback__feedback._hj-Wv2jv__Feedback__rtl {
      direction: rtl
    }

    ._hj-zRk2h__Feedback__feedback._hj-nJeUi__Feedback__hidden {
      display: none !important;
      pointer-events: none
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-ETLL8__MinimizedWidgetMiddle__label {
      font-size: 13px;
      position: relative;
      border: none;
      outline: none;
      padding: 12px 14px 12px 12px;
      cursor: pointer;
      white-space: nowrap;
      background-color: #f4364c !important;
      background-color: var(--hjFeedbackAccentColor, #f4364c) !important;
      transition: transform 0.1s ease-in-out, box-shadow 0.1s ease-in-out;
      opacity: 0.96;
      width: 40px;
      display: flex;
      flex-direction: column;
      align-items: flex-start
    }

    ._hj_feedback_container ._hj-ETLL8__MinimizedWidgetMiddle__label:hover {
      box-shadow: 0 0 35px 2px rgba(0, 0, 0, 0.24);
      opacity: 1
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container {
      position: fixed;
      top: 50%;
      transform: translateY(-50%);
      box-sizing: border-box !important;
      display: block;
      direction: ltr !important
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-v4Fsu__MinimizedWidgetMiddle__right {
      right: 0
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-v4Fsu__MinimizedWidgetMiddle__right ._hj-ETLL8__MinimizedWidgetMiddle__label {
      border-radius: 3px 0 0 3px;
      transform: translateX(2px)
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-v4Fsu__MinimizedWidgetMiddle__right ._hj-ETLL8__MinimizedWidgetMiddle__label:hover {
      transform: translateX(0)
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-v4Fsu__MinimizedWidgetMiddle__right ._hj-WJi0t__MinimizedWidgetMiddle__message {
      right: 40px
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-1QuqW__MinimizedWidgetMiddle__left {
      left: 0
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-1QuqW__MinimizedWidgetMiddle__left ._hj-ETLL8__MinimizedWidgetMiddle__label {
      border-radius: 0 3px 3px 0;
      transform: translateX(-2px)
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-1QuqW__MinimizedWidgetMiddle__left ._hj-ETLL8__MinimizedWidgetMiddle__label:hover {
      transform: translateX(0)
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container._hj-1QuqW__MinimizedWidgetMiddle__left ._hj-WJi0t__MinimizedWidgetMiddle__message {
      left: 40px
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-Dfxkw__MinimizedWidgetMiddle__text {
      overflow-wrap: normal !important;
      word-break: normal !important;
      word-wrap: normal !important;
      white-space: nowrap !important;
      filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=2);
      cursor: pointer;
      -ms-writing-mode: tb-rl;
      -webkit-writing-mode: vertical-lr;
      writing-mode: vertical-lr;
      transform: rotate(180deg);
      color: #ffffff !important;
      color: var(--hjFeedbackAccentTextColor, #fff) !important
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-Dfxkw__MinimizedWidgetMiddle__text._hj-pjjn2__MinimizedWidgetMiddle__language_ja,
    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-Dfxkw__MinimizedWidgetMiddle__text._hj-rcHsJ__MinimizedWidgetMiddle__language_ko,
    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-Dfxkw__MinimizedWidgetMiddle__text._hj-L-Bbd__MinimizedWidgetMiddle__language_zh_CN,
    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-Dfxkw__MinimizedWidgetMiddle__text._hj-2Jf5B__MinimizedWidgetMiddle__language_zh_TW {
      transform: none
    }

    ._hj_feedback_container ._hj-G09L\+__MinimizedWidgetMiddle__container ._hj-T5uly__MinimizedWidgetMiddle__emotionIcon {
      height: 18px;
      margin: 10px 0 0 -3px;
      font-size: 14px
    }

    ._hj-WJi0t__MinimizedWidgetMiddle__message {
      position: absolute;
      bottom: 3px
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault *:before {
      margin-left: -1.3984375em
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault ._hj-NS6la__EmotionIconDefault__commentIcon:before {
      content: '\e900';
      margin: 0
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault ._hj-NS6la__EmotionIconDefault__commentIcon:before,
    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault ._hj-2OhzN__EmotionIconDefault__expressionIcon._hj-x0ZI9__EmotionIconDefault__invert:before {
      color: #f4364c !important;
      color: var(--hjFeedbackAccentColor, #f4364c) !important
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault ._hj-NS6la__EmotionIconDefault__commentIcon._hj-x0ZI9__EmotionIconDefault__invert:before,
    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      color: #ffffff !important;
      color: var(--hjFeedbackAccentTextColor, #fff) !important
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-3mQXg__EmotionIconDefault__hate ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e901'
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-Lrf2W__EmotionIconDefault__dislike ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e903'
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-OPWov__EmotionIconDefault__neutral ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e905'
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-F-vtG__EmotionIconDefault__like ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e907'
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-IDB8D__EmotionIconDefault__love ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e909'
    }

    ._hj_feedback_container ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault._hj-ZQVJp__EmotionIconDefault__wink ._hj-2OhzN__EmotionIconDefault__expressionIcon:before {
      content: '\e90b'
    }

    ._hj-pRFOn__EmotionIconDefault__iconEmotionDefault {}
  </style>
  <style>
    ._hj-ONMkJ__MinimizedWidgetMessage__close {}

    ._hj_feedback_container ._hj-ONMkJ__MinimizedWidgetMessage__close {
      opacity: 0;
      position: absolute;
      top: -9px;
      right: -9px;
      width: 21px;
      height: 21px !important;
      border-radius: 50%;
      font-size: 11px;
      line-height: 21px !important;
      text-align: center;
      cursor: pointer;
      border: none;
      outline: none;
      color: #ffffff !important;
      background-color: #4d5167 !important
    }

    ._hj-cl39T__MinimizedWidgetMessage__message {
      position: relative;
      padding: 12px 16px !important;
      margin: 0 18px !important;
      width: 320px;
      max-width: calc(100vw - 120px);
      text-align: center;
      font-size: 12px !important;
      cursor: pointer;
      box-shadow: 0 2px 18px 0 rgba(0, 0, 0, 0.3);
      box-sizing: border-box;
      background-color: #ffffff !important;
      background-color: var(--hjFeedbackBackgroundColor, #fff) !important;
      bottom: -7px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      align-items: center
    }

    ._hj-cl39T__MinimizedWidgetMessage__message:before {
      content: '';
      width: 1px;
      height: 1px;
      position: absolute;
      bottom: 13px;
      border-top: 6px solid transparent;
      border-bottom: 6px solid transparent
    }

    ._hj-cl39T__MinimizedWidgetMessage__message:hover {
      box-shadow: 0 2px 24px 0 rgba(0, 0, 0, 0.33)
    }

    ._hj-cl39T__MinimizedWidgetMessage__message:hover ._hj-ONMkJ__MinimizedWidgetMessage__close,
    ._hj-cl39T__MinimizedWidgetMessage__message._hj-y\+-J7__MinimizedWidgetMessage__phone ._hj-ONMkJ__MinimizedWidgetMessage__close,
    ._hj-cl39T__MinimizedWidgetMessage__message._hj-8b8e0__MinimizedWidgetMessage__tablet ._hj-ONMkJ__MinimizedWidgetMessage__close {
      opacity: 1 !important
    }

    ._hj-cl39T__MinimizedWidgetMessage__message._hj-vpfap__MinimizedWidgetMessage__left:before {
      left: -7px;
      border-right: 7px solid #ffffff !important;
      border-right: 7px solid var(--hjFeedbackBackgroundColor, #fff) !important
    }

    ._hj-cl39T__MinimizedWidgetMessage__message._hj-Bn12n__MinimizedWidgetMessage__right:before {
      right: -7px;
      border-left: 7px solid #ffffff !important;
      border-left: 7px solid var(--hjFeedbackBackgroundColor, #fff) !important
    }

    ._hj-PFeiP__MinimizedWidgetMessage__messageText {
      color: #333333 !important;
      color: var(--hjFeedbackDarkGray, #333) !important
    }
  </style>
  <style>
    ._hj-widget-container ._hj-a4kgj__PrimaryButton__phone,
    ._hj_feedback_container ._hj-a4kgj__PrimaryButton__phone {
      font-size: 18px !important;
      padding: 12px 20px !important
    }

    ._hj-widget-container ._hj-JlEmi__PrimaryButton__tablet,
    ._hj_feedback_container ._hj-JlEmi__PrimaryButton__tablet {
      font-size: 22px !important;
      padding: 14px 28px !important
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-0izHt__MinimizedWidgetBottom__container {
      position: fixed;
      bottom: 33px;
      display: flex;
      align-items: flex-end
    }

    ._hj_feedback_container ._hj-0izHt__MinimizedWidgetBottom__container>* {
      -ms-flex: 1 0 auto
    }

    ._hj_feedback_container ._hj-0izHt__MinimizedWidgetBottom__container._hj--qUEH__MinimizedWidgetBottom__right {
      flex-direction: row-reverse;
      right: 32px
    }

    ._hj_feedback_container ._hj-0izHt__MinimizedWidgetBottom__container._hj-RCGJ4__MinimizedWidgetBottom__left {
      left: 32px
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open {
      font-size: 37px !important;
      border: none;
      background: none !important;
      outline: none;
      overflow: visible;
      position: relative;
      opacity: 0.96 !important
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open:hover {
      opacity: 1 !important
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open._hj-RCGJ4__MinimizedWidgetBottom__left {
      left: -7px
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open._hj-RCGJ4__MinimizedWidgetBottom__left,
    ._hj-g7b-Z__MinimizedWidgetBottom__open._hj--qUEH__MinimizedWidgetBottom__right {
      bottom: -3px
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open:hover>div:before {
      box-shadow: 0 2px 18px 18px rgba(0, 0, 0, 0.65)
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open>div {
      position: relative;
      cursor: pointer
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open>div:before {
      content: '';
      z-index: -1;
      position: absolute;
      bottom: 20px;
      left: 25px;
      background: rgba(0, 0, 0, 0.48);
      width: 6px;
      height: 1px;
      box-shadow: 0 2px 18px 18px rgba(0, 0, 0, 0.48);
      transition: all 0.2s ease-in-out
    }

    ._hj-g7b-Z__MinimizedWidgetBottom__open>div span {
      line-height: 1;
      vertical-align: bottom
    }

    ._hj-dj87g__MinimizedWidgetBottom__close {
      width: 44px;
      height: 37px !important;
      font-size: 20px;
      text-align: center !important;
      border: none;
      outline: none;
      border-radius: 5px;
      box-shadow: 0 2px 10px 1px rgba(0, 0, 0, 0.18);
      cursor: pointer;
      color: #ffffff !important;
      color: var(--hjFeedbackAccentTextColor, #fff) !important;
      background-color: #f4364c !important;
      background-color: var(--hjFeedbackAccentColor, #f4364c) !important
    }

    ._hj-gdqzW__MinimizedWidgetBottom__iconX {}
  </style>
  <style>
    @keyframes _hj-lISCn__ExpandedWidget__slideInLeft {
      0% {
        transform: translateX(-350px) translateY(-50%);
        opacity: 0
      }

      100% {
        transform: translateX(0px) translateY(-50%);
        opacity: 1
      }
    }

    @keyframes _hj-a6ETr__ExpandedWidget__slideOutLeft {
      0% {
        transform: translateX(0px) translateY(-50%);
        opacity: 1
      }

      100% {
        transform: translateX(-350px) translateY(-50%);
        opacity: 0
      }
    }

    @keyframes _hj-dLkgL__ExpandedWidget__slideInRight {
      0% {
        transform: translateX(350px) translateY(-50%);
        opacity: 0
      }

      100% {
        transform: translateX(0px) translateY(-50%);
        opacity: 1
      }
    }

    @keyframes _hj-3bH6k__ExpandedWidget__slideOutRight {
      0% {
        transform: translateX(0px) translateY(-50%);
        opacity: 1
      }

      100% {
        transform: translateX(350px) translateY(-50%);
        opacity: 0
      }
    }

    @keyframes _hj-X-Ux5__ExpandedWidget__slideInBottom {
      0% {
        transform: translateY(18px);
        opacity: 0
      }

      100% {
        transform: translateY(0px);
        opacity: 1
      }
    }

    @keyframes _hj-ZDTvk__ExpandedWidget__slideOutBottom {
      0% {
        transform: translateY(0px);
        opacity: 1
      }

      100% {
        transform: translateY(18px);
        opacity: 0;
        background: red
      }
    }

    @keyframes _hj-E6UHR__ExpandedWidget__slideInBottomMobile {
      0% {
        transform: translateY(20px);
        opacity: 0
      }

      100% {
        transform: translateY(0px);
        opacity: 1
      }
    }

    @keyframes _hj-Jjtcq__ExpandedWidget__slideOutBottomMobile {
      0% {
        transform: translateY(0px);
        opacity: 1
      }

      100% {
        transform: translateY(20px);
        opacity: 0
      }
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer {
      display: flex;
      z-index: 10
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-q-8RD__ExpandedWidget__isEmbedded {
      align-items: center;
      z-index: 0
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button {
      position: fixed
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-lISCn__ExpandedWidget__slideInLeft {
      animation: _hj-lISCn__ExpandedWidget__slideInLeft 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-a6ETr__ExpandedWidget__slideOutLeft {
      animation: _hj-a6ETr__ExpandedWidget__slideOutLeft 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-dLkgL__ExpandedWidget__slideInRight {
      animation: _hj-dLkgL__ExpandedWidget__slideInRight 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-3bH6k__ExpandedWidget__slideOutRight {
      animation: _hj-3bH6k__ExpandedWidget__slideOutRight 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-8t8aG__ExpandedWidget__middle {
      top: 50%
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Nf6vN__ExpandedWidget__bottom {
      bottom: 92px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Nf6vN__ExpandedWidget__bottom._hj-lISCn__ExpandedWidget__slideInLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Nf6vN__ExpandedWidget__bottom._hj-dLkgL__ExpandedWidget__slideInRight {
      animation: _hj-X-Ux5__ExpandedWidget__slideInBottom 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Nf6vN__ExpandedWidget__bottom._hj-a6ETr__ExpandedWidget__slideOutLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Nf6vN__ExpandedWidget__bottom._hj-3bH6k__ExpandedWidget__slideOutRight {
      animation: _hj-ZDTvk__ExpandedWidget__slideOutBottom 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-FZpS-__ExpandedWidget__right {
      right: 32px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-qIRHQ__ExpandedWidget__left {
      left: 32px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet {
      width: 100%;
      max-width: 420px;
      padding: 0 20px;
      top: auto;
      bottom: 20px;
      position: fixed;
      left: 0;
      right: 0
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-lISCn__ExpandedWidget__slideInLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-dLkgL__ExpandedWidget__slideInRight,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-lISCn__ExpandedWidget__slideInLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-dLkgL__ExpandedWidget__slideInRight {
      animation: _hj-E6UHR__ExpandedWidget__slideInBottomMobile 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-a6ETr__ExpandedWidget__slideOutLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-3bH6k__ExpandedWidget__slideOutRight,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-a6ETr__ExpandedWidget__slideOutLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-3bH6k__ExpandedWidget__slideOutRight {
      animation: _hj-Jjtcq__ExpandedWidget__slideOutBottomMobile 300ms forwards
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone ._hj-eEC5y__ExpandedWidget__closeButton,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet ._hj-eEC5y__ExpandedWidget__closeButton {
      right: 40px;
      height: 36px;
      width: 36px;
      font-size: 18px;
      top: -18px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize {
      top: 0;
      bottom: 0;
      padding: 0;
      max-width: 100%
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize._hj-lISCn__ExpandedWidget__slideInLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize._hj-dLkgL__ExpandedWidget__slideInRight,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize._hj-a6ETr__ExpandedWidget__slideOutLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize._hj-3bH6k__ExpandedWidget__slideOutRight,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize._hj-lISCn__ExpandedWidget__slideInLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize._hj-dLkgL__ExpandedWidget__slideInRight,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize._hj-a6ETr__ExpandedWidget__slideOutLeft,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize._hj-3bH6k__ExpandedWidget__slideOutRight {
      animation: none
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize ._hj--NfhW__ExpandedWidget__innerContainer,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize ._hj--NfhW__ExpandedWidget__innerContainer {
      box-shadow: none;
      overflow: auto
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-Glvms__ExpandedWidget__phone._hj-LHpTO__ExpandedWidget__fullSize ._hj-eEC5y__ExpandedWidget__closeButton,
    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-rPPi2__ExpandedWidget__button._hj-g9YQb__ExpandedWidget__tablet._hj-LHpTO__ExpandedWidget__fullSize ._hj-eEC5y__ExpandedWidget__closeButton {
      background-color: transparent !important;
      color: #333333 !important;
      top: 10px;
      right: 10px;
      font-size: 22px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer ._hj-eEC5y__ExpandedWidget__closeButton {
      right: 20px;
      position: absolute;
      top: -13px;
      font-size: 15px;
      width: 27px;
      height: 27px;
      cursor: pointer;
      border-radius: 50%;
      border-bottom-style: none;
      border-width: 0;
      color: #ffffff !important;
      background-color: #4d5167 !important
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer ._hj-eEC5y__ExpandedWidget__closeButton i:before {
      line-height: 27px
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer ._hj-eEC5y__ExpandedWidget__closeButton:focus {
      outline: none !important
    }

    ._hj_feedback_container ._hj-lOIQj__ExpandedWidget__outerContainer._hj-jONuA__ExpandedWidget__preview {
      animation-duration: 0s
    }

    ._hj_feedback_container ._hj--NfhW__ExpandedWidget__innerContainer {
      background-color: #fff;
      box-shadow: rgba(0, 0, 0, 0.35) 0 6px 100px 0;
      width: 320px
    }

    ._hj_feedback_container ._hj-ivniz__ExpandedWidget__inline ._hj--NfhW__ExpandedWidget__innerContainer {
      box-shadow: unset;
      border-radius: 4px;
      margin: 32px;
      background-color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px 0
    }

    @media screen and (max-width: 440px) {
      ._hj_feedback_container ._hj-ivniz__ExpandedWidget__inline ._hj--NfhW__ExpandedWidget__innerContainer {
        margin: 16px
      }
    }

    @media screen and (max-width: 352px) {
      ._hj_feedback_container ._hj-ivniz__ExpandedWidget__inline ._hj--NfhW__ExpandedWidget__innerContainer {
        margin: 16px 0;
        max-width: 100vw
      }
    }
  </style>
  <style>
    @keyframes _hj-exLiv__EmotionOption__fadeIn {
      0% {
        transform: translateY(50px);
        opacity: 0
      }

      100% {
        transform: translateY(0);
        opacity: 1
      }
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption {
      font-size: 30px;
      width: 20%;
      text-align: center;
      background: none !important;
      border: none;
      cursor: pointer;
      outline: none;
      box-shadow: none;
      display: block
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-vWDAR__EmotionOption__isEmbedded {
      font-size: 26px
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-gr7JC__EmotionOption__tablet ._hj-8MJin__EmotionOption__iconEmotion {
      margin-top: 5px;
      margin-bottom: 10px
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-exLiv__EmotionOption__fadeIn {
      opacity: 0;
      animation: _hj-exLiv__EmotionOption__fadeIn 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.35) .3s forwards
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-exLiv__EmotionOption__fadeIn:nth-of-type(2) {
      animation-delay: .4s
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-exLiv__EmotionOption__fadeIn:nth-of-type(3) {
      animation-delay: .475s
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-exLiv__EmotionOption__fadeIn:nth-of-type(4) {
      animation-delay: .55s
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-exLiv__EmotionOption__fadeIn:nth-of-type(5) {
      animation-delay: .625s
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-K06IE__EmotionOption__EmotionOptionDimmed {
      opacity: 0.5 !important
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-sr1ot__EmotionOption__EmotionOptionGreyedOut ._hj--GlAE__EmotionOption__commentIcon::before {
      color: #ccc
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-sr1ot__EmotionOption__EmotionOptionGreyedOut ._hj-DC--x__EmotionOption__iconEmotionSmiley ._hj-tLbak__EmotionOption__expressionIcon::before {
      color: #ccc
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-T0OAK__EmotionOption__EmotionOptionWithIndicator::after {
      content: '';
      display: block;
      margin: 5px auto 0;
      width: 1px;
      height: 1px;
      border-left: 4px solid transparent;
      border-right: 4px solid transparent;
      border-bottom: 5px solid #eaeaeb
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-T0OAK__EmotionOption__EmotionOptionWithIndicator._hj-pXTo9__EmotionOption__phone::after,
    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-T0OAK__EmotionOption__EmotionOptionWithIndicator._hj-gr7JC__EmotionOption__tablet::after {
      margin-top: 25px
    }

    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption._hj-UDdQc__EmotionOption__EmotionOptionForceLabel ._hj-c-jt7__EmotionOption__EmotionText,
    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption:hover ._hj-c-jt7__EmotionOption__EmotionText,
    ._hj_feedback_container ._hj-zyNAL__EmotionOption__EmotionOption:focus ._hj-c-jt7__EmotionOption__EmotionText {
      opacity: 1;
      transform: translateY(0)
    }

    ._hj_feedback_container ._hj-c-jt7__EmotionOption__EmotionText {
      font-size: 12px;
      color: #999;
      opacity: 0;
      transform: translateY(10px);
      transition: all 0.2s ease-in-out;
      word-break: break-all
    }

    ._hj_feedback_container ._hj-FdP3R__EmotionOption__EmotionTextDefault {
      padding-left: 6px
    }

    ._hj_feedback_container ._hj-vvXwd__EmotionOption__EmotionTextStar {
      opacity: 0 !important
    }

    ._hj_feedback_container ._hj-8MJin__EmotionOption__iconEmotion {
      margin-bottom: 5px
    }

    ._hj_feedback_container ._hj-8MJin__EmotionOption__iconEmotion._hj-vWDAR__EmotionOption__isEmbedded {
      max-height: 26px
    }

    ._hj_feedback_container ._hj--GlAE__EmotionOption__commentIcon {
      height: fit-content
    }

    ._hj_feedback_container ._hj--GlAE__EmotionOption__commentIcon:before {
      color: #ffd902
    }

    ._hj_feedback_container ._hj-qFs7t__EmotionOption__iconEmotionLarge._hj-7h1Ss__EmotionOption__iconEmotionDefault {
      font-size: 40px
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault *:before {
      margin-left: -1.3984375em
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault ._hj--GlAE__EmotionOption__commentIcon:before {
      content: '\e900';
      margin: 0
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault ._hj-tLbak__EmotionOption__expressionIcon:before {
      color: #3c3c3c
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault._hj-NNI6w__EmotionOption__hate ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e901'
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault._hj-1Invx__EmotionOption__dislike ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e903'
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault._hj-Qztfe__EmotionOption__neutral ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e905'
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault._hj-EwQ-L__EmotionOption__like ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e907'
    }

    ._hj_feedback_container ._hj-7h1Ss__EmotionOption__iconEmotionDefault._hj-OxvxV__EmotionOption__love ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e909'
    }

    ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji ._hj-tLbak__EmotionOption__expressionIcon,
    ._hj_feedback_container ._hj-wJAZj__EmotionOption__iconEmotionStar ._hj-tLbak__EmotionOption__expressionIcon {
      width: 34px;
      height: 38px;
      background-size: 34px;
      background-repeat: no-repeat;
      display: block;
      margin: 0 auto 4px
    }

  /*  ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji._hj-NNI6w__EmotionOption__hate ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/emoji_0.4c6dff.png)
    }

    ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji._hj-1Invx__EmotionOption__dislike ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/emoji_1.384afb.png)
    }

    ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji._hj-Qztfe__EmotionOption__neutral ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/emoji_2.7b3140.png)
    }

    ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji._hj-EwQ-L__EmotionOption__like ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/emoji_3.14e2ff.png)
    }

    ._hj_feedback_container ._hj-RuNOK__EmotionOption__iconEmotionEmoji._hj-OxvxV__EmotionOption__love ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/emoji_4.bcd136.png)
    }

    ._hj_feedback_container ._hj-wJAZj__EmotionOption__iconEmotionStar ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/star_off.6eb2ad.png)
    }

    ._hj_feedback_container ._hj-wJAZj__EmotionOption__iconEmotionStar._hj-QgFWH__EmotionOption__highlighted ._hj-tLbak__EmotionOption__expressionIcon {
      background-image: url(https://script.hotjar.com/star_on.a39685.png)
    }

    */

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley ._hj-tLbak__EmotionOption__expressionIcon {
   /*   font-family: 'hotjar' !important;*/
      line-height: 37px;
      color: #f4364c !important;
      color: var(--hjFeedbackAccentColor, #f4364c) !important
    }

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley._hj-NNI6w__EmotionOption__hate ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e91b'
    }

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley._hj-1Invx__EmotionOption__dislike ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e91f'
    }

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley._hj-Qztfe__EmotionOption__neutral ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e91e'
    }

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley._hj-EwQ-L__EmotionOption__like ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e91c'
    }

    ._hj_feedback_container ._hj-DC--x__EmotionOption__iconEmotionSmiley._hj-OxvxV__EmotionOption__love ._hj-tLbak__EmotionOption__expressionIcon:before {
      content: '\e91d'
    }

    ._hj-7h1Ss__EmotionOption__iconEmotionDefault {}
  </style>
  <style>
    ._hj_feedback_container ._hj-sMYdO__EmotionStep__EmotionStep {
      flex: 1
    }

    ._hj_feedback_container ._hj-sMYdO__EmotionStep__EmotionStep._hj-atUfw__EmotionStep__isEmbedded {
      display: flex;
      flex-direction: column;
      min-height: 160px;
      justify-content: center
    }

    ._hj_feedback_container ._hj-sMYdO__EmotionStep__EmotionStep._hj-atUfw__EmotionStep__isEmbedded._hj-faUPK__EmotionStep__phone,
    ._hj_feedback_container ._hj-sMYdO__EmotionStep__EmotionStep._hj-atUfw__EmotionStep__isEmbedded._hj-ZT0W6__EmotionStep__tablet {
      min-height: 185px
    }

    ._hj_feedback_container ._hj-4Eap5__EmotionStep__EmotionOptions {
      padding: 0 12px;
      display: flex;
      align-items: flex-start;
      margin-top: 10px
    }

    ._hj_feedback_container ._hj-9Mvlt__EmotionStep__EmotionFooter {
      padding: 30px 20px 0
    }

    ._hj_feedback_container ._hj-9Mvlt__EmotionStep__EmotionFooter._hj-atUfw__EmotionStep__isEmbedded {
      padding: 0 24px;
      margin-top: auto;
      height: 29px;
      display: flex;
      align-items: center
    }

    ._hj_feedback_container ._hj-9Mvlt__EmotionStep__EmotionFooter._hj-atUfw__EmotionStep__isEmbedded._hj-RIAug__EmotionStep__noBranding {
      margin-top: 0
    }

    ._hj_feedback_container ._hj-9Mvlt__EmotionStep__EmotionFooter._hj-atUfw__EmotionStep__isEmbedded._hj-faUPK__EmotionStep__phone,
    ._hj_feedback_container ._hj-9Mvlt__EmotionStep__EmotionFooter._hj-atUfw__EmotionStep__isEmbedded._hj-ZT0W6__EmotionStep__tablet {
      height: 46px
    }

    ._hj_feedback_container ._hj-hcA79__EmotionStep__EmotionFooterWithBranding {
      margin-bottom: 20px
    }

    ._hj_feedback_container ._hj-hcA79__EmotionStep__EmotionFooterWithBranding._hj-atUfw__EmotionStep__isEmbedded {
      margin-top: auto;
      margin-bottom: 0
    }
  </style>
  <style>
    ._hj-WZl3r__HotjarBranding__hotjarBranding {
      font-size: 0.6875em !important;
      font-size: var(--hjFeedbackFooterFontSize, 0.6875em) !important;
      direction: ltr
    }

    ._hj-WZl3r__HotjarBranding__hotjarBranding a {
      color: inherit !important
    }

    ._hj-WZl3r__HotjarBranding__hotjarBranding ._hj-q7vuu__HotjarBranding__hotjarBrandingIcon {
    /*  background-image: url(https://script.hotjar.com/widget_icons_light.766225.png);*/
      background-repeat: no-repeat;
      background-position: -16px -1px;
      margin-right: 4px;
      width: 16px;
      height: 16px;
      display: inline-block !important;
      zoom: 1;
      vertical-align: middle
    }

    ._hj-WZl3r__HotjarBranding__hotjarBranding ._hj-sm6N3__HotjarBranding__hotjarBrandingLink {
      text-decoration: underline !important
    }
  </style>
  <style>
    ._hj-Z5Onj__Title__Title {
      font-size: 17px !important;
      padding: 30px !important;
      text-align: center
    }

    ._hj-Z5Onj__Title__Title._hj-LRxgR__Title__phone {
      font-size: 18px !important;
      padding: 35px 50px !important
    }

    ._hj-Z5Onj__Title__Title._hj-J7Nqs__Title__tablet {
      font-size: 26px !important;
      padding: 40px 50px !important
    }

    ._hj-Z5Onj__Title__Title._hj-8VPIr__Title__isEmbedded {
      font-weight: 500 !important;
      font-size: 17px !important;
      padding: 0 24px 16px !important;
      border-bottom: 0 !important
    }

    ._hj-Z5Onj__Title__Title._hj-8VPIr__Title__isEmbedded._hj-LRxgR__Title__phone,
    ._hj-Z5Onj__Title__Title._hj-8VPIr__Title__isEmbedded._hj-J7Nqs__Title__tablet {
      font-size: 18px !important
    }

    ._hj-Z5Onj__Title__Title._hj-9ZlKs__Title__compact._hj-8VPIr__Title__isEmbedded {
      font-size: 15px !important
    }

    ._hj-Z5Onj__Title__Title._hj-9ZlKs__Title__compact._hj-J7Nqs__Title__tablet {
      font-size: 18px !important;
      padding-right: 30px !important;
      padding-left: 30px !important
    }
  </style>
  <style>
    ._hj-aMKgg__EmotionComment__textArea {}

    ._hj-7CHax__EmotionComment__iconSelectElement {}

    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container {
      position: relative
    }

    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container._hj-WHZRc__EmotionComment__phone ._hj-aMKgg__EmotionComment__textArea,
    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container._hj-ScRrq__EmotionComment__tablet ._hj-aMKgg__EmotionComment__textArea {
      font-size: 17px;
      border-radius: 4px;
      line-height: 1.4em !important;
      padding: 15px !important;
      height: 129px !important
    }

    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container._hj-WHZRc__EmotionComment__phone ._hj-aMKgg__EmotionComment__textArea._hj-l2lLN__EmotionComment__isEmbedded,
    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container._hj-ScRrq__EmotionComment__tablet ._hj-aMKgg__EmotionComment__textArea._hj-l2lLN__EmotionComment__isEmbedded {
      margin: 16px 0 0;
      width: 100%;
      height: 40px !important;
      white-space: nowrap;
      padding: 3px 16px !important;
      line-height: 2 !important
    }

    ._hj_feedback_container ._hj-3uW0\+__EmotionComment__container._hj-ScRrq__EmotionComment__tablet ._hj-aMKgg__EmotionComment__textArea {
      font-size: 22px;
      padding: 20px !important;
      height: 199px !important
    }

    ._hj_feedback_container ._hj-aMKgg__EmotionComment__textArea {
      display: block;
      padding: 12px 20px !important;
      height: 105px !important;
      width: 100%;
      max-width: 320px;
      line-height: 18px !important;
      resize: none;
      background: #eaeaeb !important;
      border: 0 !important;
      overflow: auto;
      border-radius: 0
    }

    ._hj_feedback_container ._hj-aMKgg__EmotionComment__textArea._hj-l2lLN__EmotionComment__isEmbedded {
      min-width: 0;
      width: calc(100% - 48px);
      margin: 16px 24px;
      height: 40px !important;
      box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1), 0px 1px 2px rgba(0, 0, 0, 0.08) !important;
      border-radius: 4px;
      background: white !important;
      padding: 5px 16px !important;
      line-height: 2 !important
    }

    ._hj_feedback_container ._hj-aMKgg__EmotionComment__textArea._hj-l2lLN__EmotionComment__isEmbedded:focus {
      box-shadow: 0 0 0 1px #fff, 0 0 0 3px var(--hjFeedbackAccentColor), inset 0 0 0 1px #838696 !important
    }

    ._hj_feedback_container ._hj-DY437__EmotionComment__elementSelector {
      background: #eaeaeb;
      padding: 10px 20px;
      position: relative;
      font-size: 16px
    }

    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton {
      padding: 0 !important;
      background: none !important;
      border: none !important;
      cursor: pointer;
      outline: none;
      opacity: 0.75;
      transition: opacity 0.2s ease-in-out;
      font-size: 16px
    }

    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton:hover,
    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton:focus {
      opacity: 1
    }

    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton:hover+._hj-1b\+Um__EmotionComment__selectorTootlip,
    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton:focus+._hj-1b\+Um__EmotionComment__selectorTootlip {
      opacity: 1
    }

    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton._hj-T-tRO__EmotionComment__selected {
      opacity: 1
    }

    ._hj_feedback_container ._hj-8ZaYv__EmotionComment__selectButton._hj-T-tRO__EmotionComment__selected ._hj-7CHax__EmotionComment__iconSelectElement::before {
      color: #f4364c !important;
      color: var(--hjFeedbackAccentColor, #f4364c) !important
    }

    ._hj_feedback_container ._hj-1b\+Um__EmotionComment__selectorTootlip {
      background: black;
      color: white;
      font-size: 12px;
      padding: 8px 12px;
      border-radius: 3px;
      position: absolute;
      left: 60px;
      top: 5px;
      width: 195px;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s ease-in-out
    }

    ._hj_feedback_container ._hj-1b\+Um__EmotionComment__selectorTootlip::before {
      content: '';
      width: 1px;
      height: 1px;
      position: absolute;
      left: -5px;
      top: 10px;
      border-top: 4px solid transparent;
      border-bottom: 4px solid transparent;
      border-right: 5px solid black
    }

    ._hj_feedback_container ._hj-1b\+Um__EmotionComment__selectorTootlip._hj-AScxi__EmotionComment__rtl:before {
      right: -5px;
      top: 10px;
      border-left: 5px solid black;
      border-right: none
    }

    ._hj_feedback_container ._hj-7CHax__EmotionComment__iconSelectElement::before {
      color: #454a55 !important;
      font-size: 22px
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-fqgX9__CommentStep__outerContainer._hj-AxVYv__CommentStep__isEmbedded {
      flex: 1;
      min-height: 160px
    }

    ._hj_feedback_container ._hj-fqgX9__CommentStep__outerContainer._hj-AxVYv__CommentStep__isEmbedded._hj-OF5Wj__CommentStep__phone,
    ._hj_feedback_container ._hj-fqgX9__CommentStep__outerContainer._hj-AxVYv__CommentStep__isEmbedded._hj-eeLUU__CommentStep__tablet {
      min-height: 185px
    }

    ._hj_feedback_container ._hj-UxzaS__CommentStep__emotionOptions {
      margin-top: 30px;
      padding: 0 12px;
      display: flex;
      align-items: flex-start
    }

    ._hj_feedback_container ._hj-UxzaS__CommentStep__emotionOptions._hj-AxVYv__CommentStep__isEmbedded {
      margin-top: 0
    }

    ._hj_feedback_container ._hj-qaasM__CommentStep__emotionOptionSmaller {
      font-size: 26px
    }

    ._hj_feedback_container ._hj-o6b77__CommentStep__extraMessage {
      font-size: 13px;
      padding: 12px 20px 0
    }

    ._hj_feedback_container ._hj-o6b77__CommentStep__extraMessage a {
      text-decoration: underline !important
    }

    ._hj_feedback_container ._hj-wASqs__CommentStep__footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 24px 12px 24px;
      direction: ltr;
      gap: 10px
    }

    ._hj_feedback_container ._hj-wASqs__CommentStep__footer._hj-AxVYv__CommentStep__isEmbedded {
      padding: 0 24px;
      margin-top: auto
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-AxVYv__CommentStep__isEmbedded {
      min-height: 160px;
      display: flex;
      flex-direction: column
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-AxVYv__CommentStep__isEmbedded._hj-OF5Wj__CommentStep__phone,
    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-AxVYv__CommentStep__isEmbedded._hj-eeLUU__CommentStep__tablet {
      min-height: 185px;
      padding: 0 24px !important
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-AxVYv__CommentStep__isEmbedded._hj-OF5Wj__CommentStep__phone ._hj-wASqs__CommentStep__footer,
    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-AxVYv__CommentStep__isEmbedded._hj-eeLUU__CommentStep__tablet ._hj-wASqs__CommentStep__footer {
      padding: 0 !important
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-OF5Wj__CommentStep__phone {
      padding: 15px 30px 0
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-OF5Wj__CommentStep__phone ._hj-wASqs__CommentStep__footer {
      padding-top: 30px
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-eeLUU__CommentStep__tablet {
      padding: 15px 60px 0
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-eeLUU__CommentStep__tablet ._hj-wASqs__CommentStep__footer {
      padding-top: 40px;
      --hjFeedbackFooterFontSize: 14px
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-OF5Wj__CommentStep__phone ._hj-UxzaS__CommentStep__emotionOptions,
    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-eeLUU__CommentStep__tablet ._hj-UxzaS__CommentStep__emotionOptions {
      padding: 0
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-OF5Wj__CommentStep__phone ._hj-UxzaS__CommentStep__emotionOptions._hj-AxVYv__CommentStep__isEmbedded,
    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-eeLUU__CommentStep__tablet ._hj-UxzaS__CommentStep__emotionOptions._hj-AxVYv__CommentStep__isEmbedded {
      margin-top: 0
    }

    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-OF5Wj__CommentStep__phone ._hj-wASqs__CommentStep__footer,
    ._hj_feedback_container ._hj-CxgLB__CommentStep__container._hj-eeLUU__CommentStep__tablet ._hj-wASqs__CommentStep__footer {
      padding-left: 0;
      padding-right: 0;
      padding-bottom: 30px
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-FcA7i__ElementHighlighter__container {
      pointer-events: none;
      position: fixed;
      z-index: -1
    }

    ._hj_feedback_container ._hj-QJAVw__ElementHighlighter__pageFrame {
      pointer-events: none;
      position: fixed;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 5;
      border-width: 4px !important;
      border-style: solid !important;
      border-color: #ffd902 !important;
      border-color: var(--hjFeedbackSelectionColor, #ffd902) !important;
      transition: border 0.2s ease-in-out
    }

    ._hj_feedback_container ._hj-F9lkb__ElementHighlighter__title {
      position: fixed;
      top: -4px;
      left: 50%;
      width: 260px;
      margin-left: -130px;
      padding: 23px 0 19px 0;
      z-index: 1;
      text-align: center;
      font-size: 13px;
      border-radius: 0 0 10px 10px;
      background-color: #ffd902 !important;
      background-color: var(--hjFeedbackSelectionColor, #ffd902) !important;
      color: #3c3c3c !important;
      color: var(--hjFeedbackSelectionTextColor, #3c3c3c) !important;
      box-shadow: 0 2px 25px 3px rgba(0, 0, 0, 0.3)
    }

    ._hj_feedback_container ._hj-F9lkb__ElementHighlighter__title::before,
    ._hj_feedback_container ._hj-F9lkb__ElementHighlighter__title::after {
      content: '';
      display: block;
      width: 55px;
      height: 50px;
      background-color: #ffd902 !important;
      background-color: var(--hjFeedbackSelectionColor, #ffd902) !important;
      position: absolute;
      top: 0;
      z-index: -1
    }

    ._hj_feedback_container ._hj-F9lkb__ElementHighlighter__title::before {
      left: -9px;
      transform: skewX(20deg)
    }

    ._hj_feedback_container ._hj-F9lkb__ElementHighlighter__title::after {
      right: -9px;
      transform: skewX(-20deg)
    }

    ._hj_feedback_container ._hj-GVV9O__ElementHighlighter__closeButton {
      height: 19px;
      width: 19px;
      margin-left: 10px;
      padding: 0;
      border-radius: 50%;
      background: transparent;
      border: 0;
      color: #3c3c3c !important;
      color: var(--hjFeedbackSelectionTextColor, #3c3c3c) !important;
      cursor: pointer;
      pointer-events: all
    }

    ._hj_feedback_container ._hj-GVV9O__ElementHighlighter__closeButton:hover {
      background: rgba(0, 0, 0, 0.2)
    }

    /*
    [data-hotjar-cursor-pointer],
    [data-hotjar-cursor-pointer] * {
      cursor: pointer !important
    }
    */
  </style>
  <style>
    ._hj_feedback_container ._hj-vFRN0__HighlightBox__boxFrame {
      display: block;
      border-width: 4px !important;
      border-style: dashed !important;
      border-color: #ffd902 !important;
      border-color: var(--hjFeedbackSelectionColor, #ffd902) !important;
      border-radius: 3px;
      position: fixed;
      z-index: -1;
      box-sizing: content-box !important;
      transition: border 0.2s ease-in-out
    }

    ._hj_feedback_container ._hj-OTcpn__HighlightBox__boxSelected {
      pointer-events: all;
      border-style: solid !important;
      border-color: #f4364c !important;
      border-color: var(--hjFeedbackAccentColor, #f4364c) !important;
      cursor: pointer
    }

    ._hj_feedback_container ._hj-OTcpn__HighlightBox__boxSelected ._hj-huuHN__HighlightBox__changeLabel {
      position: absolute;
      bottom: -32px;
      right: -4px;
      padding: 8px 12px;
      background-color: #f4364c !important;
      background-color: var(--hjFeedbackAccentColor, #f4364c) !important;
      color: #ffffff !important;
      color: var(--hjFeedbackAccentTextColor, #fff) !important;
      border-radius: 0 0 3px 3px;
      font-size: 12px
    }

    ._hj_feedback_container ._hj-YF9ms__HighlightBox__closeButton {
      padding: 5px 7px 3px 7px;
      right: -12px;
      top: -13px;
      position: absolute;
      background-color: #f4364c !important;
      background-color: var(--hjFeedbackAccentColor, #f4364c) !important;
      color: #ffffff !important;
      color: var(--hjFeedbackAccentTextColor, #fff) !important;
      border-radius: 50%;
      border: 0;
      cursor: pointer;
      font-size: 12px;
      pointer-events: all;
      text-align: center;
      z-index: 11
    }

    ._hj_feedback_container ._hj-G7nXR__HighlightBox__dimmer {
      position: fixed;
      z-index: -1;
      transition: opacity 0.2s ease-in-out;
      opacity: 0.45;
      pointer-events: all;
      background: black !important
    }
  </style>
  <style>
    ._hj-7HL5s__EmailStep__container._hj-\+Xh-y__EmailStep__isEmbedded {
      display: flex;
      flex-direction: column;
      min-height: 160px
    }

    ._hj-7HL5s__EmailStep__container._hj-\+Xh-y__EmailStep__isEmbedded._hj-hLwUY__EmailStep__phone,
    ._hj-7HL5s__EmailStep__container._hj-\+Xh-y__EmailStep__isEmbedded._hj-Te99I__EmailStep__tablet {
      min-height: 185px
    }

    ._hj-7HL5s__EmailStep__container._hj-hLwUY__EmailStep__phone ._hj-x8PHg__EmailStep__inputWrapper,
    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-x8PHg__EmailStep__inputWrapper {
      padding: 30px
    }

    ._hj-7HL5s__EmailStep__container._hj-hLwUY__EmailStep__phone ._hj-msvyV__EmailStep__input,
    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-msvyV__EmailStep__input {
      font-size: 17px !important;
      border-radius: 4px
    }

    ._hj-7HL5s__EmailStep__container._hj-hLwUY__EmailStep__phone ._hj-CSpXq__EmailStep__buttons,
    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-CSpXq__EmailStep__buttons {
      padding: 0 30px 12px !important
    }

    ._hj-7HL5s__EmailStep__container._hj-hLwUY__EmailStep__phone ._hj-CSpXq__EmailStep__buttons._hj-\+Xh-y__EmailStep__isEmbedded,
    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-CSpXq__EmailStep__buttons._hj-\+Xh-y__EmailStep__isEmbedded {
      padding: 0 24px !important
    }

    ._hj-7HL5s__EmailStep__container._hj-hLwUY__EmailStep__phone ._hj-rWd-f__EmailStep__clearButton,
    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-rWd-f__EmailStep__clearButton {
      font-size: 18px !important;
      padding: 12px 20px !important
    }

    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-x8PHg__EmailStep__inputWrapper {
      padding: 40px 60px
    }

    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-msvyV__EmailStep__input {
      font-size: 22px !important;
      padding: 26px 20px !important;
      height: 74px !important
    }

    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-CSpXq__EmailStep__buttons {
      padding-right: 60px !important;
      padding-left: 60px !important
    }

    ._hj-7HL5s__EmailStep__container._hj-Te99I__EmailStep__tablet ._hj-rWd-f__EmailStep__clearButton {
      font-size: 22px !important;
      padding: 14px 28px !important
    }

    ._hj-BuDcm__EmailStep__fieldset {
      border: none;
      margin: 0;
      padding: 0
    }

    ._hj-msvyV__EmailStep__input {
      width: 100%;
      line-height: 22px !important;
      padding: 12px 20px !important;
      height: 46px !important;
      border: none !important;
      font-size: 14px !important;
      text-align: center;
      background: #eaeaeb !important;
      color: #454a55 !important;
      box-shadow: none !important;
      outline: none
    }

    ._hj-msvyV__EmailStep__input::-ms-clear {
      display: none
    }

    ._hj-AZo5T__EmailStep__embedEmailStep ._hj-msvyV__EmailStep__input {
      width: calc(100% - 48px);
      height: 40px !important;
      box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1), 0px 1px 2px rgba(0, 0, 0, 0.08) !important;
      border-radius: 4px;
      background: white !important;
      line-height: 2 !important;
      margin: 0 24px 16px;
      text-align: left
    }

    ._hj-AZo5T__EmailStep__embedEmailStep ._hj-msvyV__EmailStep__input:focus {
      box-shadow: 0 0 0 1px #fff, 0 0 0 3px var(--hjFeedbackAccentColor), inset 0 0 0 1px #838696 !important
    }

    ._hj-AZo5T__EmailStep__embedEmailStep ._hj-x8PHg__EmailStep__inputWrapper {
      padding: 0 !important
    }

    ._hj-CSpXq__EmailStep__buttons {
      text-align: right;
      padding: 12px 24px !important;
      display: flex;
      align-items: center;
      justify-content: flex-end
    }

    ._hj-CSpXq__EmailStep__buttons._hj-\+Xh-y__EmailStep__isEmbedded {
      padding: 0 24px !important;
      margin-top: auto
    }

    ._hj-CSpXq__EmailStep__buttons button {
      transition: all 0.2s ease-in-out;
      margin-left: 4px;
      display: inline-block
    }

    ._hj-CSpXq__EmailStep__buttons ._hj-rWd-f__EmailStep__clearButton {
      color: #aaaaaa
    }

    ._hj-CSpXq__EmailStep__buttons ._hj-rWd-f__EmailStep__clearButton:hover {
      color: #666666
    }
  </style>
  <style>
    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer {
      text-align: center;
      font-size: 13px;
      padding: 0 26px 30px
    }

    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-WJRTV__FinalStep__isEmbedded {
      padding: 0 24px
    }

    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-WJRTV__FinalStep__isEmbedded._hj-Nb-j0__FinalStep__phone,
    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-WJRTV__FinalStep__isEmbedded._hj-Jwd2O__FinalStep__tablet {
      padding: 0 24px
    }

    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-Nb-j0__FinalStep__phone,
    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-Jwd2O__FinalStep__tablet {
      font-size: 16px;
      padding: 30px 45px
    }

    ._hj_feedback_container ._hj-tqHxq__FinalStep__consentContainer._hj-Jwd2O__FinalStep__tablet {
      padding: 40px 60px
    }

    ._hj_feedback_container ._hj-Sr1c2__FinalStep__legalInfoContainer {
      padding: 0 12px
    }

    ._hj_feedback_container ._hj-Sr1c2__FinalStep__legalInfoContainer._hj-Nb-j0__FinalStep__phone {
      padding: 30px
    }

    ._hj_feedback_container ._hj-Sr1c2__FinalStep__legalInfoContainer._hj-Jwd2O__FinalStep__tablet {
      padding: 40px 60px
    }

    ._hj_feedback_container ._hj-Sr1c2__FinalStep__legalInfoContainer._hj-WJRTV__FinalStep__isEmbedded {
      margin-top: 16px;
      padding-top: 0 !important;
      padding-bottom: 0 !important
    }

    ._hj_feedback_container ._hj-L3R0-__FinalStep__finalStep._hj-WJRTV__FinalStep__isEmbedded {
      display: flex;
      flex-direction: column;
      justify-content: center;
      min-height: 160px
    }

    ._hj_feedback_container ._hj-L3R0-__FinalStep__finalStep._hj-WJRTV__FinalStep__isEmbedded._hj-Nb-j0__FinalStep__phone,
    ._hj_feedback_container ._hj-L3R0-__FinalStep__finalStep._hj-WJRTV__FinalStep__isEmbedded._hj-Jwd2O__FinalStep__tablet {
      min-height: 185px
    }

    ._hj_feedback_container ._hj-U4Uxc__FinalStep__finalStepButtonWrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 24px 0 0 0
    }
  </style>
  <style>
    ._hj-4rJYs__LegalInfo__legalInfo {
      padding: 0 12px 12px 12px !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo._hj-m\+yxo__LegalInfo__isEmbedded {
      padding: 0 12px !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo:after {
      content: '';
      clear: both !important;
      display: block !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo ._hj-SYMwv__LegalInfo__legalSite {
      font-size: 0.75em;
      float: right !important;
      text-align: right
    }

    ._hj-4rJYs__LegalInfo__legalInfo ._hj-SYMwv__LegalInfo__legalSite:hover {
      text-decoration-thickness: 2px !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo ._hj-8JMiv__LegalInfo__legalName {
      font-size: 0.75em;
      float: left !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo ._hj-PkYVh__LegalInfo__footerTextColor,
    ._hj-4rJYs__LegalInfo__legalInfo ._hj-PkYVh__LegalInfo__footerTextColor:link,
    ._hj-4rJYs__LegalInfo__legalInfo ._hj-PkYVh__LegalInfo__footerTextColor:hover {
      color: #333333 !important;
      color: var(--hjFeedbackSecondaryTextColor, #333) !important
    }

    ._hj-4rJYs__LegalInfo__legalInfo._hj-sXaRy__LegalInfo__centered {
      display: flex;
      justify-content: center
    }

    ._hj-4rJYs__LegalInfo__legalInfo._hj-sXaRy__LegalInfo__centered ._hj-8JMiv__LegalInfo__legalName,
    ._hj-4rJYs__LegalInfo__legalInfo._hj-sXaRy__LegalInfo__centered ._hj-SYMwv__LegalInfo__legalSite {
      margin: 0 8px
    }
  </style>
  <style>
    ._hj-widget-container ._hj-QJHfS__styles__consentMain,
    ._hj_feedback_container ._hj-QJHfS__styles__consentMain {
      display: flex;
      flex-direction: column-reverse
    }

    ._hj-widget-container ._hj-QJHfS__styles__consentMain ._hj-iuh5p__styles__consentButtonsWrapper,
    ._hj_feedback_container ._hj-QJHfS__styles__consentMain ._hj-iuh5p__styles__consentButtonsWrapper {
      display: flex;
      flex-direction: row-reverse;
      justify-content: center
    }

    ._hj-widget-container ._hj-cK\+L-__styles__consentMessage,
    ._hj_feedback_container ._hj-cK\+L-__styles__consentMessage {
      color: #7c7c7c !important
    }

    ._hj-widget-container ._hj-cK\+L-__styles__consentMessage._hj-RTq8B__styles__dark,
    ._hj_feedback_container ._hj-cK\+L-__styles__consentMessage._hj-RTq8B__styles__dark {
      color: rgba(255, 255, 255, 0.6) !important
    }

    ._hj-widget-container ._hj-cK\+L-__styles__consentMessage._hj-N21Xh__styles__light,
    ._hj_feedback_container ._hj-cK\+L-__styles__consentMessage._hj-N21Xh__styles__light {
      color: rgba(0, 0, 0, 0.6) !important
    }

    ._hj-widget-container ._hj-cK\+L-__styles__consentMessage a,
    ._hj_feedback_container ._hj-cK\+L-__styles__consentMessage a {
      color: inherit !important
    }

    ._hj-widget-container ._hj-B\+0X3__styles__consentButton,
    ._hj_feedback_container ._hj-B\+0X3__styles__consentButton {
      line-height: 18px !important;
      font-size: 18px !important;
      margin: 20px 12px 0 12px;
      width: 50px !important;
      border: 1px solid rgba(0, 0, 0, 0) !important
    }

    ._hj-widget-container ._hj-B\+0X3__styles__consentButton._hj-oxtSd__styles__declineButton,
    ._hj_feedback_container ._hj-B\+0X3__styles__consentButton._hj-oxtSd__styles__declineButton {
      color: #324fbe !important;
      color: var(--hjFeedbackAccentColor, #324fbe) !important;
      background-color: transparent !important;
      border-color: #324fbe !important;
      border-color: var(--hjFeedbackAccentColor, #324fbe) !important
    }

    ._hj-widget-container ._hj-B\+0X3__styles__consentButton._hj-oxtSd__styles__declineButton:hover,
    ._hj_feedback_container ._hj-B\+0X3__styles__consentButton._hj-oxtSd__styles__declineButton:hover {
      color: #1c3286 !important;
      color: var(--hjFeedbackAccentHoverColor, #1c3286) !important;
      box-shadow: 0 0 0 1px var(--hjFeedbackAccentHoverColor, #1c3286) !important
    }

    ._hj-widget-container ._hj-B\+0X3__styles__consentButton i,
    ._hj_feedback_container ._hj-B\+0X3__styles__consentButton i {
      display: flex !important;
      justify-content: center;
      align-items: center;
      height: 1.1875em;
      font-size: 1.1875em
    }
  </style>
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> cz-shortcut-listen="true" style="overflow: auto;" >

