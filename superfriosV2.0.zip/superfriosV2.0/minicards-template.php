<div class="row items-container hidden-xs hidden-sm">
    <?php
    $images = get_option('custom_images', array());
    $links = array();
    
    for ($i = 1; $i <= 4; $i++) {
        $links[$i] = isset($images["custom_link_{$i}"]) ? esc_url($images["custom_link_{$i}"]) : '';
        $image_src = isset($images["custom_image_{$i}"]) ? esc_url($images["custom_image_{$i}"]) : '';
        
        if ($image_src) {
            ?>
            <div class="col-lg-3 col-md-3">
                <!-- ko if: <?php echo !empty($links[$i]) ? "startsWith('/',$links[$i])" : "false"; ?> -->
                <a id="cc_img__resize_wrapper" data-bind="attr: {href: '<?php echo $links[$i]; ?>'}" href="<?php echo $links[$i]; ?>">
                    <img data-bind="ccResizeImage: {
                        source: '<?php echo $image_src; ?>',
                        size: '70,200',
                        alt: 'Card Image <?php echo $i; ?>'}"
                        alt="Card Image <?php echo $i; ?>"
                        src="<?php echo $image_src; ?>&amp;height=70&amp;width=200">
                </a>
                <!-- /ko -->
                <!-- ko if: <?php echo empty($links[$i]) ? "true" : "false"; ?> -->
                <!-- /ko -->
                <div class="separator"></div>
            </div>
            <?php
        }
    }
    ?>
</div>
