<?php
/*
Template Name: Carousel Template
*/

get_header(); 

$images = get_post_meta(get_the_ID(), '_carousel_images', true);
?>

<div id="carouselwi2200005" class="slick-carousel">
    <?php if (!empty($images)) : ?>
        <?php foreach ($images as $image) : ?>
            <div class="carousel-banner item">
                <img src="<?php echo esc_url($image); ?>" alt="">
                <div class="gradient"></div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    $('.slick-carousel').slick({
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000
    });
});
</script>

<?php get_footer(); ?>
